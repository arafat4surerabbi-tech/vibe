import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { StoreProvider } from "@/contexts/StoreContext";
import { AuthProvider } from "@/hooks/useAuth";
import { useDevSettings } from "@/hooks/useDevSettings";
import CartDrawer from "@/components/website/CartDrawer";
import BlockedPage from "@/components/BlockedPage";
import Index from "./pages/Index.tsx";
import Admin from "./pages/Admin.tsx";
import AdminLogin from "./pages/AdminLogin.tsx";
import ProductDetail from "./pages/ProductDetail.tsx";
import Checkout from "./pages/Checkout.tsx";
import CategoryProducts from "./pages/CategoryProducts.tsx";
import DevLogin from "./pages/DevLogin.tsx";
import DevPanel from "./pages/DevPanel.tsx";
import NotFound from "./pages/NotFound.tsx";
import MetaPixel from "@/components/website/MetaPixel";
import ScrollToTop from "@/components/ScrollToTop";
import { Loader2 } from "lucide-react";

const queryClient = new QueryClient();

const AppRoutes = () => {
  const { siteBlocked, adminBlocked, blockMessage, adminBlockMessage, hostingExpired, loading } = useDevSettings();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const isSiteBlocked = siteBlocked || hostingExpired;
  const isAdminBlocked = adminBlocked || hostingExpired;

  return (
    <BrowserRouter>
      <ScrollToTop />
      <MetaPixel />
      <CartDrawer />
      <Routes>
        {/* Dev panel routes - always accessible */}
        <Route path="/dev-login" element={<DevLogin />} />
        <Route path="/dev-panel" element={<DevPanel />} />

        {/* Admin routes */}
        <Route path="/admin/login" element={isAdminBlocked ? <BlockedPage message={hostingExpired ? blockMessage : adminBlockMessage} /> : <AdminLogin />} />
        <Route path="/admin/*" element={isAdminBlocked ? <BlockedPage message={hostingExpired ? blockMessage : adminBlockMessage} /> : <Admin />} />

        {/* Public website routes */}
        <Route path="/" element={isSiteBlocked ? <BlockedPage message={blockMessage} /> : <Index />} />
        <Route path="/category/:name" element={isSiteBlocked ? <BlockedPage message={blockMessage} /> : <CategoryProducts />} />
        <Route path="/product/:id" element={isSiteBlocked ? <BlockedPage message={blockMessage} /> : <ProductDetail />} />
        <Route path="/checkout" element={isSiteBlocked ? <BlockedPage message={blockMessage} /> : <Checkout />} />
        <Route path="*" element={isSiteBlocked ? <BlockedPage message={blockMessage} /> : <NotFound />} />
      </Routes>
    </BrowserRouter>
  );
};

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <StoreProvider>
            <Toaster />
            <Sonner />
            <AppRoutes />
          </StoreProvider>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
