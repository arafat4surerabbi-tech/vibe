import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import type { Order } from "@/contexts/StoreContext";

interface StoreInfo {
  name: string;
  phone: string;
  email: string;
  address: string;
}

const generateSingleInvoice = (
  doc: jsPDF,
  order: Order,
  store: StoreInfo,
  startNewPage: boolean
) => {
  if (startNewPage) doc.addPage();

  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 15;
  let y = 20;

  // Header
  doc.setFontSize(18);
  doc.setFont("helvetica", "bold");
  doc.text(store.name, margin, y);

  doc.setFontSize(9);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(100);
  doc.text(store.phone, pageWidth - margin, y - 4, { align: "right" });
  doc.text(store.email, pageWidth - margin, y + 1, { align: "right" });
  doc.text(store.address, pageWidth - margin, y + 6, { align: "right" });
  doc.setTextColor(0);

  y += 12;
  doc.setDrawColor(200);
  doc.line(margin, y, pageWidth - margin, y);
  y += 10;

  // Invoice title
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.text("INVOICE", margin, y);

  doc.setFontSize(9);
  doc.setFont("helvetica", "normal");
  doc.text(`Invoice #: ${order.id}`, pageWidth - margin, y - 3, { align: "right" });
  doc.text(`Date: ${order.date}`, pageWidth - margin, y + 3, { align: "right" });
  y += 14;

  // Customer info
  doc.setFontSize(10);
  doc.setFont("helvetica", "bold");
  doc.text("Bill To:", margin, y);
  y += 6;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(order.customer, margin, y);
  y += 5;
  doc.text(`Phone: ${order.phone}`, margin, y);
  y += 5;
  if (order.email) { doc.text(`Email: ${order.email}`, margin, y); y += 5; }
  if (order.address) { doc.text(`Address: ${order.address}`, margin, y); y += 5; }
  if (order.deliveryArea) { doc.text(`Area: ${order.deliveryArea}`, margin, y); y += 5; }
  doc.text(`Payment: ${order.paymentMethod || "COD"}`, margin, y);
  y += 5;
  doc.text(`Status: ${order.status}`, margin, y);
  y += 10;

  // Products table
  const products = order.products || [];
  const tableBody = products.map((p, i) => [
    String(i + 1),
    p.name,
    String(p.qty),
    `${p.price.toLocaleString()} BDT`,
    `${(p.price * p.qty).toLocaleString()} BDT`,
  ]);

  autoTable(doc, {
    startY: y,
    head: [["#", "Product", "Qty", "Price", "Subtotal"]],
    body: tableBody.length > 0 ? tableBody : [["—", "No items", "—", "—", "—"]],
    margin: { left: margin, right: margin },
    headStyles: { fillColor: [50, 50, 50], fontSize: 9, fontStyle: "bold" },
    bodyStyles: { fontSize: 9 },
    columnStyles: {
      0: { cellWidth: 12 },
      1: { cellWidth: "auto" },
      2: { cellWidth: 18, halign: "center" },
      3: { cellWidth: 35, halign: "right" },
      4: { cellWidth: 40, halign: "right" },
    },
    theme: "striped",
  });

  // Total
  const finalY = (doc as any).lastAutoTable?.finalY || y + 20;
  const totalY = finalY + 8;

  doc.setDrawColor(200);
  doc.line(pageWidth - margin - 80, totalY - 4, pageWidth - margin, totalY - 4);

  doc.setFontSize(11);
  doc.setFont("helvetica", "bold");
  doc.text("Total:", pageWidth - margin - 80, totalY + 2);
  doc.text(`${order.total.toLocaleString()} BDT`, pageWidth - margin, totalY + 2, { align: "right" });

  // Courier info
  if (order.courierBooking) {
    const cY = totalY + 14;
    doc.setFontSize(9);
    doc.setFont("helvetica", "bold");
    doc.text("Courier:", margin, cY);
    doc.setFont("helvetica", "normal");
    doc.text(`${order.courierBooking.courierName} — ${order.courierBooking.consignmentId || order.courierBooking.trackingId}`, margin + 22, cY);
  }

  // Footer
  const pageH = doc.internal.pageSize.getHeight();
  doc.setFontSize(8);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(150);
  doc.text("Thank you for your purchase!", pageWidth / 2, pageH - 12, { align: "center" });
  doc.setTextColor(0);
};

const buildStore = (storeSettings: Record<string, string>): StoreInfo => ({
  name: storeSettings.store_name || "Store",
  phone: storeSettings.store_phone || "",
  email: storeSettings.store_email || "",
  address: storeSettings.store_address || "",
});

const openPrintWindow = (doc: jsPDF) => {
  const blob = doc.output("blob");
  const url = URL.createObjectURL(blob);
  const printWindow = window.open("", "_blank");
  if (printWindow) {
    printWindow.document.write(`
      <html>
        <head><title>Invoice</title></head>
        <body style="margin:0;padding:0;">
          <embed src="${url}" type="application/pdf" width="100%" height="100%" style="position:fixed;top:0;left:0;width:100%;height:100%;" />
        </body>
      </html>
    `);
    printWindow.document.close();
    // Give the PDF time to render before triggering print
    setTimeout(() => {
      printWindow.focus();
      printWindow.print();
    }, 1000);
  }
};

export const printInvoice = (order: Order, storeSettings: Record<string, string>) => {
  const doc = new jsPDF();
  generateSingleInvoice(doc, order, buildStore(storeSettings), false);
  openPrintWindow(doc);
};

export const printBulkInvoices = (orders: Order[], storeSettings: Record<string, string>) => {
  if (orders.length === 0) return;
  const doc = new jsPDF();
  orders.forEach((order, i) => {
    generateSingleInvoice(doc, order, buildStore(storeSettings), i > 0);
  });
  openPrintWindow(doc);
};

export const downloadInvoice = (order: Order, storeSettings: Record<string, string>) => {
  const doc = new jsPDF();
  generateSingleInvoice(doc, order, buildStore(storeSettings), false);
  doc.save(`Invoice-${order.id}.pdf`);
};

export const downloadBulkInvoices = (orders: Order[], storeSettings: Record<string, string>) => {
  if (orders.length === 0) return;
  const doc = new jsPDF();
  orders.forEach((order, i) => {
    generateSingleInvoice(doc, order, buildStore(storeSettings), i > 0);
  });
  doc.save(`Invoices-${orders.length}-orders.pdf`);
};
