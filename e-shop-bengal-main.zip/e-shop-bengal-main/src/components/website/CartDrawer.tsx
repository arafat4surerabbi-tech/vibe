import { X, Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStore } from "@/contexts/StoreContext";
import { useNavigate } from "react-router-dom";

const CartDrawer = () => {
  const { cart, cartTotal, cartOpen, setCartOpen, removeFromCart, updateCartQty } = useStore();
  const navigate = useNavigate();

  if (!cartOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-black/40 z-50" onClick={() => setCartOpen(false)} />
      <div className="fixed right-0 top-0 h-full w-full max-w-md bg-background border-l border-border z-50 flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h2 className="font-heading text-lg font-bold">Your Cart ({cart.length})</h2>
          <button onClick={() => setCartOpen(false)} className="p-1 hover:bg-muted rounded-full">
            <X className="h-5 w-5" />
          </button>
        </div>

        {cart.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
            <ShoppingBag className="h-12 w-12 mb-3 opacity-30" />
            <p className="font-body">Your cart is empty</p>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {cart.map((item) => (
                <div key={`${item.product.id}-${item.size}-${item.color}`} className="flex gap-3 bg-card rounded-xl p-3 border border-border/50">
                  <div className="w-16 h-16 bg-muted rounded-lg flex items-center justify-center shrink-0 overflow-hidden">
                    {item.product.image ? (
                      <img src={item.product.image} alt={item.product.name} className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-2xl opacity-30">👕</span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-heading text-sm font-semibold text-foreground truncate">{item.product.name}</h3>
                    <p className="text-xs text-muted-foreground">
                      {item.size && <>Size: {item.size}</>}
                      {item.size && item.product.hasColorVariations && item.color && " • "}
                      {item.product.hasColorVariations && item.color && (
                        <>Color: <span className="inline-block w-3 h-3 rounded-full align-middle border border-border" style={{ backgroundColor: item.color }} /></>
                      )}
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-2">
                        <button onClick={() => updateCartQty(item.product.id, item.size, item.color, item.quantity - 1)} className="w-6 h-6 rounded border border-border flex items-center justify-center hover:bg-muted">
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="text-sm font-medium w-6 text-center">{item.quantity}</span>
                        <button onClick={() => updateCartQty(item.product.id, item.size, item.color, item.quantity + 1)} className="w-6 h-6 rounded border border-border flex items-center justify-center hover:bg-muted">
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>
                      <span className="font-heading font-bold text-sm">৳{(item.product.price * item.quantity).toLocaleString()}</span>
                    </div>
                  </div>
                  <button onClick={() => removeFromCart(item.product.id, item.size, item.color)} className="text-muted-foreground hover:text-destructive p-1 self-start">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
            <div className="p-4 border-t border-border space-y-3">
              <div className="flex justify-between text-lg font-heading font-bold">
                <span>Total</span>
                <span>৳{cartTotal.toLocaleString()}</span>
              </div>
              <Button className="w-full rounded-full font-heading" size="lg" onClick={() => { setCartOpen(false); navigate("/checkout"); }}>
                Proceed to Checkout
              </Button>
            </div>
          </>
        )}
      </div>
    </>
  );
};

export default CartDrawer;
