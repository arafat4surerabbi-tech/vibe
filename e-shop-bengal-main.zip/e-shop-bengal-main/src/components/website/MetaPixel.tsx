import { useEffect, useCallback } from "react";
import { useStore } from "@/contexts/StoreContext";
import { useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

const META_PIXEL_SCRIPT_ID = "meta-pixel-script";
const META_PIXEL_NOSCRIPT_ID = "meta-pixel-noscript";

// Get fbp and fbc cookies for deduplication
const getFbCookies = () => {
  const cookies = document.cookie.split(";").reduce((acc, c) => {
    const [key, val] = c.trim().split("=");
    acc[key] = val;
    return acc;
  }, {} as Record<string, string>);
  return { fbp: cookies._fbp || "", fbc: cookies._fbc || "" };
};

// Generate unique event ID for deduplication between pixel and CAPI
const generateEventId = () =>
  `${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;

const MetaPixel = () => {
  const { storeSettings } = useStore();
  const location = useLocation();

  const pixelId = storeSettings.meta_pixel_id || "";
  const enabled = storeSettings.meta_pixel_enabled === "true";
  const hasCapiToken = !!storeSettings.meta_capi_token;
  const isAdmin = location.pathname.startsWith("/admin");

  // Send server-side event via edge function
  const sendCapiEvent = useCallback(
    async (eventName: string, customData?: Record<string, unknown>) => {
      if (!enabled || !pixelId || isAdmin) return;

      const eventId = generateEventId();
      const { fbp, fbc } = getFbCookies();

      // Fire browser pixel with event_id for deduplication
      if ((window as any).fbq) {
        (window as any).fbq("track", eventName, customData || {}, {
          eventID: eventId,
        });
      }

      if (!hasCapiToken) return;

      // Fire server-side event
      try {
        await supabase.functions.invoke("meta-capi", {
          body: {
            events: [
              {
                event_name: eventName,
                event_time: Math.floor(Date.now() / 1000),
                event_id: eventId,
                event_source_url: window.location.href,
                action_source: "website",
                user_data: { fbp, fbc },
                ...(customData ? { custom_data: customData } : {}),
              },
            ],
          },
        });
      } catch (e) {
        console.warn("CAPI event failed:", e);
      }
    },
    [enabled, pixelId, hasCapiToken, isAdmin]
  );

  // Expose sendCapiEvent globally so checkout/cart can use it
  useEffect(() => {
    (window as any).__metaTrack = sendCapiEvent;
    return () => {
      delete (window as any).__metaTrack;
    };
  }, [sendCapiEvent]);

  // Inject pixel script
  useEffect(() => {
    document.getElementById(META_PIXEL_SCRIPT_ID)?.remove();
    document.getElementById(META_PIXEL_NOSCRIPT_ID)?.remove();

    if (!enabled || !pixelId || isAdmin) return;

    const script = document.createElement("script");
    script.id = META_PIXEL_SCRIPT_ID;
    script.innerHTML = `
      !function(f,b,e,v,n,t,s)
      {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};
      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
      n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t,s)}(window, document,'script',
      'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '${pixelId}');
      fbq('track', 'PageView');
    `;
    document.head.appendChild(script);

    const noscript = document.createElement("noscript");
    noscript.id = META_PIXEL_NOSCRIPT_ID;
    noscript.innerHTML = `<img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=${pixelId}&ev=PageView&noscript=1" />`;
    document.body.appendChild(noscript);

    return () => {
      document.getElementById(META_PIXEL_SCRIPT_ID)?.remove();
      document.getElementById(META_PIXEL_NOSCRIPT_ID)?.remove();
    };
  }, [pixelId, enabled, isAdmin]);

  // Track page views on route change (both pixel + CAPI)
  useEffect(() => {
    if (!enabled || !pixelId || isAdmin) return;

    // Small delay to ensure fbq is loaded
    const timer = setTimeout(() => {
      sendCapiEvent("PageView");
    }, 500);

    return () => clearTimeout(timer);
  }, [location.pathname, enabled, pixelId, isAdmin, sendCapiEvent]);

  return null;
};

export default MetaPixel;
