import { Facebook, Instagram, Youtube, MessageCircle } from "lucide-react";
import { useStore } from "@/contexts/StoreContext";

const SiteFooter = () => {
  const { storeSettings } = useStore();
  return (
    <footer className="bg-foreground text-background mt-12">
      <div className="container mx-auto px-4 lg:px-0 py-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-heading text-lg font-bold mb-4">{storeSettings?.store_name || "Store"}</h3>
            <p className="text-sm opacity-70 font-body leading-relaxed">
              Your premier online fashion destination. Quality traditional & modern clothing.
            </p>
            <div className="flex gap-3 mt-4">
              <Facebook className="h-5 w-5 opacity-70 hover:opacity-100 cursor-pointer" />
              <Instagram className="h-5 w-5 opacity-70 hover:opacity-100 cursor-pointer" />
              <Youtube className="h-5 w-5 opacity-70 hover:opacity-100 cursor-pointer" />
              <MessageCircle className="h-5 w-5 opacity-70 hover:opacity-100 cursor-pointer" />
            </div>
          </div>
          <div>
            <h4 className="font-heading font-semibold mb-3">Quick Links</h4>
            <div className="space-y-2 text-sm opacity-70 font-body">
              <p className="hover:opacity-100 cursor-pointer">About Us</p>
              <p className="hover:opacity-100 cursor-pointer">Contact</p>
              <p className="hover:opacity-100 cursor-pointer">FAQs</p>
              <p className="hover:opacity-100 cursor-pointer">Track Order</p>
            </div>
          </div>
          <div>
            <h4 className="font-heading font-semibold mb-3">Policies</h4>
            <div className="space-y-2 text-sm opacity-70 font-body">
              <p className="hover:opacity-100 cursor-pointer">Return Policy</p>
              <p className="hover:opacity-100 cursor-pointer">Privacy Policy</p>
              <p className="hover:opacity-100 cursor-pointer">Terms of Service</p>
              <p className="hover:opacity-100 cursor-pointer">Shipping Info</p>
            </div>
          </div>
          <div>
            <h4 className="font-heading font-semibold mb-3">Payment & Delivery</h4>
            <div className="flex flex-wrap gap-2 mb-3">
              <span className="bg-background/10 text-xs px-2.5 py-1 rounded-full font-body">COD</span>
            </div>
            <p className="text-xs opacity-60 font-body">Courier: Pathao, Steadfast, Redx</p>
          </div>
        </div>
        <div className="border-t border-background/10 mt-8 pt-6 text-center text-xs opacity-50 font-body">
          © 2026 All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default SiteFooter;
