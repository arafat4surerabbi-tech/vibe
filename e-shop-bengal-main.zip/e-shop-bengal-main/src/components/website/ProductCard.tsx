import { ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { useStore } from "@/contexts/StoreContext";

interface Product {
  id: number;
  name: string;
  price: number;
  originalPrice: number;
  image: string;
  category: string;
  rating: number;
  reviews: number;
  badge: string;
  colors: string[];
  sizes: string[];
  stock: number;
}

const ProductCard = ({ product }: { product: Product }) => {
  const navigate = useNavigate();
  const { addToCart } = useStore();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, product.sizes[0], product.colors[0]);
  };


  return (
    <motion.div
      whileHover={{ y: -4 }}
      className="bg-card rounded-xl overflow-hidden border border-border/50 group cursor-pointer"
      onClick={() => navigate(`/product/${product.id}`)}
    >
      <div className="relative bg-muted flex items-center justify-center overflow-hidden">
        {product.image ? (
          <img src={product.image} alt={product.name} className="w-full h-auto object-contain" />
        ) : (
          <div className="aspect-[3/4] flex items-center justify-center">
            <span className="text-6xl opacity-30">👕</span>
          </div>
        )}
        {product.badge && (
          <Badge className="absolute top-3 left-3 bg-primary text-primary-foreground text-xs font-heading">
            {product.badge}
          </Badge>
        )}
        <div className="absolute bottom-0 left-0 right-0 p-3 flex gap-2 translate-y-full group-hover:translate-y-0 transition-transform">
          <Button size="sm" className="flex-1 rounded-full text-xs font-heading" onClick={handleAddToCart}>
            <ShoppingCart className="h-3.5 w-3.5 mr-1" />
            Add to Cart
          </Button>
        </div>
      </div>

      <div className="p-4">
        <p className="text-xs text-muted-foreground mb-1">{product.category}</p>
        <h3 className="font-heading font-semibold text-sm text-card-foreground line-clamp-2 mb-2">
          {product.name}
        </h3>
        <div className="flex items-center gap-2">
          <span className="font-heading font-bold text-primary text-lg">৳{product.price.toLocaleString()}</span>
          {product.originalPrice > product.price && (
            <span className="text-xs text-muted-foreground line-through">৳{product.originalPrice.toLocaleString()}</span>
          )}
        </div>
        {product.stock < 20 && (
          <p className="text-xs text-destructive mt-2">Only {product.stock} left!</p>
        )}
      </div>
    </motion.div>
  );
};

export default ProductCard;
