import { MessageCircle } from "lucide-react";
import { useStore } from "@/contexts/StoreContext";

const WhatsAppButton = () => {
  const { storeSettings } = useStore();
  const whatsappNumber = storeSettings.whatsapp_number || "8801700000000";

  return (
    <a
      href={`https://wa.me/${whatsappNumber}`}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 bg-success text-success-foreground rounded-full p-3.5 shadow-lg hover:scale-110 transition-transform"
    >
      <MessageCircle className="h-6 w-6" />
    </a>
  );
};

export default WhatsAppButton;
