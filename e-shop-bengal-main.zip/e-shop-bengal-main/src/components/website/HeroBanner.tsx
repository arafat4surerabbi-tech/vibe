import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useStore } from "@/contexts/StoreContext";
import { useNavigate } from "react-router-dom";

const HeroBanner = () => {
  const { banners } = useStore();
  const navigate = useNavigate();
  const activeSlides = banners.filter((b) => b.enabled);
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    if (activeSlides.length <= 1) return;
    const timer = setInterval(() => setCurrent((p) => (p + 1) % activeSlides.length), 5000);
    return () => clearInterval(timer);
  }, [activeSlides.length]);

  if (activeSlides.length === 0) return null;

  const slide = activeSlides[current % activeSlides.length] as any;
  const hasLink = slide.link && slide.link.trim() !== "" && slide.link !== "none";

  const handleBannerClick = () => {
    if (hasLink) navigate(slide.link);
  };

  return (
    <div className="relative overflow-hidden">
      <AnimatePresence mode="wait">
        <motion.div
          key={slide.id}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className={`relative flex flex-col justify-end overflow-hidden ${hasLink ? "cursor-pointer" : ""}`}
          onClick={handleBannerClick}
        >
          {slide.image ? (
            <img src={slide.image} alt={slide.title || "Banner"} className="w-full h-auto block" />
          ) : (
            <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/10" />
          )}
          {slide.title && (
            <div className="absolute bottom-0 left-0 right-0 z-10 p-6 md:p-10 flex flex-col items-center text-center">
              <motion.h1 initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.2 }} className={`font-heading text-3xl md:text-5xl lg:text-6xl font-bold mb-4 drop-shadow-lg ${slide.image ? "text-white" : "text-foreground"}`}>
                {slide.title}
              </motion.h1>
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {activeSlides.length > 1 && (
        <>
          <button onClick={(e) => { e.stopPropagation(); setCurrent((p) => (p - 1 + activeSlides.length) % activeSlides.length); }} className="absolute left-4 top-1/2 -translate-y-1/2 bg-card/80 backdrop-blur-sm rounded-full p-2 shadow-sm hover:bg-card transition-colors z-20">
            <ChevronLeft className="h-5 w-5 text-foreground" />
          </button>
          <button onClick={(e) => { e.stopPropagation(); setCurrent((p) => (p + 1) % activeSlides.length); }} className="absolute right-4 top-1/2 -translate-y-1/2 bg-card/80 backdrop-blur-sm rounded-full p-2 shadow-sm hover:bg-card transition-colors z-20">
            <ChevronRight className="h-5 w-5 text-foreground" />
          </button>
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 z-20">
            {activeSlides.map((_, i) => (
              <button key={i} onClick={(e) => { e.stopPropagation(); setCurrent(i); }} className={`w-2.5 h-2.5 rounded-full transition-all ${i === current ? "bg-primary w-8" : "bg-muted-foreground/30"}`} />
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default HeroBanner;
