import { useState, useEffect } from "react";
import { Zap } from "lucide-react";
import ProductCard from "./ProductCard";
import { useStore } from "@/contexts/StoreContext";

const FlashSale = () => {
  const { products } = useStore();
  const [timeLeft, setTimeLeft] = useState({ hours: 5, minutes: 32, seconds: 15 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        let { hours, minutes, seconds } = prev;
        seconds--;
        if (seconds < 0) { seconds = 59; minutes--; }
        if (minutes < 0) { minutes = 59; hours--; }
        if (hours < 0) { hours = 23; minutes = 59; seconds = 59; }
        return { hours, minutes, seconds };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const pad = (n: number) => n.toString().padStart(2, "0");
  const saleProducts = products.filter((p) => p.originalPrice > p.price).slice(0, 4);

  return (
    <section className="py-8 px-4 lg:px-0">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Zap className="h-6 w-6 text-warning fill-warning" />
          <h2 className="font-heading text-2xl md:text-3xl font-bold text-foreground">Flash Sale</h2>
        </div>
        <div className="flex gap-1.5">
          {[pad(timeLeft.hours), pad(timeLeft.minutes), pad(timeLeft.seconds)].map((v, i) => (
            <span key={i} className="bg-foreground text-background font-heading font-bold text-sm md:text-base px-2.5 py-1 rounded-lg">{v}</span>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {saleProducts.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  );
};

export default FlashSale;
