import ProductCard from "./ProductCard";
import { useStore } from "@/contexts/StoreContext";

const NewArrivals = () => {
  const { products } = useStore();
  const newProducts = products.filter((p) => p.badge === "New" || p.badge === "Trending").slice(0, 4);

  return (
    <section id="new-arrivals" className="py-8 px-4 lg:px-0">
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-heading text-2xl md:text-3xl font-bold text-foreground">New Arrivals</h2>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {newProducts.map((p) => (
          <ProductCard key={`new-${p.id}`} product={p} />
        ))}
      </div>
    </section>
  );
};

export default NewArrivals;
