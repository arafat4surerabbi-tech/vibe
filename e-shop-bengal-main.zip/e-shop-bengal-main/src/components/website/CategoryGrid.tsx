import { motion } from "framer-motion";
import { useStore } from "@/contexts/StoreContext";
import { useNavigate } from "react-router-dom";

const CategoryGrid = () => {
  const { categories } = useStore();
  const navigate = useNavigate();
  const activeCategories = categories.filter((c) => c.enabled);

  if (activeCategories.length === 0) return null;

  return (
    <section className="py-8 px-4 lg:px-0">
      <h2 className="font-heading text-xl md:text-2xl font-bold text-foreground mb-6">Shop by Category</h2>
      <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-4 md:gap-6">
        {activeCategories.map((cat, i) => (
          <motion.div
            key={cat.id}
            initial={{ opacity: 0, scale: 0.9, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="cursor-pointer group flex flex-col items-center gap-3"
            onClick={() => navigate(`/category/${encodeURIComponent(cat.name)}`)}
          >
            {/* Image area — circular, aesthetic */}
            <div className="w-[85%] md:w-[90%] aspect-square rounded-full overflow-hidden shadow-sm border border-border/50 group-hover:border-primary/30 group-hover:shadow-md transition-all duration-300">
              {cat.image ? (
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-secondary">
                  <span className="text-2xl md:text-3xl text-muted-foreground group-hover:scale-110 transition-transform duration-300">
                    {cat.icon || cat.name.charAt(0)}
                  </span>
                </div>
              )}
            </div>
            {/* Category name below image */}
            <h3 className="font-heading font-semibold text-foreground text-xs md:text-sm text-center leading-tight">
              {cat.name}
            </h3>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default CategoryGrid;
