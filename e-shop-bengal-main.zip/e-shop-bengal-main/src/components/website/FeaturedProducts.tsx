import ProductCard from "./ProductCard";
import { useStore } from "@/contexts/StoreContext";

const FeaturedProducts = () => {
  const { products } = useStore();
  const featuredProducts = [...products].slice(-4).reverse();

  return (
    <section className="py-8 px-4 lg:px-0">
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-heading text-2xl md:text-3xl font-bold text-foreground">Featured Products</h2>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {featuredProducts.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  );
};

export default FeaturedProducts;
