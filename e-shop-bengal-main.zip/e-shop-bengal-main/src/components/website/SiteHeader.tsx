import { useState, useEffect } from "react";
import { Search, ShoppingCart, Menu, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useStore } from "@/contexts/StoreContext";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

interface NavLink {
  id: number;
  label: string;
  path: string;
  sort_order: number;
  enabled: boolean;
}

const SiteHeader = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [navLinks, setNavLinks] = useState<NavLink[]>([]);
  const { cartCount, setCartOpen, storeSettings } = useStore();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchLinks = async () => {
      const { data } = await supabase.from("nav_links").select("*").eq("enabled", true).order("sort_order") as any;
      if (data) setNavLinks(data);
    };
    fetchLinks();
  }, []);

  const allLinks = [{ label: "Home", path: "/" }, ...navLinks.map((l) => ({ label: l.label, path: l.path }))];

  return (
    <header className="sticky top-0 z-40 bg-card/95 backdrop-blur-md border-b border-border">
      <div className="container mx-auto">
        <div className="flex items-center justify-between h-14 md:h-16 px-4 lg:px-0">
          <div className="flex items-center gap-3">
            <button className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
            <div className="cursor-pointer flex items-center" onClick={() => navigate("/")}>
              {storeSettings?.site_logo_url ? (
                <img src={storeSettings.site_logo_url} alt={storeSettings?.store_name || "Logo"} className="h-8 md:h-10 object-contain" />
              ) : (
                <h1 className="font-heading text-xl md:text-2xl font-bold text-foreground">{storeSettings?.store_name || "Store"}</h1>
              )}
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            {allLinks.map((link) => (
              <a key={link.label} href={link.path} className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors font-body">
                {link.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <button onClick={() => setSearchOpen(!searchOpen)} className="p-2 rounded-full hover:bg-muted transition-colors">
              <Search className="h-4 w-4 text-foreground" />
            </button>
            <button onClick={() => setCartOpen(true)} className="p-2 rounded-full hover:bg-muted transition-colors relative">
              <ShoppingCart className="h-4 w-4 text-foreground" />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-foreground text-background text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">{cartCount}</span>
              )}
            </button>
          </div>
        </div>

        {searchOpen && (
          <div className="px-4 pb-3 lg:px-0">
            <Input placeholder="Search products..." className="rounded-full bg-muted border-0 font-body" autoFocus />
          </div>
        )}

        {mobileMenuOpen && (
          <nav className="md:hidden px-4 pb-4 space-y-1 border-t border-border pt-2">
            {allLinks.map((link) => (
              <a key={link.label} href={link.path} className="block py-2.5 text-sm font-medium text-muted-foreground hover:text-foreground font-body" onClick={() => setMobileMenuOpen(false)}>
                {link.label}
              </a>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
};

export default SiteHeader;
