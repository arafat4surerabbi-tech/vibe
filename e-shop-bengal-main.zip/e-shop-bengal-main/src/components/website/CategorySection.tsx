import ProductCard from "./ProductCard";
import { useStore } from "@/contexts/StoreContext";

interface CategorySectionProps {
  id: string;
  title: string;
  filterType: "category" | "badge";
  filterValue: string;
}

const CategorySection = ({ id, title, filterType, filterValue }: CategorySectionProps) => {
  const { products } = useStore();
  const filtered = products.filter((p) =>
    filterType === "category"
      ? p.category.toLowerCase() === filterValue.toLowerCase()
      : p.badge.toLowerCase() === filterValue.toLowerCase()
  );

  if (filtered.length === 0) return null;

  return (
    <section id={id} className="py-8 px-4 lg:px-0">
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-heading text-2xl md:text-3xl font-bold text-foreground">{title}</h2>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {filtered.map((p) => (
          <ProductCard key={`${id}-${p.id}`} product={p} />
        ))}
      </div>
    </section>
  );
};

export default CategorySection;
