import { AlertTriangle } from "lucide-react";

interface BlockedPageProps {
  message: string;
}

const BlockedPage = ({ message }: BlockedPageProps) => {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="text-center max-w-md space-y-4">
        <AlertTriangle className="h-16 w-16 text-destructive mx-auto" />
        <h1 className="font-heading text-2xl font-bold text-foreground">Service Unavailable</h1>
        <p className="text-muted-foreground leading-relaxed">{message}</p>
      </div>
    </div>
  );
};

export default BlockedPage;
