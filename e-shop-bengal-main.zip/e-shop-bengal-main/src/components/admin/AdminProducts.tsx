import { useState, useEffect, useCallback } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useStore } from "@/contexts/StoreContext";
import { Search, Plus, Edit, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import MultiImageUpload from "./MultiImageUpload";
import { Switch } from "@/components/ui/switch";

const AdminProducts = () => {
  const { products, categories, refreshProducts } = useStore();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [editProduct, setEditProduct] = useState<any>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [productImages, setProductImages] = useState<string[]>([]);

  const filtered = products.filter((p) => p.name.toLowerCase().includes(search.toLowerCase()));
  const categoryOptions = categories.map((category) => category.name);

  const [hasColorVariations, setHasColorVariations] = useState(false);
  const [selectedSizes, setSelectedSizes] = useState<string[]>(["M"]);
  const availableSizes = ["M", "L", "XL", "XXL", "3XL"];
  const emptyProduct = { id: 0, name: "", price: 0, originalPrice: 0, image: "", category: categoryOptions[0] || "New Arrivals", rating: 0, reviews: 0, badge: "", colors: ["#000000"], sizes: ["M"], stock: 0, description: "", hasColorVariations: false };

  // Load product images when editing
  const loadProductImages = useCallback(async (productId: number) => {
    const { data } = await supabase
      .from("product_images")
      .select("*")
      .eq("product_id", productId)
      .order("sort_order");
    if (data && data.length > 0) {
      setProductImages(data.map((r: any) => r.image_url));
    }
  }, []);

  const saveProductImages = async (productId: number, images: string[]) => {
    // Delete existing images
    await supabase.from("product_images").delete().eq("product_id", productId);
    // Insert new images
    if (images.length > 0) {
      const rows = images.map((url, i) => ({
        product_id: productId,
        image_url: url,
        sort_order: i,
      }));
      await supabase.from("product_images").insert(rows as any);
    }
    // Update main product image to first image
    const mainImage = images[0] || "";
    await supabase.from("products").update({ image: mainImage } as any).eq("id", productId);
  };

  const handleSave = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const mainImage = productImages[0] || "";
    const dbData = {
      name: fd.get("name") as string,
      price: Number(fd.get("price")),
      original_price: Number(fd.get("originalPrice")),
      category: (fd.get("category") as string) || categoryOptions[0] || "New Arrivals",
      stock: Number(fd.get("stock")),
      badge: fd.get("badge") as string,
      sizes: JSON.parse(JSON.stringify(selectedSizes)),
      description: fd.get("description") as string,
      image: mainImage,
      has_color_variations: hasColorVariations,
      rating: editProduct?.rating || 0,
      reviews: editProduct?.reviews || 0,
      colors: JSON.parse(JSON.stringify((fd.get("colors") as string || "#000000").split(",").map((s) => s.trim()).filter(Boolean))),
    };

    if (editProduct?.id) {
      await supabase.from("products").update(dbData as any).eq("id", editProduct.id);
      await saveProductImages(editProduct.id, productImages);
      toast({ title: "Product updated", description: dbData.name });
    } else {
      const { data: inserted } = await supabase.from("products").insert(dbData as any).select("id").single();
      if (inserted) {
        await saveProductImages(inserted.id, productImages);
      }
      toast({ title: "Product added", description: dbData.name });
    }
    await refreshProducts();
    setDialogOpen(false);
    setEditProduct(null);
  };

  const handleDelete = async (id: number) => {
    await supabase.from("product_images").delete().eq("product_id", id);
    await supabase.from("products").delete().eq("id", id);
    await refreshProducts();
    toast({ title: "Product deleted" });
  };

  const openEdit = async (p: any) => {
    setEditProduct(p);
    setProductImages(p.image ? [p.image] : []);
    setHasColorVariations(p.hasColorVariations || false);
    setSelectedSizes(p.sizes || ["M"]);
    setDialogOpen(true);
    // Load additional images from product_images table
    await loadProductImages(p.id);
  };
  const openAdd = () => { setEditProduct(emptyProduct); setProductImages([]); setHasColorVariations(false); setSelectedSizes(["M"]); setDialogOpen(true); };

  return (
    <div className="space-y-4 p-4 lg:p-6">
      <div className="flex items-center justify-between">
        <h2 className="font-heading text-2xl font-bold text-foreground">Product Management</h2>
        <Button size="sm" className="rounded-full font-heading" onClick={openAdd}>
          <Plus className="h-4 w-4 mr-1" /> Add Product
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search products..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 rounded-full bg-muted border-0 font-body" />
      </div>

      <div className="grid gap-3">
        {filtered.map((p) => (
          <Card key={p.id} className="border-border/50">
            <CardContent className="p-3 flex items-center gap-4">
              <div className="w-14 h-14 bg-muted rounded-lg flex items-center justify-center shrink-0 overflow-hidden">
                {p.image ? (
                  <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                ) : (
                  <span className="text-2xl opacity-40">👕</span>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <h3 className="font-heading font-semibold text-sm text-card-foreground truncate">{p.name}</h3>
                  {p.badge && <Badge variant="secondary" className="text-[10px] shrink-0">{p.badge}</Badge>}
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span>{p.category}</span>
                  <span>৳{p.price.toLocaleString()}</span>
                  <span className={p.stock < 20 ? "text-destructive font-medium" : ""}>Stock: {p.stock}</span>
                  <span>{p.sizes.join(", ")}</span>
                </div>
              </div>
              <div className="flex gap-1 shrink-0">
                <Button variant="ghost" size="sm" className="h-8 px-2" onClick={() => openEdit(p)}>
                  <Edit className="h-3.5 w-3.5" />
                </Button>
                <Button variant="ghost" size="sm" className="h-8 px-2 text-destructive hover:text-destructive" onClick={() => handleDelete(p.id)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-heading">{editProduct?.id ? "Edit Product" : "Add Product"}</DialogTitle>
            <DialogDescription>Configure product details, pricing, and images</DialogDescription>
          </DialogHeader>
          <form key={editProduct?.id || "new-product"} onSubmit={handleSave} className="space-y-3 max-h-[70vh] overflow-y-auto pr-1">
            <div><Label>Name</Label><Input name="name" defaultValue={editProduct?.name} required /></div>
            <div>
              <Label>Images</Label>
              <p className="text-xs text-muted-foreground mb-1">First image will be the main product image. Upload multiple photos.</p>
              <MultiImageUpload images={productImages} onChange={setProductImages} folder="products" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Price (৳)</Label><Input name="price" type="number" defaultValue={editProduct?.price} required /></div>
              <div><Label>Original Price (৳)</Label><Input name="originalPrice" type="number" defaultValue={editProduct?.originalPrice} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Category</Label>
                <select name="category" defaultValue={editProduct?.category || categoryOptions[0] || "New Arrivals"} className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm">
                  {categoryOptions.map((option) => (
                    <option key={option} value={option}>{option}</option>
                  ))}
                </select>
              </div>
              <div><Label>Stock</Label><Input name="stock" type="number" defaultValue={editProduct?.stock} required /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Badge</Label><Input name="badge" defaultValue={editProduct?.badge} placeholder="e.g. New, Sale" /></div>
              <div>
                <Label>Sizes</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {availableSizes.map((size) => (
                    <button
                      key={size}
                      type="button"
                      onClick={() => setSelectedSizes((prev) => prev.includes(size) ? prev.filter((s) => s !== size) : [...prev, size])}
                      className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-colors ${selectedSizes.includes(size) ? "bg-primary text-primary-foreground border-primary" : "bg-muted text-muted-foreground border-border hover:border-primary"}`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Label className="text-sm font-medium">Enable Color Variations</Label>
              <Switch checked={hasColorVariations} onCheckedChange={setHasColorVariations} />
            </div>
            {hasColorVariations && (
              <div><Label>Colors (comma-sep hex codes)</Label><Input name="colors" defaultValue={editProduct?.colors?.join(", ")} placeholder="#000000, #FFFFFF, #FF0000" /></div>
            )}
            <div><Label>Description</Label><textarea name="description" defaultValue={editProduct?.description} className="w-full border rounded-lg p-2 text-sm min-h-[80px] bg-background" /></div>
            <Button type="submit" className="w-full rounded-full font-heading">Save Product</Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminProducts;
