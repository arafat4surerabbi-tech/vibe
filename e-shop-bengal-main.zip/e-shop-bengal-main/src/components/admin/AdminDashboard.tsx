import { useMemo } from "react";
import { Package, ShoppingCart, Users, TrendingUp, Truck } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useStore } from "@/contexts/StoreContext";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const statusColor: Record<string, string> = {
  Pending: "bg-warning/10 text-warning border-warning/20",
  Processing: "bg-info/10 text-info border-info/20",
  Confirmed: "bg-accent/10 text-accent border-accent/20",
  Shipped: "bg-accent/10 text-accent border-accent/20",
  Delivered: "bg-success/10 text-success border-success/20",
  Cancelled: "bg-destructive/10 text-destructive border-destructive/20",
};

const AdminDashboard = () => {
  const { products, orders, customers } = useStore();

  const totalSales = useMemo(() => orders.reduce((s, o) => s + o.total, 0), [orders]);
  

  // Build monthly sales from real orders
  const monthlySales = useMemo(() => {
    const months: Record<string, number> = {};
    orders.forEach((o) => {
      const d = new Date(o.date);
      const key = d.toLocaleString("en", { month: "short" });
      months[key] = (months[key] || 0) + o.total;
    });
    const allMonths = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    return allMonths.map((m) => ({ month: m, sales: months[m] || 0 })).filter((m) => m.sales > 0);
  }, [orders]);

  const statCards = [
    { label: "Total Sales", value: `৳${totalSales > 0 ? (totalSales / 1000).toFixed(1) + "K" : "0"}`, icon: TrendingUp, color: "text-admin-accent" },
    { label: "Total Orders", value: orders.length, icon: ShoppingCart, color: "text-admin" },
    { label: "Customers", value: customers.length, icon: Users, color: "text-info" },
    { label: "Products", value: products.length, icon: Package, color: "text-admin-accent" },
  ];

  return (
    <div className="space-y-6 p-4 lg:p-6">
      <h2 className="font-heading text-2xl font-bold text-foreground">Dashboard</h2>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {statCards.map((s) => (
          <Card key={s.label} className="border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2"><s.icon className={`h-5 w-5 ${s.color}`} /></div>
              <p className="font-heading text-2xl font-bold text-card-foreground">{s.value}</p>
              <p className="text-xs text-muted-foreground">{s.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <Card className="md:col-span-2 border-border/50">
          <CardHeader className="pb-2"><CardTitle className="text-base font-heading">Sales Chart</CardTitle></CardHeader>
          <CardContent>
            {monthlySales.length === 0 ? (
              <p className="text-sm text-muted-foreground py-10 text-center">No sales data yet. Orders placed on the website will appear here.</p>
            ) : (
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={monthlySales}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="month" fontSize={12} tickLine={false} />
                  <YAxis fontSize={12} tickLine={false} tickFormatter={(v) => `৳${v / 1000}K`} />
                  <Tooltip formatter={(v: number) => [`৳${v.toLocaleString()}`, "Sales"]} />
                  <Bar dataKey="sales" fill="hsl(var(--admin-accent))" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-heading flex items-center gap-2"><Truck className="h-4 w-4 text-admin-accent" /> Parcel Updates</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 max-h-[280px] overflow-y-auto">
            {orders.length === 0 ? (
              <p className="text-sm text-muted-foreground">No parcel updates yet.</p>
            ) : (
              orders
                .filter((o) => ["Delivered", "Shipped", "Cancelled"].includes(o.status))
                .slice(0, 8)
                .map((o) => (
                  <div key={o.id} className="flex items-center justify-between p-3 rounded-lg border border-border/50 bg-muted/30">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-card-foreground truncate">{o.id}</p>
                      <p className="text-xs text-muted-foreground truncate">{o.customer}</p>
                    </div>
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium border shrink-0 ${statusColor[o.status] || ""}`}>{o.status}</span>
                  </div>
                ))
            )}
            {orders.filter((o) => ["Delivered", "Shipped", "Cancelled"].includes(o.status)).length === 0 && orders.length > 0 && (
              <p className="text-sm text-muted-foreground">No delivered, shipped, or cancelled parcels yet.</p>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="border-border/50">
        <CardHeader className="pb-2"><CardTitle className="text-base font-heading">Recent Orders</CardTitle></CardHeader>
        <CardContent>
          {orders.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">No orders yet. Orders placed from the website will show up here.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-muted-foreground border-b border-border">
                    <th className="pb-2 font-medium">Order ID</th>
                    <th className="pb-2 font-medium hidden md:table-cell">Customer</th>
                    <th className="pb-2 font-medium">Total</th>
                    <th className="pb-2 font-medium">Status</th>
                    <th className="pb-2 font-medium hidden md:table-cell">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.slice(0, 5).map((o) => (
                    <tr key={o.id} className="border-b border-border/50 last:border-0">
                      <td className="py-3 font-medium text-card-foreground">{o.id}</td>
                      <td className="py-3 hidden md:table-cell text-card-foreground">{o.customer}</td>
                      <td className="py-3 text-card-foreground">৳{o.total.toLocaleString()}</td>
                      <td className="py-3">
                        <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium border ${statusColor[o.status] || ""}`}>{o.status}</span>
                      </td>
                      <td className="py-3 hidden md:table-cell text-muted-foreground">{o.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminDashboard;
