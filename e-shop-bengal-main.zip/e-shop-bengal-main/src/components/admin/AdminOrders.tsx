import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useStore, type Order, type CourierConfig } from "@/contexts/StoreContext";
import { Search, Download, Eye, Truck, Send, Loader2, ExternalLink, Settings, Printer } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { printInvoice, printBulkInvoices, downloadInvoice } from "@/utils/generateInvoice";

const statusColor: Record<string, string> = {
  Pending: "bg-[hsl(38,92%,50%)]/10 text-[hsl(38,92%,50%)] border-[hsl(38,92%,50%)]/20",
  Confirmed: "bg-[hsl(145,60%,42%)]/10 text-[hsl(145,60%,42%)] border-[hsl(145,60%,42%)]/20",
  Cancelled: "bg-[hsl(0,84%,60%)]/10 text-[hsl(0,84%,60%)] border-[hsl(0,84%,60%)]/20",
};

const defaultStatuses = ["Pending", "Confirmed", "Cancelled"];

const isCourierReady = (c: CourierConfig) => {
  if (c.id === "pathao") return c.enabled && Boolean(c.apiKey.trim() && c.apiSecret.trim() && c.username?.trim() && c.password?.trim());
  return c.enabled && Boolean(c.apiKey.trim() && c.apiSecret.trim());
};

interface AdminOrdersProps {
  initialStatusFilter?: string;
  onViewOrder?: (orderId: string) => void;
}

const AdminOrders = ({ initialStatusFilter = "all", onViewOrder }: AdminOrdersProps) => {
  const { orders, updateOrderStatus, couriers, refreshOrders, refreshCouriers, storeSettings } = useStore();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>(initialStatusFilter);

  useEffect(() => {
    setStatusFilter(initialStatusFilter);
  }, [initialStatusFilter]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [sendingCourier, setSendingCourier] = useState<string | null>(null);
  const [courierPickerOrder, setCourierPickerOrder] = useState<Order | null>(null);
  const [bulkCourierPicker, setBulkCourierPicker] = useState(false);
  const [bulkSending, setBulkSending] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const readyCouriers = couriers.filter(isCourierReady);
  const allStatuses = Array.from(new Set([...defaultStatuses, ...orders.map((o) => o.status)]));

  const filtered = orders.filter((o) => {
    const matchesSearch = o.id.toLowerCase().includes(search.toLowerCase()) ||
      o.customer.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === "all" || o.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleStatusChange = async (orderId: string, status: string) => {
    await updateOrderStatus(orderId, status);
    toast({ title: "Status updated", description: `${orderId} → ${status}` });
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filtered.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filtered.map((o) => o.id)));
    }
  };

  const handleBulkStatusChange = async (status: string) => {
    const ids = Array.from(selectedIds);
    await Promise.all(ids.map((id) => updateOrderStatus(id, status)));
    toast({ title: "Bulk status updated", description: `${ids.length} orders → ${status}` });
    setSelectedIds(new Set());
  };

  const showSetupMessage = () => {
    toast({
      title: "No courier configured",
      description: "Go to Delivery → Courier Partners to set up at least one courier API.",
      variant: "destructive",
    });
  };

  const handleSendClick = (order: Order) => {
    if (readyCouriers.length === 0) { showSetupMessage(); return; }
    if (readyCouriers.length === 1) { handleSendToCourier(order, readyCouriers[0]); return; }
    setCourierPickerOrder(order);
  };

  const handleBulkSendClick = () => {
    if (readyCouriers.length === 0) { showSetupMessage(); return; }
    if (readyCouriers.length === 1) { handleBulkSendToCourier(readyCouriers[0]); return; }
    setBulkCourierPicker(true);
  };

  const handleBulkSendToCourier = async (courier: CourierConfig) => {
    setBulkCourierPicker(false);
    setBulkSending(true);
    const eligibleOrders = orders.filter((o) => selectedIds.has(o.id) && o.status === "Confirmed" && !o.courierBooking);
    if (eligibleOrders.length === 0) {
      toast({ title: "No eligible orders", description: "Only confirmed orders without courier booking can be sent.", variant: "destructive" });
      setBulkSending(false);
      return;
    }
    let success = 0;
    let failed = 0;
    for (const order of eligibleOrders) {
      try {
        await handleSendToCourier(order, courier);
        success++;
      } catch {
        failed++;
      }
    }
    toast({ title: "Bulk courier send complete", description: `${success} sent, ${failed} failed` });
    setBulkSending(false);
    setSelectedIds(new Set());
  };

  const saveCourierBooking = async (orderId: string, booking: any) => {
    await supabase.from("orders").update({ courier_booking: booking } as any).eq("id", orderId);
    await refreshOrders();
  };

  const handleSendToCourier = async (order: Order, courier: CourierConfig) => {
    setCourierPickerOrder(null);
    setSendingCourier(order.id);
    try {
      if (courier.id === "steadfast") {
        await sendToSteadfast(order, courier);
      } else if (courier.id === "pathao") {
        await sendToPathao(order, courier);
      } else {
        toast({ title: "Not supported", description: `${courier.name} integration is not available yet.`, variant: "destructive" });
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : `Could not send order to ${courier.name}.`;
      toast({ title: "Courier booking failed", description: message, variant: "destructive" });
    } finally {
      setSendingCourier(null);
    }
  };

  const sendToSteadfast = async (order: Order, courier: CourierConfig) => {
    const { data, error } = await supabase.functions.invoke("steadfast-courier", {
      body: {
        action: "create_order",
        api_key: courier.apiKey,
        secret_key: courier.apiSecret,
        invoice: order.id,
        recipient_name: order.customer,
        recipient_phone: order.phone,
        recipient_address: order.address || "N/A",
        cod_amount: order.paymentMethod === "cod" || order.paymentMethod === "cod-(cash-on-delivery)" ? order.total : 0,
        note: `Order ${order.id} - ${order.products?.map((p) => `${p.name} x${p.qty}`).join(", ") || ""}`,
      },
    });

    if (error) {
      const errorData = "context" in error && error.context ? await error.context.json().catch(() => null) : null;
      throw new Error(errorData?.error || error.message || "Failed to send order to Steadfast");
    }

    if (data?.status === 200 && data?.consignment) {
      const c = data.consignment;
      const booking = {
        courierId: "steadfast",
        courierName: "Steadfast",
        trackingId: c.tracking_code,
        consignmentId: String(c.consignment_id),
        trackingLink: c.tracking_link || "",
        status: c.status || "in_review",
        bookedAt: c.created_at || new Date().toISOString(),
      };
      await saveCourierBooking(order.id, booking);
      toast({ title: "Sent to Steadfast", description: `Parcel created: ${c.consignment_id}` });
    } else {
      throw new Error(data?.error || data?.message || "Failed to book Steadfast courier");
    }
  };

  const sendToPathao = async (order: Order, courier: CourierConfig) => {
    const credentials = {
      client_id: courier.apiKey,
      client_secret: courier.apiSecret,
      username: courier.username,
      password: courier.password,
    };

    const { data: storesData, error: storesErr } = await supabase.functions.invoke("pathao-courier", {
      body: { action: "get_stores", ...credentials },
    });

    const storesErrorData = storesErr && "context" in storesErr && storesErr.context
      ? await storesErr.context.json().catch(() => null) : null;

    const stores = Array.isArray(storesData?.data?.data) ? storesData.data.data : [];

    if (storesErr || stores.length === 0) {
      throw new Error(storesErrorData?.error || storesData?.message || "Could not fetch Pathao stores.");
    }

    const savedStoreId = Number(courier.storeId) || 0;
    const resolvedStore =
      stores.find((store: { store_id: number }) => Number(store.store_id) === savedStoreId) ||
      stores.find((store: { is_default_store?: boolean }) => Boolean(store.is_default_store)) ||
      stores[0];

    const storeId = Number(resolvedStore?.store_id) || 0;
    if (!storeId) throw new Error("No valid Pathao store was found.");

    if (String(courier.storeId || "") !== String(storeId)) {
      await supabase.from("courier_configs").update({ store_id: String(storeId) } as any).eq("id", "pathao");
      await refreshCouriers();
    }

    const { data, error } = await supabase.functions.invoke("pathao-courier", {
      body: {
        action: "create_order",
        ...credentials,
        store_id: storeId,
        merchant_order_id: order.id,
        recipient_name: order.customer,
        recipient_phone: order.phone,
        recipient_address: order.address || "N/A",
        recipient_city: 1,
        recipient_zone: 1,
        recipient_area: 1,
        delivery_type: 48,
        item_type: 2,
        item_quantity: order.products?.reduce((s, p) => s + p.qty, 0) || 1,
        item_weight: 0.5,
        amount_to_collect: order.paymentMethod === "cod" || order.paymentMethod === "cod-(cash-on-delivery)" ? order.total : 0,
        special_instruction: `Order ${order.id}`,
      },
    });

    if (error) {
      const errorData = "context" in error && error.context ? await error.context.json().catch(() => null) : null;
      throw new Error(errorData?.error || error.message || "Failed to send order to Pathao");
    }

    if (data?.data || data?.code === 200) {
      const d = data.data;
      const booking = {
        courierId: "pathao",
        courierName: "Pathao",
        trackingId: String(d?.consignment_id || d?.order_id || ""),
        consignmentId: String(d?.consignment_id || ""),
        trackingLink: "",
        status: d?.order_status || "Pending",
        bookedAt: d?.created_at || new Date().toISOString(),
      };
      await saveCourierBooking(order.id, booking);
      toast({ title: "Sent to Pathao", description: `Order created: ${d?.consignment_id || d?.order_id || "Success"}` });
    } else {
      throw new Error(data?.message || data?.error || "Failed to book Pathao courier");
    }
  };

  const getStatusColor = (status: string) => statusColor[status] || "bg-muted text-muted-foreground border-border";

  return (
    <div className="space-y-4 p-4 lg:p-6">
      <div className="flex items-center justify-between">
        <h2 className="font-heading text-2xl font-bold text-foreground">Order Management</h2>
        <Button variant="outline" size="sm" className="rounded-full font-heading">
          <Download className="h-4 w-4 mr-1" /> Export
        </Button>
      </div>

      <div className="flex items-center gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search orders..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 rounded-full bg-muted border-0 font-body" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[150px] rounded-full font-body">
            <SelectValue placeholder="All Statuses" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            {allStatuses.map((s) => (
              <SelectItem key={s} value={s}>{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {orders.length === 0 ? (
        <Card className="border-border/50">
          <CardContent className="p-8 text-center">
            <p className="text-muted-foreground">No orders yet. Orders placed from the website will appear here.</p>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-border/50">
          <CardContent className="p-0">
            {selectedIds.size > 0 && (
              <div className="flex items-center gap-3 px-4 py-2.5 bg-primary/5 border-b border-border">
                <span className="text-sm font-medium text-foreground">{selectedIds.size} selected</span>
                <Select onValueChange={(v) => handleBulkStatusChange(v)}>
                  <SelectTrigger className="h-7 w-[160px] rounded-full text-xs font-medium">
                    <SelectValue placeholder="Change status..." />
                  </SelectTrigger>
                  <SelectContent>
                    {allStatuses.map((s) => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button variant="outline" size="sm" className="h-7 text-xs rounded-full gap-1" onClick={() => {
                  const selected = orders.filter((o) => selectedIds.has(o.id));
                  printBulkInvoices(selected, storeSettings);
                }}>
                  <Printer className="h-3 w-3" /> Print Invoices
                </Button>
                <Button variant="outline" size="sm" className="h-7 text-xs rounded-full gap-1 border-primary/30 text-primary hover:bg-primary/10"
                  onClick={handleBulkSendClick}
                  disabled={bulkSending}>
                  {bulkSending ? (
                    <><Loader2 className="h-3 w-3 animate-spin" /> Sending...</>
                  ) : (
                    <><Send className="h-3 w-3" /> Send to Courier</>
                  )}
                </Button>
                <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setSelectedIds(new Set())}>Clear</Button>
              </div>
            )}
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-muted-foreground border-b border-border bg-muted/50">
                    <th className="p-3 w-10">
                      <Checkbox
                        checked={filtered.length > 0 && selectedIds.size === filtered.length}
                        onCheckedChange={toggleSelectAll}
                      />
                    </th>
                    <th className="p-3 font-medium">Order ID</th>
                    <th className="p-3 font-medium">Customer</th>
                    <th className="p-3 font-medium hidden md:table-cell">Phone</th>
                    <th className="p-3 font-medium">Total</th>
                    <th className="p-3 font-medium">Status</th>
                    <th className="p-3 font-medium">Courier</th>
                    <th className="p-3 font-medium">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((o) => (
                    <tr key={o.id} className={`border-b border-border/50 last:border-0 hover:bg-muted/30 ${selectedIds.has(o.id) ? "bg-primary/5" : ""}`}>
                      <td className="p-3">
                        <Checkbox
                          checked={selectedIds.has(o.id)}
                          onCheckedChange={() => toggleSelect(o.id)}
                        />
                      </td>
                      <td className="p-3 font-medium text-primary cursor-pointer hover:underline" onClick={() => onViewOrder?.(o.id)}>{o.id}</td>
                      <td className="p-3 text-card-foreground">{o.customer}</td>
                      <td className="p-3 hidden md:table-cell text-muted-foreground">{o.phone}</td>
                      <td className="p-3 font-medium text-card-foreground">৳{o.total.toLocaleString()}</td>
                      <td className="p-3">
                        <Select value={o.status} onValueChange={(v) => handleStatusChange(o.id, v)}>
                          <SelectTrigger className={`h-7 w-[130px] rounded-full text-xs font-medium border ${getStatusColor(o.status)}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {allStatuses.map((s) => (
                              <SelectItem key={s} value={s}>{s}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="p-3">
                        {o.courierBooking ? (
                          <div className="flex items-center gap-1">
                            <Badge variant="secondary" className="text-xs gap-1 font-mono cursor-pointer hover:bg-accent" onClick={() => setSelectedOrder(o)}>
                              <Truck className="h-3 w-3" />
                              {o.courierBooking.courierName}: {o.courierBooking.consignmentId || o.courierBooking.trackingId}
                            </Badge>
                            {o.courierBooking.trackingLink && (
                              <a href={o.courierBooking.trackingLink} target="_blank" rel="noopener noreferrer" className="text-primary hover:text-primary/80">
                                <ExternalLink className="h-3 w-3" />
                              </a>
                            )}
                          </div>
                        ) : o.status === "Confirmed" ? (
                          <Button
                            variant="outline" size="sm"
                            className="h-7 px-3 gap-1.5 text-xs rounded-full border-primary/30 text-primary hover:bg-primary/10"
                            onClick={() => handleSendClick(o)}
                            disabled={sendingCourier === o.id}
                          >
                            {sendingCourier === o.id ? (
                              <><Loader2 className="h-3 w-3 animate-spin" /> Sending...</>
                            ) : readyCouriers.length > 0 ? (
                              <><Send className="h-3 w-3" /> Send to Courier</>
                            ) : (
                              <><Settings className="h-3 w-3" /> Setup Courier</>
                            )}
                          </Button>
                        ) : (
                          <span className="text-xs text-muted-foreground">—</span>
                        )}
                      </td>
                      <td className="p-3 flex gap-1">
                        <Button variant="ghost" size="sm" className="h-7 px-2" onClick={() => onViewOrder?.(o.id)}>
                          <Eye className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="sm" className="h-7 px-2" onClick={() => downloadInvoice(o, storeSettings)} title="Download Invoice">
                          <Printer className="h-3.5 w-3.5" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={!!courierPickerOrder} onOpenChange={() => setCourierPickerOrder(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle className="font-heading">Choose Courier</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">Select which courier to send order <strong>{courierPickerOrder?.id}</strong> to:</p>
          <div className="space-y-2">
            {readyCouriers.map((c) => (
              <Button key={c.id} variant="outline" className="w-full justify-start gap-2 rounded-full font-heading"
                onClick={() => courierPickerOrder && handleSendToCourier(courierPickerOrder, c)}>
                <Truck className="h-4 w-4" /> {c.name}
              </Button>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={bulkCourierPicker} onOpenChange={() => setBulkCourierPicker(false)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle className="font-heading">Choose Courier for Bulk Send</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">Send <strong>{orders.filter((o) => selectedIds.has(o.id) && o.status === "Confirmed" && !o.courierBooking).length}</strong> confirmed orders to:</p>
          <div className="space-y-2">
            {readyCouriers.map((c) => (
              <Button key={c.id} variant="outline" className="w-full justify-start gap-2 rounded-full font-heading"
                onClick={() => handleBulkSendToCourier(c)}>
                <Truck className="h-4 w-4" /> {c.name}
              </Button>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={!!selectedOrder} onOpenChange={() => setSelectedOrder(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle className="font-heading">Order {selectedOrder?.id}</DialogTitle></DialogHeader>
          {selectedOrder && (
            <div className="space-y-4 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div><p className="text-muted-foreground">Customer</p><p className="font-medium">{selectedOrder.customer}</p></div>
                <div><p className="text-muted-foreground">Phone</p><p className="font-medium">{selectedOrder.phone}</p></div>
                <div><p className="text-muted-foreground">Email</p><p className="font-medium">{selectedOrder.email || "N/A"}</p></div>
                <div><p className="text-muted-foreground">Date</p><p className="font-medium">{selectedOrder.date}</p></div>
                <div><p className="text-muted-foreground">Address</p><p className="font-medium">{selectedOrder.address || "N/A"}</p></div>
                <div><p className="text-muted-foreground">Status</p><Badge className={getStatusColor(selectedOrder.status)}>{selectedOrder.status}</Badge></div>
              </div>

              {selectedOrder.courierBooking && (
                <div className="p-3 rounded-lg bg-muted/50 border border-border/50">
                  <p className="font-medium mb-2 flex items-center gap-1"><Truck className="h-3.5 w-3.5" /> {selectedOrder.courierBooking.courierName} Courier</p>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div><span className="text-muted-foreground">Consignment ID:</span> <span className="font-mono font-medium">{selectedOrder.courierBooking.consignmentId || "—"}</span></div>
                    <div><span className="text-muted-foreground">Tracking Code:</span> <span className="font-mono font-medium">{selectedOrder.courierBooking.trackingId}</span></div>
                    <div><span className="text-muted-foreground">Status:</span> <Badge variant="secondary" className="text-xs">{selectedOrder.courierBooking.status}</Badge></div>
                    <div><span className="text-muted-foreground">Booked:</span> {new Date(selectedOrder.courierBooking.bookedAt).toLocaleString()}</div>
                  </div>
                  {selectedOrder.courierBooking.trackingLink && (
                    <a href={selectedOrder.courierBooking.trackingLink} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 mt-2 text-xs text-primary hover:underline">
                      <ExternalLink className="h-3 w-3" /> Track Parcel
                    </a>
                  )}
                </div>
              )}

              {selectedOrder.status === "Confirmed" && !selectedOrder.courierBooking && (
                <Button className="w-full rounded-full font-heading gap-2"
                  onClick={() => { setSelectedOrder(null); handleSendClick(selectedOrder); }}
                  disabled={sendingCourier === selectedOrder.id}>
                  {sendingCourier === selectedOrder.id ? (
                    <><Loader2 className="h-4 w-4 animate-spin" /> Sending to Courier...</>
                  ) : readyCouriers.length > 0 ? (
                    <><Send className="h-4 w-4" /> Send to Courier</>
                  ) : (
                    <><Settings className="h-4 w-4" /> Setup Courier First</>
                  )}
                </Button>
              )}

              {selectedOrder.products && selectedOrder.products.length > 0 && (
                <div>
                  <p className="font-medium mb-2">Products</p>
                  {selectedOrder.products.map((p, i) => (
                    <div key={i} className="flex justify-between py-1.5 border-b border-border/50 last:border-0">
                      <span>{p.name} × {p.qty}</span>
                      <span className="font-medium">৳{(p.price * p.qty).toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              )}
              <div className="flex justify-between font-heading font-bold text-base border-t border-border pt-3">
                <span>Total</span><span>৳{selectedOrder.total.toLocaleString()}</span>
              </div>
              <Button variant="outline" className="w-full rounded-full font-heading gap-2 mt-2" onClick={() => downloadInvoice(selectedOrder, storeSettings)}>
                <Printer className="h-4 w-4" /> Download Invoice
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminOrders;
