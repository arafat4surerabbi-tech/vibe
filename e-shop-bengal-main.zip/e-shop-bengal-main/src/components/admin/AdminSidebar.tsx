import { useState } from "react";
import {
  LayoutDashboard, Package, ShoppingCart, Tag, Users, CreditCard, Truck, Settings, Image, Grid3X3, ChevronDown, Navigation
} from "lucide-react";
import { useStore } from "@/contexts/StoreContext";

const menuItems = [
  { label: "Dashboard", icon: LayoutDashboard, id: "dashboard" },
  { label: "Orders", icon: ShoppingCart, id: "orders" },
  { label: "Products", icon: Package, id: "products" },
  { label: "Banners", icon: Image, id: "banners" },
  { label: "Categories", icon: Grid3X3, id: "categories" },
  { label: "Navigation", icon: Navigation, id: "navigation" },
  { label: "Promotions", icon: Tag, id: "promotions" },
  { label: "Customers", icon: Users, id: "customers" },
  { label: "Payments", icon: CreditCard, id: "payments" },
  { label: "Delivery", icon: Truck, id: "delivery" },
  { label: "Settings", icon: Settings, id: "settings" },
];

const defaultStatuses = ["Pending", "Confirmed", "Cancelled"];

interface AdminSidebarProps {
  activeSection: string;
  onSectionChange: (id: string) => void;
  orderStatusFilter?: string;
  onOrderStatusFilter?: (status: string) => void;
}

const AdminSidebar = ({ activeSection, onSectionChange, orderStatusFilter, onOrderStatusFilter }: AdminSidebarProps) => {
  const { orders } = useStore();
  const [ordersExpanded, setOrdersExpanded] = useState(false);

  const allStatuses = Array.from(new Set([...defaultStatuses, ...orders.map((o) => o.status)]));

  const statusCounts: Record<string, number> = {};
  orders.forEach((o) => {
    statusCounts[o.status] = (statusCounts[o.status] || 0) + 1;
  });

  const pendingCount = statusCounts["Pending"] || 0;

  return (
    <aside className="w-full md:w-56 shrink-0 bg-admin text-admin-foreground border-r border-border md:min-h-[calc(100vh-120px)]">
      <div className="p-4 border-b border-admin-accent/30">
        <h2 className="font-heading text-lg font-bold text-admin-foreground">Admin Panel</h2>
      </div>
      <nav className="p-2">
        <div className="flex md:flex-col gap-1 overflow-x-auto md:overflow-visible pb-2 md:pb-0">
          {menuItems.map((item) => {
            if (item.id === "orders") {
              return (
                <div key={item.id} className="flex flex-col">
                  <button
                    onClick={() => {
                      onSectionChange("orders");
                      onOrderStatusFilter?.("all");
                      setOrdersExpanded((prev) => !prev);
                    }}
                    className={`flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-body whitespace-nowrap transition-colors ${
                      activeSection === "orders"
                        ? "bg-admin-accent text-admin-accent-foreground font-medium"
                        : "text-admin-foreground/60 hover:bg-admin-accent/20 hover:text-admin-foreground"
                    }`}
                  >
                    <item.icon className="h-4 w-4 shrink-0" />
                    <span>Orders</span>
                    {pendingCount > 0 && (
                      <span className="ml-auto mr-1 bg-admin-accent text-admin-accent-foreground text-[10px] font-bold rounded-full px-1.5 py-0.5">
                        {pendingCount}
                      </span>
                    )}
                    <ChevronDown className={`h-3.5 w-3.5 shrink-0 transition-transform ${ordersExpanded ? "rotate-180" : ""}`} />
                  </button>
                  {ordersExpanded && (
                    <div className="hidden md:flex flex-col gap-0.5 ml-6 mt-0.5">
                      <button
                        onClick={() => { onSectionChange("orders"); onOrderStatusFilter?.("all"); }}
                        className={`text-left text-xs px-3 py-1.5 rounded-md transition-colors ${
                          activeSection === "orders" && orderStatusFilter === "all"
                            ? "bg-admin-accent/50 text-admin-accent-foreground font-medium"
                            : "text-admin-foreground/50 hover:text-admin-foreground hover:bg-admin-accent/10"
                        }`}
                      >
                        All Orders ({orders.length})
                      </button>
                      {allStatuses.map((status) => (
                        <button
                          key={status}
                          onClick={() => { onSectionChange("orders"); onOrderStatusFilter?.(status); }}
                          className={`text-left text-xs px-3 py-1.5 rounded-md transition-colors flex items-center justify-between ${
                            activeSection === "orders" && orderStatusFilter === status
                              ? "bg-admin-accent/50 text-admin-accent-foreground font-medium"
                              : "text-admin-foreground/50 hover:text-admin-foreground hover:bg-admin-accent/10"
                          }`}
                        >
                          <span>{status}</span>
                          {(statusCounts[status] || 0) > 0 && (
                            <span className="text-[10px] font-mono opacity-70">{statusCounts[status]}</span>
                          )}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            }

            return (
              <button
                key={item.id}
                onClick={() => onSectionChange(item.id)}
                className={`flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-body whitespace-nowrap transition-colors ${
                  activeSection === item.id
                    ? "bg-admin-accent text-admin-accent-foreground font-medium"
                    : "text-admin-foreground/60 hover:bg-admin-accent/20 hover:text-admin-foreground"
                }`}
              >
                <item.icon className="h-4 w-4 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </aside>
  );
};

export default AdminSidebar;
