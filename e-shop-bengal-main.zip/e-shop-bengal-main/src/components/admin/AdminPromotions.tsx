import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useStore } from "@/contexts/StoreContext";
import { Plus, Edit, Trash2, Tag } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

const AdminPromotions = () => {
  const { coupons, refreshCoupons } = useStore();
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editCoupon, setEditCoupon] = useState<any>(null);

  const emptyCoupon = { id: "", code: "", discount: 0, type: "percent" as const, minOrder: 0, maxUses: 100, usedCount: 0, expiry: "", active: true };

  const handleSave = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const dbData = {
      code: (fd.get("code") as string).toUpperCase(),
      discount: Number(fd.get("discount")),
      type: fd.get("type") as string,
      min_order: Number(fd.get("minOrder")),
      max_uses: Number(fd.get("maxUses")),
      expiry: fd.get("expiry") as string,
      active: true,
      used_count: editCoupon?.usedCount || 0,
    };

    if (editCoupon?.id) {
      await supabase.from("coupons").update(dbData as any).eq("id", editCoupon.id);
      toast({ title: "Coupon updated" });
    } else {
      await supabase.from("coupons").insert({ ...dbData, id: `CP${Date.now()}` } as any);
      toast({ title: "Coupon created", description: dbData.code });
    }
    await refreshCoupons();
    setDialogOpen(false);
    setEditCoupon(null);
  };

  const toggleActive = async (id: string, currentActive: boolean) => {
    await supabase.from("coupons").update({ active: !currentActive } as any).eq("id", id);
    await refreshCoupons();
  };

  const deleteCoupon = async (id: string) => {
    await supabase.from("coupons").delete().eq("id", id);
    await refreshCoupons();
    toast({ title: "Coupon deleted" });
  };

  return (
    <div className="space-y-4 p-4 lg:p-6">
      <div className="flex items-center justify-between">
        <h2 className="font-heading text-2xl font-bold text-foreground">Promotions & Coupons</h2>
        <Button size="sm" className="rounded-full font-heading" onClick={() => { setEditCoupon(emptyCoupon); setDialogOpen(true); }}>
          <Plus className="h-4 w-4 mr-1" /> Add Coupon
        </Button>
      </div>

      <div className="grid gap-3">
        {coupons.map((c) => (
          <Card key={c.id} className="border-border/50">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 bg-muted rounded-lg flex items-center justify-center shrink-0">
                <Tag className="h-5 w-5 text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-heading font-bold text-card-foreground">{c.code}</h3>
                  <Badge variant={c.active ? "default" : "secondary"} className="text-[10px]">{c.active ? "Active" : "Inactive"}</Badge>
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
                  <span>{c.type === "percent" ? `${c.discount}% off` : `৳${c.discount} off`}</span>
                  <span>Min: ৳{c.minOrder}</span>
                  <span>Used: {c.usedCount}/{c.maxUses}</span>
                  <span>Expires: {c.expiry}</span>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Switch checked={c.active} onCheckedChange={() => toggleActive(c.id, c.active)} />
                <Button variant="ghost" size="sm" className="h-8 px-2" onClick={() => { setEditCoupon(c); setDialogOpen(true); }}>
                  <Edit className="h-3.5 w-3.5" />
                </Button>
                <Button variant="ghost" size="sm" className="h-8 px-2 text-destructive" onClick={() => deleteCoupon(c.id)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-heading">{editCoupon?.id ? "Edit Coupon" : "New Coupon"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSave} className="space-y-3">
            <div><Label>Coupon Code</Label><Input name="code" defaultValue={editCoupon?.code} required /></div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Type</Label>
                <Select name="type" defaultValue={editCoupon?.type || "percent"}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percent">Percentage</SelectItem>
                    <SelectItem value="fixed">Fixed Amount</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Discount</Label><Input name="discount" type="number" defaultValue={editCoupon?.discount} required /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Min Order (৳)</Label><Input name="minOrder" type="number" defaultValue={editCoupon?.minOrder} /></div>
              <div><Label>Max Uses</Label><Input name="maxUses" type="number" defaultValue={editCoupon?.maxUses} /></div>
            </div>
            <div><Label>Expiry Date</Label><Input name="expiry" type="date" defaultValue={editCoupon?.expiry} required /></div>
            <Button type="submit" className="w-full rounded-full font-heading">Save Coupon</Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminPromotions;
