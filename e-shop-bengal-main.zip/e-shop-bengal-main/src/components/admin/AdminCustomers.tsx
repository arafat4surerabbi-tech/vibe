import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useStore } from "@/contexts/StoreContext";
import { Search, Eye, Ban, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

const AdminCustomers = () => {
  const { customers, refreshCustomers } = useStore();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);

  const filtered = customers.filter((c) =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.phone.includes(search)
  );

  const toggleBlock = async (id: string, currentStatus: string) => {
    const newStatus = currentStatus === "active" ? "blocked" : "active";
    await supabase.from("customers").update({ status: newStatus } as any).eq("id", id);
    await refreshCustomers();
    toast({ title: "Customer status updated" });
  };

  return (
    <div className="space-y-4 p-4 lg:p-6">
      <h2 className="font-heading text-2xl font-bold text-foreground">Customer Management</h2>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search by name or phone..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 rounded-full bg-muted border-0 font-body" />
      </div>

      <Card className="border-border/50">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-muted-foreground border-b border-border bg-muted/50">
                  <th className="p-3 font-medium">Name</th>
                  <th className="p-3 font-medium hidden md:table-cell">Email</th>
                  <th className="p-3 font-medium">Phone</th>
                  <th className="p-3 font-medium hidden md:table-cell">Orders</th>
                  <th className="p-3 font-medium">Spent</th>
                  <th className="p-3 font-medium">Status</th>
                  <th className="p-3 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((c) => (
                  <tr key={c.id} className="border-b border-border/50 last:border-0 hover:bg-muted/30">
                    <td className="p-3 font-medium text-card-foreground">{c.name}</td>
                    <td className="p-3 hidden md:table-cell text-muted-foreground">{c.email}</td>
                    <td className="p-3 text-muted-foreground">{c.phone}</td>
                    <td className="p-3 hidden md:table-cell text-card-foreground">{c.orders}</td>
                    <td className="p-3 font-medium text-card-foreground">৳{c.totalSpent.toLocaleString()}</td>
                    <td className="p-3">
                      <Badge variant={c.status === "active" ? "default" : "destructive"} className="text-xs">
                        {c.status}
                      </Badge>
                    </td>
                    <td className="p-3 flex gap-1">
                      <Button variant="ghost" size="sm" className="h-7 px-2" onClick={() => setSelectedCustomer(c)}>
                        <Eye className="h-3.5 w-3.5" />
                      </Button>
                      <Button variant="ghost" size="sm" className="h-7 px-2" onClick={() => toggleBlock(c.id, c.status)}>
                        {c.status === "active" ? <Ban className="h-3.5 w-3.5 text-destructive" /> : <CheckCircle className="h-3.5 w-3.5 text-success" />}
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={!!selectedCustomer} onOpenChange={() => setSelectedCustomer(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-heading">Customer Details</DialogTitle>
          </DialogHeader>
          {selectedCustomer && (
            <div className="space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div><p className="text-muted-foreground">Name</p><p className="font-medium">{selectedCustomer.name}</p></div>
                <div><p className="text-muted-foreground">Email</p><p className="font-medium">{selectedCustomer.email}</p></div>
                <div><p className="text-muted-foreground">Phone</p><p className="font-medium">{selectedCustomer.phone}</p></div>
                <div><p className="text-muted-foreground">Address</p><p className="font-medium">{selectedCustomer.address}</p></div>
                <div><p className="text-muted-foreground">Total Orders</p><p className="font-medium">{selectedCustomer.orders}</p></div>
                <div><p className="text-muted-foreground">Lifetime Value</p><p className="font-medium">৳{selectedCustomer.totalSpent.toLocaleString()}</p></div>
                <div><p className="text-muted-foreground">Joined</p><p className="font-medium">{selectedCustomer.joinDate}</p></div>
                <div><p className="text-muted-foreground">Status</p><Badge variant={selectedCustomer.status === "active" ? "default" : "destructive"}>{selectedCustomer.status}</Badge></div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminCustomers;
