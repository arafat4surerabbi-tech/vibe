import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { useStore } from "@/contexts/StoreContext";
import { CreditCard, DollarSign, TrendingUp } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

const AdminPayments = () => {
  const { orders } = useStore();
  const { toast } = useToast();
  const [methods, setMethods] = useState([
    { id: "cod", name: "Cash on Delivery", enabled: true },
  ]);

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.from("store_settings").select("*").eq("key", "payment_methods").maybeSingle();
      if (data?.value) {
        try {
          const saved = JSON.parse(data.value);
          setMethods((prev) => prev.map((m) => {
            const s = saved.find((x: any) => x.id === m.id);
            return s ? { ...m, enabled: s.enabled } : m;
          }));
        } catch {}
      }
    };
    load();
  }, []);

  const toggleMethod = async (id: string) => {
    const updated = methods.map((m) => m.id === id ? { ...m, enabled: !m.enabled } : m);
    setMethods(updated);
    const value = JSON.stringify(updated.map((m) => ({ id: m.id, enabled: m.enabled })));
    const { data: existing } = await supabase.from("store_settings").select("id").eq("key", "payment_methods").maybeSingle();
    if (existing) {
      await supabase.from("store_settings").update({ value } as any).eq("key", "payment_methods");
    } else {
      await supabase.from("store_settings").insert({ key: "payment_methods", value } as any);
    }
    toast({ title: `${methods.find(m => m.id === id)?.name} ${updated.find(m => m.id === id)?.enabled ? 'enabled' : 'disabled'}` });
  };

  const totalRevenue = orders.reduce((s, o) => s + o.total, 0);
  const codOrders = orders.filter((o) => o.status !== "Cancelled").length;
  const deliveredRevenue = orders.filter((o) => o.status === "Delivered").reduce((s, o) => s + o.total, 0);

  return (
    <div className="space-y-4 p-4 lg:p-6">
      <h2 className="font-heading text-2xl font-bold text-foreground">Payments & Finance</h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-2"><DollarSign className="h-5 w-5 text-success" /><span className="text-sm text-muted-foreground">Total Revenue</span></div>
            <p className="font-heading text-2xl font-bold">৳{totalRevenue.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-2"><TrendingUp className="h-5 w-5 text-info" /><span className="text-sm text-muted-foreground">Collected</span></div>
            <p className="font-heading text-2xl font-bold">৳{deliveredRevenue.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-2"><CreditCard className="h-5 w-5 text-primary" /><span className="text-sm text-muted-foreground">Total Transactions</span></div>
            <p className="font-heading text-2xl font-bold">{codOrders}</p>
          </CardContent>
        </Card>
      </div>

      <Card className="border-border/50">
        <CardHeader><CardTitle className="font-heading text-base">Payment Methods</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          {methods.map((m) => (
            <div key={m.id} className="flex items-center justify-between p-3 rounded-lg border border-border/50">
              <div className="flex items-center gap-3">
                <CreditCard className="h-5 w-5 text-muted-foreground" />
                <span className="font-medium text-sm">{m.name}</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant={m.enabled ? "default" : "secondary"} className="text-xs">{m.enabled ? "Enabled" : "Disabled"}</Badge>
                <Switch checked={m.enabled} onCheckedChange={() => toggleMethod(m.id)} />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardHeader><CardTitle className="font-heading text-base">Recent Transactions</CardTitle></CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-muted-foreground border-b border-border bg-muted/50">
                  <th className="p-3 font-medium">Order</th>
                  <th className="p-3 font-medium">Customer</th>
                  <th className="p-3 font-medium">Amount</th>
                  <th className="p-3 font-medium">Status</th>
                  <th className="p-3 font-medium">Date</th>
                </tr>
              </thead>
              <tbody>
                {orders.slice(0, 10).map((o) => (
                  <tr key={o.id} className="border-b border-border/50 last:border-0">
                    <td className="p-3 font-medium">{o.id}</td>
                    <td className="p-3 text-muted-foreground">{o.customer}</td>
                    <td className="p-3 font-medium">৳{o.total.toLocaleString()}</td>
                    <td className="p-3"><Badge variant={o.status === "Delivered" ? "default" : "secondary"} className="text-xs">{o.status}</Badge></td>
                    <td className="p-3 text-muted-foreground">{o.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminPayments;
