import { useState } from "react";
import AdminSidebar from "./AdminSidebar";
import AdminDashboard from "./AdminDashboard";
import AdminOrders from "./AdminOrders";
import AdminOrderDetail from "./AdminOrderDetail";
import AdminProducts from "./AdminProducts";
import AdminPromotions from "./AdminPromotions";
import AdminCustomers from "./AdminCustomers";
import AdminPayments from "./AdminPayments";
import AdminDelivery from "./AdminDelivery";
import AdminSettings from "./AdminSettings";
import AdminBanners from "./AdminBanners";
import AdminCategories from "./AdminCategories";
import AdminNavLinks from "./AdminNavLinks";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";

// Admin Panel with Order Detail view
const AdminPanel = () => {
  const [activeSection, setActiveSection] = useState("dashboard");
  const [orderStatusFilter, setOrderStatusFilter] = useState("all");
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const { signOut } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await signOut();
    navigate("/admin/login");
  };

  const handleViewOrder = (orderId: string) => {
    setSelectedOrderId(orderId);
    setActiveSection("order-detail");
  };

  const renderSection = () => {
    switch (activeSection) {
      case "dashboard": return <AdminDashboard />;
      case "orders": return <AdminOrders initialStatusFilter={orderStatusFilter} onViewOrder={handleViewOrder} />;
      case "order-detail": return selectedOrderId ? (
        <AdminOrderDetail orderId={selectedOrderId} onBack={() => { setSelectedOrderId(null); setActiveSection("orders"); }} />
      ) : <AdminOrders initialStatusFilter={orderStatusFilter} onViewOrder={handleViewOrder} />;
      case "products": return <AdminProducts />;
      case "banners": return <AdminBanners />;
      case "categories": return <AdminCategories />;
      case "navigation": return <AdminNavLinks />;
      case "promotions": return <AdminPromotions />;
      case "customers": return <AdminCustomers />;
      case "payments": return <AdminPayments />;
      case "delivery": return <AdminDelivery />;
      case "settings": return <AdminSettings />;
      default: return <AdminDashboard />;
    }
  };

  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <AdminSidebar
        activeSection={activeSection}
        onSectionChange={(section) => { setActiveSection(section); setSelectedOrderId(null); }}
        orderStatusFilter={orderStatusFilter}
        onOrderStatusFilter={setOrderStatusFilter}
      />
      <div className="flex-1 min-w-0 bg-admin-secondary">
        <div className="flex justify-end p-2 border-b border-admin-accent/20 bg-white">
          <Button variant="ghost" size="sm" onClick={handleLogout} className="text-muted-foreground hover:text-admin-accent">
            <LogOut className="h-4 w-4 mr-1" /> Logout
          </Button>
        </div>
        {renderSection()}
      </div>
    </div>
  );
};

export default AdminPanel;
