import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Plus, Edit, Trash2 } from "lucide-react";
import { useStore } from "@/contexts/StoreContext";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import ImageUpload from "./ImageUpload";

const AdminCategories = () => {
  const { categories, refreshCategories } = useStore();
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editCat, setEditCat] = useState<any>(null);
  const [imageUrl, setImageUrl] = useState("");

  const handleSave = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const dbData = {
      name: fd.get("name") as string,
      icon: "",
      image: imageUrl,
      count: Number(fd.get("count") || 0),
      enabled: true,
    };

    if (editCat?.id) {
      await supabase.from("categories").update(dbData as any).eq("id", editCat.id);
      toast({ title: "Category updated" });
    } else {
      await supabase.from("categories").insert(dbData as any);
      toast({ title: "Category added" });
    }
    await refreshCategories();
    setDialogOpen(false);
    setEditCat(null);
    setImageUrl("");
  };

  const deleteCat = async (id: number) => {
    await supabase.from("categories").delete().eq("id", id);
    await refreshCategories();
    toast({ title: "Category deleted" });
  };

  const toggleCat = async (id: number, currentEnabled: boolean) => {
    await supabase.from("categories").update({ enabled: !currentEnabled } as any).eq("id", id);
    await refreshCategories();
  };

  const openEdit = (cat: any) => {
    setEditCat(cat);
    setImageUrl(cat.image || "");
    setDialogOpen(true);
  };

  const openAdd = () => {
    setEditCat(null);
    setImageUrl("");
    setDialogOpen(true);
  };

  return (
    <div className="space-y-4 p-4 lg:p-6">
      <div className="flex items-center justify-between">
        <h2 className="font-heading text-2xl font-bold text-foreground">Category Management</h2>
        <Button size="sm" className="rounded-full font-heading" onClick={openAdd}>
          <Plus className="h-4 w-4 mr-1" /> Add Category
        </Button>
      </div>

      <div className="grid gap-3">
        {categories.map((cat) => (
          <Card key={cat.id} className="border-border/50">
            <CardContent className="p-3 flex items-center gap-4">
              <Switch checked={cat.enabled} onCheckedChange={() => toggleCat(cat.id, cat.enabled)} />
              <div className="w-12 h-12 rounded-lg overflow-hidden flex items-center justify-center shrink-0 bg-muted">
                {cat.image ? (
                  <img src={cat.image} alt={cat.name} className="w-full h-full object-cover" />
                ) : (
                  <span className="text-lg font-heading font-bold text-muted-foreground">{cat.name.charAt(0)}</span>
                )}
              </div>
              <div className="flex-1">
                <h3 className="font-heading font-semibold text-sm text-card-foreground">{cat.name}</h3>
                <p className="text-xs text-muted-foreground">{cat.count} products</p>
              </div>
              <div className="flex gap-1 shrink-0">
                <Button variant="ghost" size="sm" className="h-8 px-2" onClick={() => openEdit(cat)}>
                  <Edit className="h-3.5 w-3.5" />
                </Button>
                <Button variant="ghost" size="sm" className="h-8 px-2 text-destructive" onClick={() => deleteCat(cat.id)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-heading">{editCat ? "Edit Category" : "Add Category"}</DialogTitle>
            <DialogDescription>Configure category name and image</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSave} className="space-y-3">
            <div><Label>Name</Label><Input name="name" defaultValue={editCat?.name} required /></div>
            <div><Label>Image</Label><ImageUpload value={imageUrl} onChange={setImageUrl} folder="categories" /></div>
            <div><Label>Product Count</Label><Input name="count" type="number" defaultValue={editCat?.count || 0} /></div>
            <Button type="submit" className="w-full rounded-full font-heading">Save Category</Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminCategories;
