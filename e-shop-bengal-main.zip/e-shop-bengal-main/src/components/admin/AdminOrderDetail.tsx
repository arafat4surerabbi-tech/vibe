import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useStore, type Order, type Product } from "@/contexts/StoreContext";
import { ArrowLeft, Save, Printer, Truck, ExternalLink, Send, Loader2, Settings, Package, User, MapPin, CreditCard, Calendar, Hash, Trash2, Plus, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { downloadInvoice } from "@/utils/generateInvoice";

const statusOptions = ["Pending", "Confirmed", "Processing", "Shipped", "Delivered", "Cancelled", "Returned"];

interface AdminOrderDetailProps {
  orderId: string;
  onBack: () => void;
}

const AdminOrderDetail = ({ orderId, onBack }: AdminOrderDetailProps) => {
  const { orders, refreshOrders, couriers, storeSettings, products: allProducts, deliveryZones } = useStore();
  const { toast } = useToast();
  const order = orders.find((o) => o.id === orderId);

  const [customer, setCustomer] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const [deliveryArea, setDeliveryArea] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("");
  const [status, setStatus] = useState("");
  const [products, setProducts] = useState<{ name: string; qty: number; price: number; image?: string; size?: string; color?: string }[]>([]);
  const [saving, setSaving] = useState(false);
  const [sendingCourier, setSendingCourier] = useState(false);
  const [showProductPicker, setShowProductPicker] = useState(false);
  const [productSearch, setProductSearch] = useState("");
  const pickerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (order) {
      setCustomer(order.customer);
      setPhone(order.phone);
      setEmail(order.email || "");
      setAddress(order.address || "");
      setDeliveryArea(order.deliveryArea || "");
      setPaymentMethod(order.paymentMethod || "cod");
      setStatus(order.status);
      setProducts(order.products ? [...order.products] : []);
    }
  }, [order]);

  if (!order) {
    return (
      <div className="p-6">
        <Button variant="ghost" onClick={onBack} className="mb-4 gap-2">
          <ArrowLeft className="h-4 w-4" /> Back to Orders
        </Button>
        <p className="text-muted-foreground">Order not found.</p>
      </div>
    );
  }

  const subtotal = products.reduce((s, p) => s + p.price * p.qty, 0);
  const selectedZone = deliveryZones.find((z) => z.name === deliveryArea);
  const deliveryCharge = selectedZone?.charge || 0;
  const grandTotal = subtotal + deliveryCharge;

  const handleSave = async () => {
    setSaving(true);
    try {
      // Update order
      await supabase.from("orders").update({
        customer_name: customer,
        phone,
        email,
        address,
        delivery_area: deliveryArea,
        payment_method: paymentMethod,
        status,
        total: grandTotal,
        items_count: products.reduce((s, p) => s + p.qty, 0),
      } as any).eq("id", orderId);

      // Delete existing order items and re-insert
      await supabase.from("order_items").delete().eq("order_id", orderId);
      if (products.length > 0) {
        await supabase.from("order_items").insert(
          products.map((p) => ({
            order_id: orderId,
            product_name: p.name,
            quantity: p.qty,
            price: p.price,
            image: p.image || "",
            size: p.size || "",
            color: p.color || "",
          }))
        );
      }

      await refreshOrders();
      toast({ title: "Order updated", description: `${orderId} saved successfully.` });
    } catch (err) {
      toast({ title: "Error", description: "Failed to save order.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const handlePrintInvoice = () => {
    const updatedOrder: Order = {
      ...order,
      customer,
      phone,
      email,
      address,
      deliveryArea,
      paymentMethod,
      status,
      total: subtotal,
      products,
    };
    downloadInvoice(updatedOrder, storeSettings);
  };

  const updateProduct = (index: number, field: string, value: string | number) => {
    setProducts((prev) =>
      prev.map((p, i) => (i === index ? { ...p, [field]: value } : p))
    );
  };

  const removeProduct = (index: number) => {
    setProducts((prev) => prev.filter((_, i) => i !== index));
  };

  const addProduct = () => {
    setShowProductPicker(true);
    setProductSearch("");
  };

  const pickProduct = (p: Product) => {
    setProducts((prev) => [...prev, { name: p.name, qty: 1, price: p.price, image: p.image }]);
    setShowProductPicker(false);
    setProductSearch("");
  };

  const filteredCatalog = allProducts.filter((p) =>
    p.name.toLowerCase().includes(productSearch.toLowerCase())
  );

  const statusColor: Record<string, string> = {
    Pending: "bg-amber-500/10 text-amber-600 border-amber-500/20",
    Confirmed: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20",
    Processing: "bg-blue-500/10 text-blue-600 border-blue-500/20",
    Shipped: "bg-violet-500/10 text-violet-600 border-violet-500/20",
    Delivered: "bg-green-500/10 text-green-600 border-green-500/20",
    Cancelled: "bg-red-500/10 text-red-600 border-red-500/20",
    Returned: "bg-orange-500/10 text-orange-600 border-orange-500/20",
  };

  return (
    <div className="space-y-4 p-4 lg:p-6 max-w-5xl">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={onBack} className="rounded-full gap-1.5">
            <ArrowLeft className="h-4 w-4" /> Back
          </Button>
          <div>
            <h2 className="font-heading text-xl font-bold text-foreground flex items-center gap-2">
              <Hash className="h-5 w-5 text-primary" />
              {order.id}
            </h2>
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <Calendar className="h-3 w-3" /> {order.date}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="rounded-full gap-1.5 font-heading" onClick={handlePrintInvoice}>
            <Printer className="h-4 w-4" /> Download Invoice
          </Button>
          <Button size="sm" className="rounded-full gap-1.5 font-heading" onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            Save Changes
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left column - Customer & Order info */}
        <div className="lg:col-span-2 space-y-4">
          {/* Customer Info */}
          <Card className="border-border/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-heading flex items-center gap-2">
                <User className="h-4 w-4 text-primary" /> Customer Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-muted-foreground">Full Name</Label>
                  <Input value={customer} onChange={(e) => setCustomer(e.target.value)} className="mt-1 rounded-lg" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Phone</Label>
                  <Input value={phone} onChange={(e) => setPhone(e.target.value)} className="mt-1 rounded-lg" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Email</Label>
                  <Input value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1 rounded-lg" />
                </div>
                 <div>
                   <Label className="text-xs text-muted-foreground">Delivery Area</Label>
                   <Select value={deliveryArea} onValueChange={setDeliveryArea}>
                     <SelectTrigger className="mt-1 rounded-lg">
                       <SelectValue placeholder="Select area" />
                     </SelectTrigger>
                     <SelectContent>
                       {deliveryZones.map((z) => (
                         <SelectItem key={z.id} value={z.name}>{z.name} (৳{z.charge})</SelectItem>
                       ))}
                     </SelectContent>
                   </Select>
                 </div>
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Address</Label>
                <Textarea value={address} onChange={(e) => setAddress(e.target.value)} className="mt-1 rounded-lg" rows={2} />
              </div>
            </CardContent>
          </Card>

          {/* Products */}
          <Card className="border-border/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-heading flex items-center gap-2">
                <Package className="h-4 w-4 text-primary" /> Order Items
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {products.map((p, i) => (
                <div key={i} className="flex items-end gap-2 p-3 bg-muted/30 rounded-lg border border-border/30">
                  <div className="w-12 h-12 bg-muted rounded-lg flex items-center justify-center shrink-0 overflow-hidden self-center">
                    {p.image ? (
                      <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-lg opacity-30">👕</span>
                    )}
                  </div>
                  <div className="flex-1">
                    <Label className="text-xs text-muted-foreground">Product Name</Label>
                    <Input value={p.name} onChange={(e) => updateProduct(i, "name", e.target.value)} className="mt-1 rounded-lg" />
                  </div>
                  <div className="w-20">
                    <Label className="text-xs text-muted-foreground">Qty</Label>
                    <Input type="number" min={1} value={p.qty} onChange={(e) => updateProduct(i, "qty", parseInt(e.target.value) || 1)} className="mt-1 rounded-lg" />
                  </div>
                  <div className="w-28">
                    <Label className="text-xs text-muted-foreground">Price (৳)</Label>
                    <Input type="number" min={0} value={p.price} onChange={(e) => updateProduct(i, "price", parseFloat(e.target.value) || 0)} className="mt-1 rounded-lg" />
                  </div>
                  <div className="w-24 text-right">
                    <Label className="text-xs text-muted-foreground">Subtotal</Label>
                    <p className="mt-1 h-10 flex items-center justify-end font-medium text-sm">৳{(p.price * p.qty).toLocaleString()}</p>
                  </div>
                  <Button variant="ghost" size="sm" className="h-10 px-2 text-destructive hover:text-destructive" onClick={() => removeProduct(i)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}

              {/* Product Picker */}
              {showProductPicker ? (
                <div ref={pickerRef} className="border border-border rounded-lg p-3 space-y-2 bg-card">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search products..."
                      value={productSearch}
                      onChange={(e) => setProductSearch(e.target.value)}
                      className="pl-9 rounded-full bg-muted border-0"
                      autoFocus
                    />
                  </div>
                  <div className="max-h-48 overflow-y-auto space-y-1">
                    {filteredCatalog.length === 0 && (
                      <p className="text-sm text-muted-foreground text-center py-3">No products found</p>
                    )}
                    {filteredCatalog.map((cp) => (
                      <button
                        key={cp.id}
                        type="button"
                        onClick={() => pickProduct(cp)}
                        className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50 transition-colors text-left"
                      >
                        <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center shrink-0 overflow-hidden">
                          {cp.image ? (
                            <img src={cp.image} alt={cp.name} className="w-full h-full object-cover" />
                          ) : (
                            <span className="text-sm opacity-30">👕</span>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{cp.name}</p>
                          <p className="text-xs text-muted-foreground">৳{cp.price.toLocaleString()} • Stock: {cp.stock}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                  <Button variant="ghost" size="sm" className="w-full text-xs" onClick={() => setShowProductPicker(false)}>
                    Cancel
                  </Button>
                </div>
              ) : (
                <Button variant="outline" size="sm" className="rounded-full gap-1.5 w-full" onClick={addProduct}>
                  <Plus className="h-3.5 w-3.5" /> Add Product
                </Button>
              )}

              <Separator />
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>৳{subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Delivery ({deliveryArea || "N/A"})</span>
                  <span>৳{deliveryCharge.toLocaleString()}</span>
                </div>
              </div>
              <div className="flex justify-between items-center font-heading font-bold text-lg border-t border-border pt-2">
                <span>Total</span>
                <span className="text-primary">৳{grandTotal.toLocaleString()}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right column - Status, Payment, Courier */}
        <div className="space-y-4">
          {/* Status & Payment */}
          <Card className="border-border/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-heading">Order Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label className="text-xs text-muted-foreground">Status</Label>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger className={`mt-1 rounded-lg border ${statusColor[status] || ""}`}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {statusOptions.map((s) => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs text-muted-foreground flex items-center gap-1">
                  <CreditCard className="h-3 w-3" /> Payment Method
                </Label>
                <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                  <SelectTrigger className="mt-1 rounded-lg">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                     <SelectItem value="cod">Cash on Delivery</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Courier Info */}
          <Card className="border-border/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-heading flex items-center gap-2">
                <Truck className="h-4 w-4 text-primary" /> Courier
              </CardTitle>
            </CardHeader>
            <CardContent>
              {order.courierBooking ? (
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Courier</span>
                    <span className="font-medium">{order.courierBooking.courierName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Consignment</span>
                    <span className="font-mono text-xs font-medium">{order.courierBooking.consignmentId || order.courierBooking.trackingId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Status</span>
                    <Badge variant="secondary" className="text-xs">{order.courierBooking.status}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Booked</span>
                    <span className="text-xs">{new Date(order.courierBooking.bookedAt).toLocaleDateString()}</span>
                  </div>
                  {order.courierBooking.trackingLink && (
                    <a href={order.courierBooking.trackingLink} target="_blank" rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-primary hover:underline mt-1">
                      <ExternalLink className="h-3 w-3" /> Track Parcel
                    </a>
                  )}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No courier booked yet. Send to courier from the orders list.</p>
              )}
            </CardContent>
          </Card>

          {/* Order Summary */}
          <Card className="border-border/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-heading">Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Items</span>
                <span>{products.reduce((s, p) => s + p.qty, 0)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>৳{subtotal.toLocaleString()}</span>
              </div>
              <Separator />
              <div className="flex justify-between font-bold font-heading">
                <span>Total</span>
                <span className="text-primary">৳{subtotal.toLocaleString()}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AdminOrderDetail;
