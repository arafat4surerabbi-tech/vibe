import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Plus, Edit, Trash2, Image } from "lucide-react";
import { useStore } from "@/contexts/StoreContext";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import ImageUpload from "./ImageUpload";

const AdminBanners = () => {
  const { banners, products, categories, refreshBanners } = useStore();
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editBanner, setEditBanner] = useState<any>(null);
  const [selectedLink, setSelectedLink] = useState("");
  const [imageUrl, setImageUrl] = useState("");

  const handleSave = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const dbData = {
      title: (fd.get("title") as string) || "",
      subtitle: "",
      cta: "",
      bg: "from-primary/20 to-accent/10",
      image: imageUrl,
      enabled: true,
      link: selectedLink === "none" ? "" : (selectedLink || ""),
      cta_color: "",
    };

    if (editBanner?.id) {
      await supabase.from("banners").update(dbData as any).eq("id", editBanner.id);
      toast({ title: "Banner updated" });
    } else {
      await supabase.from("banners").insert({ ...dbData, id: `B${Date.now()}` } as any);
      toast({ title: "Banner added" });
    }
    await refreshBanners();
    setDialogOpen(false);
    setEditBanner(null);
    setSelectedLink("");
    setImageUrl("");
  };

  const deleteBanner = async (id: string) => {
    await supabase.from("banners").delete().eq("id", id);
    await refreshBanners();
    toast({ title: "Banner deleted" });
  };

  const toggleBanner = async (id: string, currentEnabled: boolean) => {
    await supabase.from("banners").update({ enabled: !currentEnabled } as any).eq("id", id);
    await refreshBanners();
  };

  const openEdit = (b: any) => {
    setEditBanner(b);
    setSelectedLink(b.link || "");
    setImageUrl(b.image || "");
    setDialogOpen(true);
  };

  const openAdd = () => {
    setEditBanner(null);
    setSelectedLink("");
    setImageUrl("");
    setDialogOpen(true);
  };

  return (
    <div className="space-y-4 p-4 lg:p-6">
      <div className="flex items-center justify-between">
        <h2 className="font-heading text-2xl font-bold text-foreground">Banner Management</h2>
        <Button size="sm" className="rounded-full font-heading" onClick={openAdd}>
          <Plus className="h-4 w-4 mr-1" /> Add Banner
        </Button>
      </div>

      <div className="grid gap-3">
        {banners.map((b) => (
          <Card key={b.id} className="border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <Switch checked={b.enabled} onCheckedChange={() => toggleBanner(b.id, b.enabled)} />
                <div className="w-24 h-14 rounded-lg overflow-hidden shrink-0 bg-muted flex items-center justify-center">
                  {b.image ? (
                    <img src={b.image} alt={b.title} className="w-full h-full object-cover" />
                  ) : (
                    <Image className="h-5 w-5 text-muted-foreground" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-heading font-semibold text-sm text-card-foreground truncate">{b.title || "(No title)"}</h3>
                  {(b as any).link && <p className="text-xs text-muted-foreground mt-0.5">Link: {(b as any).link}</p>}
                </div>
                <div className="flex gap-1 shrink-0">
                  <Button variant="ghost" size="sm" className="h-8 px-2" onClick={() => openEdit(b)}>
                    <Edit className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="sm" className="h-8 px-2 text-destructive" onClick={() => deleteBanner(b.id)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-heading">{editBanner ? "Edit Banner" : "Add Banner"}</DialogTitle>
            <DialogDescription>Configure banner image, title and link destination</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSave} className="space-y-3">
            <div><Label>Image</Label><ImageUpload value={imageUrl} onChange={setImageUrl} folder="banners" /></div>
            <div><Label>Title (optional)</Label><Input name="title" defaultValue={editBanner?.title} placeholder="e.g. Eid Collection 2026" /></div>
            <div>
              <Label>Link Destination (clicking banner navigates here)</Label>
              <Select value={selectedLink} onValueChange={setSelectedLink}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a link destination" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No link</SelectItem>
                  {categories.filter(c => c.enabled).map((cat) => (
                    <SelectItem key={`cat-${cat.id}`} value={`/category/${encodeURIComponent(cat.name)}`}>
                      📁 Category: {cat.name}
                    </SelectItem>
                  ))}
                  {products.map((p) => (
                    <SelectItem key={`prod-${p.id}`} value={`/product/${p.id}`}>
                      🛍️ Product: {p.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button type="submit" className="w-full rounded-full font-heading">Save Banner</Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminBanners;
