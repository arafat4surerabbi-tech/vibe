import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Plus, Edit, Trash2, GripVertical } from "lucide-react";
import { useStore } from "@/contexts/StoreContext";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface NavLink {
  id: number;
  label: string;
  path: string;
  sort_order: number;
  enabled: boolean;
}

const AdminNavLinks = () => {
  const { categories } = useStore();
  const { toast } = useToast();
  const [links, setLinks] = useState<NavLink[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editLink, setEditLink] = useState<NavLink | null>(null);

  const fetchLinks = async () => {
    const { data } = await supabase.from("nav_links").select("*").order("sort_order") as any;
    if (data) setLinks(data);
  };

  useEffect(() => { fetchLinks(); }, []);

  const handleSave = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const dbData = {
      label: fd.get("label") as string,
      path: fd.get("path") as string,
      sort_order: Number(fd.get("sort_order") || 0),
      enabled: true,
    };

    if (editLink?.id) {
      await supabase.from("nav_links").update(dbData as any).eq("id", editLink.id);
      toast({ title: "Nav link updated" });
    } else {
      await supabase.from("nav_links").insert(dbData as any);
      toast({ title: "Nav link added" });
    }
    await fetchLinks();
    setDialogOpen(false);
    setEditLink(null);
  };

  const deleteLink = async (id: number) => {
    await supabase.from("nav_links").delete().eq("id", id);
    await fetchLinks();
    toast({ title: "Nav link deleted" });
  };

  const toggleLink = async (id: number, currentEnabled: boolean) => {
    await supabase.from("nav_links").update({ enabled: !currentEnabled } as any).eq("id", id);
    await fetchLinks();
  };

  const openEdit = (link: NavLink) => {
    setEditLink(link);
    setDialogOpen(true);
  };

  const openAdd = () => {
    setEditLink(null);
    setDialogOpen(true);
  };

  return (
    <div className="space-y-4 p-4 lg:p-6">
      <div className="flex items-center justify-between">
        <h2 className="font-heading text-2xl font-bold text-foreground">Header Navigation</h2>
        <Button size="sm" className="rounded-full font-heading" onClick={openAdd}>
          <Plus className="h-4 w-4 mr-1" /> Add Link
        </Button>
      </div>

      <p className="text-sm text-muted-foreground">Manage the navigation links shown in the website header. "Home" is always shown.</p>

      <div className="grid gap-2">
        {links.map((link) => (
          <Card key={link.id} className="border-border/50">
            <CardContent className="p-3 flex items-center gap-3">
              <GripVertical className="h-4 w-4 text-muted-foreground/50 shrink-0" />
              <Switch checked={link.enabled} onCheckedChange={() => toggleLink(link.id, link.enabled)} />
              <div className="flex-1 min-w-0">
                <h3 className="font-heading font-semibold text-sm text-card-foreground">{link.label}</h3>
                <p className="text-xs text-muted-foreground">{link.path}</p>
              </div>
              <span className="text-xs text-muted-foreground/50 font-mono">#{link.sort_order}</span>
              <div className="flex gap-1 shrink-0">
                <Button variant="ghost" size="sm" className="h-8 px-2" onClick={() => openEdit(link)}>
                  <Edit className="h-3.5 w-3.5" />
                </Button>
                <Button variant="ghost" size="sm" className="h-8 px-2 text-destructive" onClick={() => deleteLink(link.id)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
        {links.length === 0 && (
          <p className="text-sm text-muted-foreground text-center py-8">No navigation links yet. Add your first one!</p>
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-heading">{editLink ? "Edit Nav Link" : "Add Nav Link"}</DialogTitle>
            <DialogDescription>Configure label and link path</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSave} className="space-y-3">
            <div><Label>Label</Label><Input name="label" defaultValue={editLink?.label} required placeholder="e.g. Men" /></div>
            <div>
              <Label>Path</Label>
              <Input name="path" defaultValue={editLink?.path} required placeholder="e.g. /category/Men or /#section" />
              <p className="text-xs text-muted-foreground mt-1">Use /category/CategoryName to link to a category page, or /#section-id for page sections</p>
            </div>
            <div><Label>Sort Order</Label><Input name="sort_order" type="number" defaultValue={editLink?.sort_order || 0} /></div>
            <Button type="submit" className="w-full rounded-full font-heading">Save Link</Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminNavLinks;
