import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Settings, Store, Mail, ClipboardList, Paintbrush } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useStore } from "@/contexts/StoreContext";
import ImageUpload from "./ImageUpload";

const CHECKOUT_FIELDS = [
  { key: "checkout_field_name", label: "Full Name", defaultOn: true },
  { key: "checkout_field_phone", label: "Phone", defaultOn: true },
  { key: "checkout_field_email", label: "Email", defaultOn: true },
  { key: "checkout_field_address", label: "Address", defaultOn: true },
  { key: "checkout_field_delivery_area", label: "Delivery Area", defaultOn: true },
  { key: "checkout_field_payment_method", label: "Payment Method", defaultOn: true },
];

const AdminSettings = () => {
  const { toast } = useToast();
  const { refreshStoreSettings } = useStore();
  const [storeInfo, setStoreInfo] = useState({
    name: "Store",
    email: "admin@store.com",
    phone: "01700000000",
    address: "Dhaka, Bangladesh",
    vatRate: "5",
    whatsappNumber: "8801700000000",
    callNumber: "8801700000000",
  });
  const [metaPixelId, setMetaPixelId] = useState("");
  const [metaPixelEnabled, setMetaPixelEnabled] = useState(false);
  const [metaCapiToken, setMetaCapiToken] = useState("");
  const [checkoutFields, setCheckoutFields] = useState<Record<string, boolean>>({});
  const [siteTitle, setSiteTitle] = useState("");
  const [flaticonUrl, setFlaticonUrl] = useState("");
  const [siteLogoUrl, setSiteLogoUrl] = useState("");

  useEffect(() => {
    const loadSettings = async () => {
      const { data } = await supabase.from("store_settings").select("*");
      if (data) {
        const map: Record<string, string> = {};
        data.forEach((r: any) => { map[r.key] = r.value; });
        setStoreInfo({
          name: map.store_name || "Store",
          email: map.store_email || "",
          phone: map.store_phone || "",
          address: map.store_address || "",
          vatRate: map.vat_rate || "5",
          whatsappNumber: map.whatsapp_number || "8801700000000",
          callNumber: map.call_number || "8801700000000",
        });
        setMetaPixelId(map.meta_pixel_id || "");
        setMetaPixelEnabled(map.meta_pixel_enabled === "true");
        setMetaCapiToken(map.meta_capi_token || "");
        
        const fields: Record<string, boolean> = {};
        CHECKOUT_FIELDS.forEach((f) => {
          fields[f.key] = map[f.key] !== undefined ? map[f.key] === "true" : f.defaultOn;
        });
        setCheckoutFields(fields);
        setSiteTitle(map.site_title || "");
        setFlaticonUrl(map.flaticon_url || "");
        setSiteLogoUrl(map.site_logo_url || "");
      }
    };
    loadSettings();
  }, []);

  const handleSave = async () => {
    const settings = [
      { key: "store_name", value: storeInfo.name },
      { key: "store_email", value: storeInfo.email },
      { key: "store_phone", value: storeInfo.phone },
      { key: "store_address", value: storeInfo.address },
      { key: "vat_rate", value: storeInfo.vatRate },
      { key: "whatsapp_number", value: storeInfo.whatsappNumber },
      { key: "call_number", value: storeInfo.callNumber },
      { key: "meta_pixel_id", value: metaPixelId },
      { key: "meta_pixel_enabled", value: String(metaPixelEnabled) },
      { key: "meta_capi_token", value: metaCapiToken },
      { key: "site_title", value: siteTitle },
      { key: "flaticon_url", value: flaticonUrl },
      { key: "site_logo_url", value: siteLogoUrl },
      ...CHECKOUT_FIELDS.map((f) => ({ key: f.key, value: String(checkoutFields[f.key] ?? f.defaultOn) })),
    ];

    for (const s of settings) {
      const { data: existing } = await supabase.from("store_settings").select("id").eq("key", s.key).maybeSingle();
      if (existing) {
        await supabase.from("store_settings").update({ value: s.value } as any).eq("key", s.key);
      } else {
        await supabase.from("store_settings").insert({ key: s.key, value: s.value } as any);
      }
    }
    await refreshStoreSettings();
    toast({ title: "Settings saved successfully" });
  };

  return (
    <div className="space-y-4 p-4 lg:p-6">
      <h2 className="font-heading text-2xl font-bold text-foreground">Settings</h2>

      <Card className="border-border/50">
        <CardHeader><CardTitle className="font-heading text-base flex items-center gap-2"><Store className="h-4 w-4" /> Store Information</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Store Name</Label><Input value={storeInfo.name} onChange={(e) => setStoreInfo({ ...storeInfo, name: e.target.value })} /></div>
            <div><Label>Email</Label><Input value={storeInfo.email} onChange={(e) => setStoreInfo({ ...storeInfo, email: e.target.value })} /></div>
            <div><Label>Phone</Label><Input value={storeInfo.phone} onChange={(e) => setStoreInfo({ ...storeInfo, phone: e.target.value })} /></div>
          </div>
          <div><Label>Address</Label><Input value={storeInfo.address} onChange={(e) => setStoreInfo({ ...storeInfo, address: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>WhatsApp Number</Label><Input value={storeInfo.whatsappNumber} onChange={(e) => setStoreInfo({ ...storeInfo, whatsappNumber: e.target.value })} placeholder="8801XXXXXXXXX" /></div>
            <div><Label>Call Number</Label><Input value={storeInfo.callNumber} onChange={(e) => setStoreInfo({ ...storeInfo, callNumber: e.target.value })} placeholder="8801XXXXXXXXX" /></div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardHeader><CardTitle className="font-heading text-base flex items-center gap-2"><Paintbrush className="h-4 w-4" /> Site Appearance</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Site Title</Label>
            <Input value={siteTitle} onChange={(e) => setSiteTitle(e.target.value)} placeholder="e.g. My Awesome Store" />
            <p className="text-xs text-muted-foreground mt-1">This title appears in the browser tab.</p>
          </div>
          <div>
            <Label>Site Logo</Label>
            <ImageUpload value={siteLogoUrl} onChange={setSiteLogoUrl} folder="settings" />
            <p className="text-xs text-muted-foreground mt-1">Used in the website header.</p>
          </div>
          <div>
            <Label>Favicon / Flaticon</Label>
            <ImageUpload value={flaticonUrl} onChange={setFlaticonUrl} folder="settings" />
            <p className="text-xs text-muted-foreground mt-1">Small icon that appears in the browser tab (ideally square, e.g. 32x32).</p>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardHeader><CardTitle className="font-heading text-base flex items-center gap-2"><ClipboardList className="h-4 w-4" /> Checkout Fields</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          <p className="text-xs text-muted-foreground mb-2">Toggle which fields customers see on the checkout page.</p>
          {CHECKOUT_FIELDS.map((f) => (
            <div key={f.key} className="flex items-center justify-between p-3 rounded-lg border border-border/50">
              <span className="text-sm font-medium">{f.label}</span>
              <Switch
                checked={checkoutFields[f.key] ?? f.defaultOn}
                onCheckedChange={(v) => setCheckoutFields((prev) => ({ ...prev, [f.key]: v }))}
              />
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardHeader><CardTitle className="font-heading text-base flex items-center gap-2"><Settings className="h-4 w-4" /> Meta Pixel / Tracking</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div>
            <Label>Meta Pixel ID</Label>
            <Input value={metaPixelId} onChange={(e) => setMetaPixelId(e.target.value)} placeholder="e.g. 123456789012345" />
            <p className="text-xs text-muted-foreground mt-1">Enter your Facebook/Meta Pixel ID. Find it in Meta Events Manager.</p>
          </div>
          <div>
            <Label>Conversions API Access Token</Label>
            <Input value={metaCapiToken} onChange={(e) => setMetaCapiToken(e.target.value)} placeholder="EAAxxxxxxx..." type="password" />
            <p className="text-xs text-muted-foreground mt-1">Generate a token in Meta Events Manager → Settings → Conversions API.</p>
          </div>
          <div className="flex items-center justify-between p-3 rounded-lg border border-border/50">
            <div>
              <p className="font-medium text-sm">Enable Meta Pixel & Conversions API</p>
              <p className="text-xs text-muted-foreground">Track visitor activity with browser pixel + server-side events</p>
            </div>
            <Switch checked={metaPixelEnabled} onCheckedChange={setMetaPixelEnabled} />
          </div>
        </CardContent>
      </Card>

      <Button className="rounded-full font-heading" onClick={handleSave}>Save Settings</Button>
    </div>
  );
};

export default AdminSettings;
