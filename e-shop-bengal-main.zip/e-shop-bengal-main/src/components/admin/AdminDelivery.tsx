import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Truck, MapPin, CheckCircle, AlertCircle, RotateCcw, Unplug, Settings } from "lucide-react";
import { useStore } from "@/contexts/StoreContext";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

const AdminDelivery = () => {
  const { toast } = useToast();
  const { deliveryZones, couriers, orders, refreshDeliveryZones, refreshCouriers } = useStore();
  const [courierDialog, setCourierDialog] = useState<string | null>(null);

  const updateCharge = async (id: number, charge: number) => {
    await supabase.from("delivery_zones").update({ charge } as any).eq("id", id);
    await refreshDeliveryZones();
  };

  const toggleZone = async (id: number, currentEnabled: boolean) => {
    await supabase.from("delivery_zones").update({ enabled: !currentEnabled } as any).eq("id", id);
    await refreshDeliveryZones();
  };

  const toggleCourier = async (id: string) => {
    const c = couriers.find((cc) => cc.id === id);
    if (!c) return;
    const hasCredentials = id === "pathao"
      ? Boolean(c.apiKey.trim() && c.apiSecret.trim() && c.username?.trim() && c.password?.trim())
      : Boolean(c.apiKey.trim() && c.apiSecret.trim());

    if (!c.enabled && !hasCredentials) {
      toast({ title: "Setup needed", description: `Add ${c.name} API credentials first.`, variant: "destructive" });
      return;
    }
    await supabase.from("courier_configs").update({ enabled: !c.enabled } as any).eq("id", id);
    await refreshCouriers();
  };

  const saveCourierApi = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const apiKey = String(fd.get("apiKey") || "").trim();
    const apiSecret = String(fd.get("apiSecret") || "").trim();
    const username = String(fd.get("username") || "").trim();
    const password = String(fd.get("password") || "").trim();
    const storeId = String(fd.get("storeId") || "").trim();

    if (!courierDialog) return;

    if (courierDialog === "pathao") {
      if (!apiKey || !apiSecret || !username || !password) {
        toast({ title: "Missing credentials", description: "Client ID, Client Secret, Username and Password are all required for Pathao.", variant: "destructive" });
        return;
      }
    } else {
      if (!apiKey || !apiSecret) {
        toast({ title: "Missing credentials", description: "Both API key and secret key are required.", variant: "destructive" });
        return;
      }
    }

    const courierName = couriers.find((c) => c.id === courierDialog)?.name || courierDialog;

    await supabase.from("courier_configs").update({
      api_key: apiKey,
      api_secret: apiSecret,
      username,
      password,
      store_id: storeId,
      enabled: true,
    } as any).eq("id", courierDialog);

    await refreshCouriers();
    toast({ title: `${courierName} connected`, description: "Credentials saved. Confirmed orders can now be sent to this courier." });
    setCourierDialog(null);
  };

  const clearCourierApi = async (id: string) => {
    const courierName = couriers.find((c) => c.id === id)?.name || id;
    await supabase.from("courier_configs").update({
      api_key: "", api_secret: "", username: "", password: "", store_id: "", enabled: false,
    } as any).eq("id", id);
    await refreshCouriers();
    toast({ title: `${courierName} disconnected`, description: "API credentials removed." });
  };

  const isConnected = (c: typeof couriers[0]) => {
    if (c.id === "pathao") return Boolean(c.apiKey.trim() && c.apiSecret.trim() && c.username?.trim() && c.password?.trim());
    return Boolean(c.apiKey.trim() && c.apiSecret.trim());
  };

  const courierBookings = orders.filter((o) => o.courierBooking).map((o) => ({ order: o.id, ...o.courierBooking! }));
  const selectedCourier = couriers.find((c) => c.id === courierDialog);

  return (
    <div className="space-y-4 p-4 lg:p-6">
      <h2 className="font-heading text-2xl font-bold text-foreground">Delivery Management</h2>

      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="font-heading text-base flex items-center gap-2">
            <MapPin className="h-4 w-4" /> Delivery Zones
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {deliveryZones.map((z) => (
            <div key={z.id} className="flex items-center gap-4 p-3 rounded-lg border border-border/50">
              <Switch checked={z.enabled} onCheckedChange={() => toggleZone(z.id, z.enabled)} />
              <div className="flex-1"><p className="font-medium text-sm">{z.name}</p></div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">৳</span>
                <Input type="number" value={z.charge} onChange={(e) => updateCharge(z.id, Number(e.target.value))} className="w-20 h-8 text-sm" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="font-heading text-base flex items-center gap-2">
            <Truck className="h-4 w-4" /> Courier Partners & API Setup
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-xs text-muted-foreground mb-2">
            Add API credentials here. These are used when you click <strong>Send to Courier</strong> on confirmed orders.
          </p>
          {couriers.map((c) => {
            const connected = isConnected(c);
            return (
              <div key={c.id} className="flex flex-col gap-3 rounded-lg border border-border/50 p-3 md:flex-row md:items-center md:justify-between">
                <div className="flex items-center gap-3">
                  <Truck className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <span className="font-medium text-sm">{c.name}</span>
                    <div className="mt-0.5 flex items-center gap-1">
                      {connected ? (
                        <span className="text-xs text-success flex items-center gap-1"><CheckCircle className="h-3 w-3" /> API Connected</span>
                      ) : (
                        <span className="text-xs text-muted-foreground flex items-center gap-1"><AlertCircle className="h-3 w-3" /> Not configured</span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <Badge variant={c.enabled && connected ? "default" : "secondary"} className="text-xs">
                    {c.enabled && connected ? "Active" : "Inactive"}
                  </Badge>
                  <Button variant="outline" size="sm" className="h-8 rounded-full text-xs" onClick={() => setCourierDialog(c.id)}>
                    {connected ? <RotateCcw className="h-3 w-3 mr-1" /> : <Settings className="h-3 w-3 mr-1" />}
                    {connected ? "Reconnect API" : "Setup API"}
                  </Button>
                  {connected && (
                    <Button variant="ghost" size="sm" className="h-8 rounded-full text-xs" onClick={() => clearCourierApi(c.id)}>
                      <Unplug className="h-3 w-3 mr-1" /> Remove
                    </Button>
                  )}
                  <Switch checked={c.enabled} onCheckedChange={() => toggleCourier(c.id)} />
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>

      {courierBookings.length > 0 && (
        <Card className="border-border/50">
          <CardHeader>
            <CardTitle className="font-heading text-base flex items-center gap-2">
              <Truck className="h-4 w-4" /> Recent Courier Bookings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-muted-foreground border-b border-border">
                    <th className="pb-2 font-medium">Order</th>
                    <th className="pb-2 font-medium">Courier</th>
                    <th className="pb-2 font-medium">Tracking ID</th>
                    <th className="pb-2 font-medium">Status</th>
                    <th className="pb-2 font-medium">Booked At</th>
                  </tr>
                </thead>
                <tbody>
                  {courierBookings.map((b) => (
                    <tr key={b.trackingId} className="border-b border-border/50 last:border-0">
                      <td className="py-2 font-medium">{b.order}</td>
                      <td className="py-2">{b.courierName}</td>
                      <td className="py-2 font-mono text-xs">{b.trackingId}</td>
                      <td className="py-2"><Badge variant="secondary" className="text-xs">{b.status}</Badge></td>
                      <td className="py-2 text-muted-foreground">{new Date(b.bookedAt).toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={!!courierDialog} onOpenChange={() => setCourierDialog(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-heading">Setup {selectedCourier?.name} API</DialogTitle>
          </DialogHeader>
          <form onSubmit={saveCourierApi} className="space-y-3">
            {courierDialog === "pathao" ? (
              <>
                <p className="text-xs text-muted-foreground">
                  Get credentials from <a href="https://merchant.pathao.com/courier/developer-api" target="_blank" rel="noopener noreferrer" className="text-primary underline">Pathao Merchant Panel</a>.
                </p>
                <div><Label>Client ID</Label><Input name="apiKey" defaultValue={selectedCourier?.apiKey} required placeholder="Enter Client ID" /></div>
                <div><Label>Client Secret</Label><Input name="apiSecret" type="password" defaultValue={selectedCourier?.apiSecret} required placeholder="Enter Client Secret" /></div>
                <div><Label>Username (Email)</Label><Input name="username" type="email" defaultValue={selectedCourier?.username} required placeholder="Your Pathao merchant email" /></div>
                <div><Label>Password</Label><Input name="password" type="password" defaultValue={selectedCourier?.password} required placeholder="Your Pathao password" /></div>
                <div><Label>Store ID <span className="text-muted-foreground text-xs">(optional)</span></Label><Input name="storeId" defaultValue={selectedCourier?.storeId} placeholder="Pathao Store ID" /></div>
              </>
            ) : (
              <>
                <p className="text-xs text-muted-foreground">Enter your API key and secret key.</p>
                <div><Label>API Key</Label><Input name="apiKey" defaultValue={selectedCourier?.apiKey} required placeholder="Enter API key" /></div>
                <div><Label>Secret Key</Label><Input name="apiSecret" type="password" defaultValue={selectedCourier?.apiSecret} required placeholder="Enter secret key" /></div>
                <input type="hidden" name="username" value="" />
                <input type="hidden" name="password" value="" />
                <input type="hidden" name="storeId" value="" />
              </>
            )}
            <Button type="submit" className="w-full rounded-full font-heading">Save & Enable</Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminDelivery;
