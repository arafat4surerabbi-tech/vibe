import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Shield, Globe, Lock, Clock, LogOut, Key, RotateCcw } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

const DevPanelContent = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [siteBlocked, setSiteBlocked] = useState(false);
  const [adminBlocked, setAdminBlocked] = useState(false);
  const [blockMessage, setBlockMessage] = useState("");
  const [adminBlockMessage, setAdminBlockMessage] = useState("");
  const [hostingExpiry, setHostingExpiry] = useState("");
  const [devPassword, setDevPassword] = useState("");
  const [loading, setLoading] = useState(true);
  const [resetting, setResetting] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    const { data } = await supabase.from("dev_settings").select("*");
    if (data) {
      const map: Record<string, string> = {};
      data.forEach((r: any) => { map[r.key] = r.value; });
      setSiteBlocked(map.site_blocked === "true");
      setAdminBlocked(map.admin_blocked === "true");
      setBlockMessage(map.block_message || "");
      setAdminBlockMessage(map.admin_block_message || "");
      setHostingExpiry(map.hosting_expiry || "");
      setDevPassword(map.dev_password || "");
    }
    setLoading(false);
  };

  const saveSetting = async (key: string, value: string) => {
    const { data: existing } = await supabase.from("dev_settings").select("id").eq("key", key).maybeSingle();
    if (existing) {
      await supabase.from("dev_settings").update({ value } as any).eq("key", key);
    } else {
      await supabase.from("dev_settings").insert({ key, value } as any);
    }
  };

  const handleSaveAll = async () => {
    const settings = [
      { key: "site_blocked", value: String(siteBlocked) },
      { key: "admin_blocked", value: String(adminBlocked) },
      { key: "block_message", value: blockMessage },
      { key: "admin_block_message", value: adminBlockMessage },
      { key: "hosting_expiry", value: hostingExpiry },
      { key: "dev_password", value: devPassword },
    ];
    for (const s of settings) {
      await saveSetting(s.key, s.value);
    }
    toast({ title: "Developer settings saved!" });
  };

  const handleLogout = () => {
    sessionStorage.removeItem("dev_authenticated");
    navigate("/dev-login");
  };

  const handleResetAll = async () => {
    setResetting(true);
    try {
      const { error } = await supabase.rpc("reset_all_data");
      if (error) throw error;
      toast({ title: "✅ Full reset complete!", description: "All data has been wiped. The site is now fresh." });
    } catch (e: any) {
      toast({ title: "Reset failed", description: e.message, variant: "destructive" });
    } finally {
      setResetting(false);
    }
  };

  // Calculate remaining days
  const getRemainingDays = () => {
    if (!hostingExpiry) return null;
    const expiry = new Date(hostingExpiry);
    const now = new Date();
    const diff = Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return diff;
  };

  const remainingDays = getRemainingDays();

  if (loading) return <div className="flex items-center justify-center min-h-screen"><p>Loading...</p></div>;

  return (
    <div className="max-w-3xl mx-auto p-4 lg:p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Shield className="h-7 w-7 text-primary" />
          <h1 className="font-heading text-2xl font-bold">Developer Panel</h1>
        </div>
        <Button variant="ghost" size="sm" onClick={handleLogout}>
          <LogOut className="h-4 w-4 mr-1" /> Logout
        </Button>
      </div>

      {/* Website Blocking */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="font-heading text-base flex items-center gap-2">
            <Globe className="h-4 w-4" /> Website Control
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-lg border border-border/50">
            <div>
              <p className="font-medium text-sm">Block Website</p>
              <p className="text-xs text-muted-foreground">Visitors will see a block message instead of the website</p>
            </div>
            <Switch checked={siteBlocked} onCheckedChange={setSiteBlocked} />
          </div>
          <div>
            <Label>Website Block Message</Label>
            <Textarea
              value={blockMessage}
              onChange={(e) => setBlockMessage(e.target.value)}
              placeholder="Message shown when website is blocked..."
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      {/* Admin Blocking */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="font-heading text-base flex items-center gap-2">
            <Lock className="h-4 w-4" /> Admin Panel Control
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-lg border border-border/50">
            <div>
              <p className="font-medium text-sm">Block Admin Panel</p>
              <p className="text-xs text-muted-foreground">Admin users will see a block message</p>
            </div>
            <Switch checked={adminBlocked} onCheckedChange={setAdminBlocked} />
          </div>
          <div>
            <Label>Admin Block Message</Label>
            <Textarea
              value={adminBlockMessage}
              onChange={(e) => setAdminBlockMessage(e.target.value)}
              placeholder="Message shown when admin is blocked..."
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      {/* Hosting Expiry */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="font-heading text-base flex items-center gap-2">
            <Clock className="h-4 w-4" /> Hosting Expiry
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Hosting Expiry Date</Label>
            <Input
              type="date"
              value={hostingExpiry}
              onChange={(e) => setHostingExpiry(e.target.value)}
            />
            <p className="text-xs text-muted-foreground mt-1">
              When this date passes, both website and admin panel will automatically show the block message.
            </p>
          </div>
          {remainingDays !== null && (
            <div className={`p-3 rounded-lg border ${remainingDays <= 0 ? 'border-destructive/50 bg-destructive/10' : remainingDays <= 7 ? 'border-yellow-500/50 bg-yellow-500/10' : 'border-green-500/50 bg-green-500/10'}`}>
              <p className="text-sm font-medium">
                {remainingDays <= 0
                  ? `⚠️ Hosting expired ${Math.abs(remainingDays)} days ago — site is blocked`
                  : `✅ ${remainingDays} days remaining`}
              </p>
            </div>
          )}
          <div className="flex gap-2">
            {[30, 90, 180, 365].map((days) => (
              <Button
                key={days}
                variant="outline"
                size="sm"
                onClick={() => {
                  const d = new Date();
                  d.setDate(d.getDate() + days);
                  setHostingExpiry(d.toISOString().split("T")[0]);
                }}
              >
                +{days}d
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Dev Password */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="font-heading text-base flex items-center gap-2">
            <Key className="h-4 w-4" /> Developer Password
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div>
            <Label>Change Dev Panel Password</Label>
            <Input
              type="text"
              value={devPassword}
              onChange={(e) => setDevPassword(e.target.value)}
            />
            <p className="text-xs text-muted-foreground mt-1">This password is used to access this developer panel.</p>
          </div>
        </CardContent>
      </Card>

      {/* Factory Reset */}
      <Card className="border-destructive/30 bg-destructive/5">
        <CardHeader>
          <CardTitle className="font-heading text-base flex items-center gap-2 text-destructive">
            <RotateCcw className="h-4 w-4" /> Factory Reset
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">
            Delete <strong>all</strong> orders, customers, products, banners, categories, coupons, delivery zones, navigation links, courier configs, and store settings. This cannot be undone.
          </p>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" className="rounded-full font-heading" disabled={resetting}>
                <RotateCcw className={`h-4 w-4 mr-2 ${resetting ? "animate-spin" : ""}`} />
                {resetting ? "Resetting..." : "Reset Everything"}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete ALL data — orders, customers, products, banners, categories, coupons, and settings. The website and admin panel will appear completely empty.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleResetAll} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  Yes, Reset Everything
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>

      <Button className="rounded-full font-heading w-full" onClick={handleSaveAll}>
        Save All Settings
      </Button>
    </div>
  );
};

export default DevPanelContent;
