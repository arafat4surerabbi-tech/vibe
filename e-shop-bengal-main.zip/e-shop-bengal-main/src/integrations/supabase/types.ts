export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      banners: {
        Row: {
          bg: string
          created_at: string
          cta: string
          cta_color: string
          enabled: boolean
          id: string
          image: string
          link: string
          subtitle: string
          title: string
        }
        Insert: {
          bg?: string
          created_at?: string
          cta?: string
          cta_color?: string
          enabled?: boolean
          id?: string
          image?: string
          link?: string
          subtitle?: string
          title?: string
        }
        Update: {
          bg?: string
          created_at?: string
          cta?: string
          cta_color?: string
          enabled?: boolean
          id?: string
          image?: string
          link?: string
          subtitle?: string
          title?: string
        }
        Relationships: []
      }
      categories: {
        Row: {
          count: number
          created_at: string
          enabled: boolean
          icon: string
          id: number
          image: string
          name: string
        }
        Insert: {
          count?: number
          created_at?: string
          enabled?: boolean
          icon?: string
          id?: number
          image?: string
          name: string
        }
        Update: {
          count?: number
          created_at?: string
          enabled?: boolean
          icon?: string
          id?: number
          image?: string
          name?: string
        }
        Relationships: []
      }
      coupons: {
        Row: {
          active: boolean
          code: string
          created_at: string
          discount: number
          expiry: string
          id: string
          max_uses: number
          min_order: number
          type: string
          used_count: number
        }
        Insert: {
          active?: boolean
          code: string
          created_at?: string
          discount?: number
          expiry?: string
          id: string
          max_uses?: number
          min_order?: number
          type?: string
          used_count?: number
        }
        Update: {
          active?: boolean
          code?: string
          created_at?: string
          discount?: number
          expiry?: string
          id?: string
          max_uses?: number
          min_order?: number
          type?: string
          used_count?: number
        }
        Relationships: []
      }
      courier_configs: {
        Row: {
          api_key: string
          api_secret: string
          base_url: string
          created_at: string
          enabled: boolean
          id: string
          name: string
          password: string
          store_id: string
          username: string
        }
        Insert: {
          api_key?: string
          api_secret?: string
          base_url?: string
          created_at?: string
          enabled?: boolean
          id: string
          name: string
          password?: string
          store_id?: string
          username?: string
        }
        Update: {
          api_key?: string
          api_secret?: string
          base_url?: string
          created_at?: string
          enabled?: boolean
          id?: string
          name?: string
          password?: string
          store_id?: string
          username?: string
        }
        Relationships: []
      }
      customers: {
        Row: {
          address: string
          created_at: string
          email: string
          id: string
          join_date: string
          name: string
          orders_count: number
          phone: string
          status: string
          total_spent: number
        }
        Insert: {
          address?: string
          created_at?: string
          email?: string
          id: string
          join_date?: string
          name: string
          orders_count?: number
          phone?: string
          status?: string
          total_spent?: number
        }
        Update: {
          address?: string
          created_at?: string
          email?: string
          id?: string
          join_date?: string
          name?: string
          orders_count?: number
          phone?: string
          status?: string
          total_spent?: number
        }
        Relationships: []
      }
      delivery_zones: {
        Row: {
          charge: number
          enabled: boolean
          id: number
          name: string
        }
        Insert: {
          charge?: number
          enabled?: boolean
          id?: number
          name: string
        }
        Update: {
          charge?: number
          enabled?: boolean
          id?: number
          name?: string
        }
        Relationships: []
      }
      dev_settings: {
        Row: {
          created_at: string
          id: number
          key: string
          value: string
        }
        Insert: {
          created_at?: string
          id?: never
          key: string
          value?: string
        }
        Update: {
          created_at?: string
          id?: never
          key?: string
          value?: string
        }
        Relationships: []
      }
      nav_links: {
        Row: {
          created_at: string
          enabled: boolean
          id: number
          label: string
          path: string
          sort_order: number
        }
        Insert: {
          created_at?: string
          enabled?: boolean
          id?: number
          label: string
          path?: string
          sort_order?: number
        }
        Update: {
          created_at?: string
          enabled?: boolean
          id?: number
          label?: string
          path?: string
          sort_order?: number
        }
        Relationships: []
      }
      order_items: {
        Row: {
          color: string
          id: number
          image: string
          order_id: string
          price: number
          product_name: string
          quantity: number
          size: string
        }
        Insert: {
          color?: string
          id?: number
          image?: string
          order_id: string
          price?: number
          product_name: string
          quantity?: number
          size?: string
        }
        Update: {
          color?: string
          id?: number
          image?: string
          order_id?: string
          price?: number
          product_name?: string
          quantity?: number
          size?: string
        }
        Relationships: [
          {
            foreignKeyName: "order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          address: string
          courier_booking: Json | null
          created_at: string
          customer_name: string
          delivery_area: string
          email: string
          id: string
          items_count: number
          payment_method: string
          phone: string
          status: string
          total: number
        }
        Insert: {
          address?: string
          courier_booking?: Json | null
          created_at?: string
          customer_name: string
          delivery_area?: string
          email?: string
          id: string
          items_count?: number
          payment_method?: string
          phone?: string
          status?: string
          total?: number
        }
        Update: {
          address?: string
          courier_booking?: Json | null
          created_at?: string
          customer_name?: string
          delivery_area?: string
          email?: string
          id?: string
          items_count?: number
          payment_method?: string
          phone?: string
          status?: string
          total?: number
        }
        Relationships: []
      }
      product_images: {
        Row: {
          created_at: string
          id: number
          image_url: string
          product_id: number
          sort_order: number
        }
        Insert: {
          created_at?: string
          id?: number
          image_url?: string
          product_id: number
          sort_order?: number
        }
        Update: {
          created_at?: string
          id?: number
          image_url?: string
          product_id?: number
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "product_images_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      products: {
        Row: {
          badge: string
          category: string
          colors: Json
          created_at: string
          description: string
          has_color_variations: boolean
          id: number
          image: string
          name: string
          original_price: number
          price: number
          rating: number
          reviews: number
          sizes: Json
          stock: number
          updated_at: string
        }
        Insert: {
          badge?: string
          category?: string
          colors?: Json
          created_at?: string
          description?: string
          has_color_variations?: boolean
          id?: number
          image?: string
          name: string
          original_price?: number
          price?: number
          rating?: number
          reviews?: number
          sizes?: Json
          stock?: number
          updated_at?: string
        }
        Update: {
          badge?: string
          category?: string
          colors?: Json
          created_at?: string
          description?: string
          has_color_variations?: boolean
          id?: number
          image?: string
          name?: string
          original_price?: number
          price?: number
          rating?: number
          reviews?: number
          sizes?: Json
          stock?: number
          updated_at?: string
        }
        Relationships: []
      }
      store_settings: {
        Row: {
          created_at: string
          id: number
          key: string
          value: string
        }
        Insert: {
          created_at?: string
          id?: number
          key: string
          value?: string
        }
        Update: {
          created_at?: string
          id?: number
          key?: string
          value?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      generate_order_id: { Args: never; Returns: string }
      reset_all_data: { Args: never; Returns: undefined }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
