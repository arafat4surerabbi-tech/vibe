import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

interface DevSettings {
  siteBlocked: boolean;
  adminBlocked: boolean;
  blockMessage: string;
  adminBlockMessage: string;
  hostingExpired: boolean;
  loading: boolean;
}

export const useDevSettings = (): DevSettings => {
  const [settings, setSettings] = useState<DevSettings>({
    siteBlocked: false,
    adminBlocked: false,
    blockMessage: "This website is currently unavailable.",
    adminBlockMessage: "Admin panel is currently unavailable.",
    hostingExpired: false,
    loading: true,
  });

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.from("dev_settings").select("*");
      if (data) {
        const map: Record<string, string> = {};
        data.forEach((r: any) => { map[r.key] = r.value; });

        let hostingExpired = false;
        if (map.hosting_expiry) {
          hostingExpired = new Date(map.hosting_expiry) < new Date();
        }

        setSettings({
          siteBlocked: map.site_blocked === "true",
          adminBlocked: map.admin_blocked === "true",
          blockMessage: map.block_message || "This website is currently unavailable.",
          adminBlockMessage: map.admin_block_message || "Admin panel is currently unavailable.",
          hostingExpired,
          loading: false,
        });
      } else {
        setSettings(prev => ({ ...prev, loading: false }));
      }
    };
    load();
  }, []);

  return settings;
};
