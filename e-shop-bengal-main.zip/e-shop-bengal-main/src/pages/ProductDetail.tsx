import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ShoppingCart, ChevronLeft, Minus, Plus, MessageCircle, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useStore } from "@/contexts/StoreContext";
import SiteHeader from "@/components/website/SiteHeader";
import SiteFooter from "@/components/website/SiteFooter";
import ProductCard from "@/components/website/ProductCard";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { products, addToCart, storeSettings } = useStore();
  
  const product = products.find((p) => p.id === Number(id));

  const [selectedSize, setSelectedSize] = useState("");
  const [selectedColor, setSelectedColor] = useState("");
  const [qty, setQty] = useState(1);
  const [showColors, setShowColors] = useState(false);
  const [allImages, setAllImages] = useState<string[]>([]);
  const [activeImage, setActiveImage] = useState(0);

  // Load product images
  useEffect(() => {
    if (!product) return;
    const loadImages = async () => {
      const { data } = await supabase
        .from("product_images")
        .select("image_url")
        .eq("product_id", product.id)
        .order("sort_order");
      if (data && data.length > 0) {
        setAllImages(data.map((r: any) => r.image_url));
      } else if (product.image) {
        setAllImages([product.image]);
      } else {
        setAllImages([]);
      }
      setActiveImage(0);
    };
    loadImages();
  }, [product]);

  // Meta Pixel: ViewContent event
  useEffect(() => {
    if (!product) return;
    const track = (window as any).__metaTrack;
    if (track) {
      track("ViewContent", {
        content_name: product.name,
        content_ids: [String(product.id)],
        content_type: "product",
        value: product.price,
        currency: "BDT",
      });
    }
  }, [product]);

  if (!product) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="container mx-auto px-4 py-20 text-center">
          <p className="text-muted-foreground text-lg">Product not found</p>
          <Button onClick={() => navigate("/")} className="mt-4 rounded-full">Go Home</Button>
        </div>
        <SiteFooter />
      </div>
    );
  }

  const related = products.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4);

  const handleAddToCart = (openCart = true) => {
    const size = selectedSize || product.sizes[0];
    const color = selectedColor || product.colors[0];
    addToCart(product, size, color, qty, openCart);
  };

  const currentImage = allImages[activeImage] || product.image;

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="container mx-auto px-4 py-6">

        <div className="grid md:grid-cols-2 gap-8">
          {/* Image Gallery */}
          <div className="space-y-3">
            <div className="relative bg-muted rounded-xl overflow-hidden">
              {currentImage ? (
                <img src={currentImage} alt={product.name} className="w-full h-auto object-contain" />
              ) : (
                <div className="aspect-square flex items-center justify-center">
                  <span className="text-9xl opacity-20">👕</span>
                </div>
              )}
              {product.badge && (
                <Badge className="absolute top-4 left-4 bg-primary text-primary-foreground font-heading">{product.badge}</Badge>
              )}
            </div>
            {/* Thumbnails */}
            {allImages.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-1">
                {allImages.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImage(i)}
                    className={`shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 transition-all ${
                      i === activeImage ? "border-primary" : "border-border hover:border-foreground/30"
                    }`}
                  >
                    <img src={img} alt={`${product.name} ${i + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Details */}
          <div className="space-y-5">
            <div>
              <p className="text-sm text-muted-foreground font-body">{product.category}</p>
              <h1 className="font-heading text-2xl md:text-3xl font-bold text-foreground">{product.name}</h1>
            </div>

            <div className="flex items-baseline gap-3">
              <span className="font-heading text-3xl font-bold text-foreground">৳{product.price.toLocaleString()}</span>
              {product.originalPrice > product.price && (
                <span className="text-lg text-muted-foreground line-through">৳{product.originalPrice.toLocaleString()}</span>
              )}
            </div>

            {/* Colors */}
            {product.hasColorVariations && product.colors.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <Label className="text-sm font-medium text-foreground font-body">Color Variations</Label>
                  <Switch checked={showColors} onCheckedChange={setShowColors} />
                </div>
                {showColors && (
                  <Select value={selectedColor} onValueChange={setSelectedColor}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select a color" />
                    </SelectTrigger>
                    <SelectContent>
                      {product.colors.map((c) => (
                        <SelectItem key={c} value={c}>
                          <div className="flex items-center gap-2">
                            <span className="w-4 h-4 rounded-full border border-border inline-block" style={{ backgroundColor: c }} />
                            <span>{c}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            )}

            {/* Sizes */}
            {product.sizes.length > 0 && (
              <div>
                <p className="text-sm font-medium text-foreground mb-2 font-body">Size</p>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((s) => (
                    <button
                      key={s}
                      onClick={() => setSelectedSize(s)}
                      className={`px-4 py-2 rounded-lg border text-sm font-medium font-body transition-all ${
                        selectedSize === s
                          ? "bg-primary text-primary-foreground border-primary"
                          : "border-border text-foreground hover:border-foreground"
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Qty */}
            <div>
              <p className="text-sm font-medium text-foreground mb-2 font-body">Quantity</p>
              <div className="flex items-center gap-3">
                <button onClick={() => setQty(Math.max(1, qty - 1))} className="w-9 h-9 rounded-lg border border-border flex items-center justify-center hover:bg-muted">
                  <Minus className="h-4 w-4" />
                </button>
                <span className="font-medium text-lg w-8 text-center">{qty}</span>
                <button onClick={() => setQty(qty + 1)} className="w-9 h-9 rounded-lg border border-border flex items-center justify-center hover:bg-muted">
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            </div>

            {product.stock < 20 && (
              <p className="text-sm text-destructive font-medium">Only {product.stock} left in stock!</p>
            )}

            <div className="flex flex-col gap-3">
              <div className="flex gap-3">
                <Button size="lg" className="flex-1 rounded-full font-heading" onClick={() => { handleAddToCart(false); navigate("/checkout"); }}>
                  Buy Now
                </Button>
                <Button size="lg" variant="secondary" className="flex-1 rounded-full font-heading" onClick={() => handleAddToCart()}>
                  <ShoppingCart className="h-5 w-5 mr-2" /> Add to Cart
                </Button>
              </div>
              <div className="flex gap-3">
                <Button size="lg" className="flex-1 rounded-full font-heading bg-[#22C55E] text-white hover:bg-[#1EA34D] border-none" asChild>
                  <a href={`https://wa.me/${storeSettings.whatsapp_number || '8801700000000'}?text=Hi, I'm interested in ${encodeURIComponent(product.name)} (৳${product.price})`} target="_blank" rel="noopener noreferrer">
                    <MessageCircle className="h-5 w-5 mr-2" /> WhatsApp
                  </a>
                </Button>
                <Button size="lg" className="flex-1 rounded-full font-heading bg-[#3B82F6] text-white hover:bg-[#2563EB] border-none" asChild>
                  <a href={`tel:+${storeSettings.call_number || '8801700000000'}`}>
                    <Phone className="h-5 w-5 mr-2" /> Call Now
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="details" className="mt-10">
          <TabsList className="bg-muted rounded-full">
            <TabsTrigger value="details" className="rounded-full font-heading">Details</TabsTrigger>
            <TabsTrigger value="size-chart" className="rounded-full font-heading">Size Chart</TabsTrigger>
          </TabsList>
          <TabsContent value="details" className="mt-4">
            <div className="bg-card rounded-xl p-6 border border-border/50">
              <p className="text-muted-foreground font-heading leading-relaxed">{product.description || "No description available."}</p>
            </div>
          </TabsContent>
          <TabsContent value="size-chart" className="mt-4">
            <div className="bg-card rounded-xl p-6 border border-border/50">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-muted-foreground">
                    <th className="py-2 text-left">Size</th><th className="py-2">Chest (in)</th><th className="py-2">Length (in)</th>
                  </tr>
                </thead>
                <tbody className="text-center text-foreground">
                  <tr className="border-b border-border/50"><td className="py-2 text-left">M</td><td>38</td><td>28</td></tr>
                  <tr className="border-b border-border/50"><td className="py-2 text-left">L</td><td>40</td><td>29</td></tr>
                  <tr className="border-b border-border/50"><td className="py-2 text-left">XL</td><td>42</td><td>30</td></tr>
                  <tr><td className="py-2 text-left">XXL</td><td>44</td><td>31</td></tr>
                </tbody>
              </table>
            </div>
          </TabsContent>
        </Tabs>

        {/* Related */}
        {related.length > 0 && (
          <section className="mt-12">
            <h2 className="font-heading text-2xl font-bold text-foreground mb-6">Related Products</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {related.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </section>
        )}
      </main>
      <SiteFooter />
    </div>
  );
};

export default ProductDetail;
