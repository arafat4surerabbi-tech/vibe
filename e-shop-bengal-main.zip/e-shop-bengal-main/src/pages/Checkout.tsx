import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useStore } from "@/contexts/StoreContext";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import SiteHeader from "@/components/website/SiteHeader";
import SiteFooter from "@/components/website/SiteFooter";

const Checkout = () => {
  const { cart, cartTotal, clearCart, deliveryZones, storeSettings } = useStore();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [deliveryArea, setDeliveryArea] = useState("1");
  const [payment, setPayment] = useState("cod");
  const [submitting, setSubmitting] = useState(false);

  // Field visibility from store settings (default true)
  const showName = storeSettings.checkout_field_name !== "false";
  const showPhone = storeSettings.checkout_field_phone !== "false";
  const showEmail = storeSettings.checkout_field_email !== "false";
  const showAddress = storeSettings.checkout_field_address !== "false";
  const showDeliveryArea = storeSettings.checkout_field_delivery_area !== "false";
  const showPaymentMethod = storeSettings.checkout_field_payment_method !== "false";

  // Meta Pixel: InitiateCheckout event
  useEffect(() => {
    if (cart.length === 0) return;
    const track = (window as any).__metaTrack;
    if (track) {
      track("InitiateCheckout", {
        content_ids: cart.map((c) => String(c.product.id)),
        num_items: cart.length,
        value: cartTotal,
        currency: "BDT",
      });
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const activeZones = deliveryZones.filter((z) => z.enabled);
  const selectedZone = activeZones.find((z) => z.id.toString() === deliveryArea) || activeZones[0];
  const deliveryCharge = showDeliveryArea ? (selectedZone?.charge || 60) : 0;
  const grandTotal = cartTotal + deliveryCharge;

  const handleOrder = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitting(true);
    const fd = new FormData(e.currentTarget);
    const customerName = (fd.get("name") as string) || "Customer";
    const phone = (fd.get("phone") as string) || "";
    const email = (fd.get("email") as string) || "";
    const address = (fd.get("address") as string) || "";

    try {
      const { data: orderIdData } = await supabase.rpc("generate_order_id");
      const orderId = orderIdData || `ORD-${Date.now()}`;

      await supabase.from("orders").insert({
        id: orderId,
        customer_name: customerName,
        items_count: cart.length,
        total: grandTotal,
        status: "Pending",
        phone,
        email,
        address,
        delivery_area: selectedZone?.name || "",
        payment_method: payment,
      } as any);

      const items = cart.map((c) => ({
        order_id: orderId,
        product_name: c.product.name,
        quantity: c.quantity,
        price: c.product.price,
        image: c.product.image || "",
        size: c.size || "",
        color: c.color || "",
      }));
      await supabase.from("order_items").insert(items as any);

      const { data: existingCustomer } = await supabase
        .from("customers")
        .select("id, orders_count, total_spent")
        .eq("phone", phone || "N/A")
        .maybeSingle();

      if (existingCustomer) {
        await supabase.from("customers").update({
          name: customerName,
          email,
          address,
          orders_count: (existingCustomer as any).orders_count + 1,
          total_spent: Number((existingCustomer as any).total_spent) + grandTotal,
        } as any).eq("id", (existingCustomer as any).id);
      } else {
        const custId = `C${String(Date.now()).slice(-6)}`;
        await supabase.from("customers").insert({
          id: custId,
          name: customerName,
          email,
          phone: phone || "N/A",
          orders_count: 1,
          total_spent: grandTotal,
          join_date: new Date().toISOString().split("T")[0],
          status: "active",
          address,
        } as any);
      }

      // Meta Pixel: Purchase event
      const track = (window as any).__metaTrack;
      if (track) {
        track("Purchase", {
          content_ids: cart.map((c) => String(c.product.id)),
          num_items: cart.length,
          value: grandTotal,
          currency: "BDT",
        });
      }

      clearCart();
      toast({ title: "Order placed!", description: `Order ${orderId} confirmed.` });
      navigate("/");
    } catch (err) {
      toast({ title: "Order failed", description: "Please try again.", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="container mx-auto px-4 py-20 text-center">
          <p className="text-muted-foreground">Your cart is empty.</p>
          <Button onClick={() => navigate("/")} className="mt-4 rounded-full">Continue Shopping</Button>
        </div>
        <SiteFooter />
      </div>
    );
  }

  const hasContactFields = showName || showPhone || showEmail || showAddress;

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="container mx-auto px-4 py-6">
        <h1 className="font-heading text-2xl font-bold mb-6">Checkout</h1>
        <form onSubmit={handleOrder} className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-4">
            {hasContactFields && (
              <Card className="border-border/50">
                <CardHeader><CardTitle className="font-heading text-base">Contact Information</CardTitle></CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    {showName && <div><Label className="font-body text-sm">Full Name</Label><Input name="name" required className="rounded-lg" /></div>}
                    {showPhone && <div><Label className="font-body text-sm">Phone</Label><Input name="phone" required className="rounded-lg" /></div>}
                  </div>
                  {showEmail && <div><Label className="font-body text-sm">Email (optional)</Label><Input name="email" type="email" className="rounded-lg" /></div>}
                  {showAddress && <div><Label className="font-body text-sm">Address</Label><Input name="address" required className="rounded-lg" /></div>}
                </CardContent>
              </Card>
            )}

            {showDeliveryArea && (
              <Card className="border-border/50">
                <CardHeader><CardTitle className="font-heading text-base">Delivery Area</CardTitle></CardHeader>
                <CardContent>
                  <RadioGroup value={deliveryArea} onValueChange={setDeliveryArea} className="space-y-2">
                    {activeZones.map((z) => (
                      <label key={z.id} className="flex items-center gap-3 p-3 rounded-lg border border-border/50 hover:bg-muted/50 cursor-pointer">
                        <RadioGroupItem value={z.id.toString()} />
                        <span className="flex-1 text-sm font-body">{z.name}</span>
                        <span className="text-sm font-medium">৳{z.charge}</span>
                      </label>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>
            )}

            {showPaymentMethod && (
              <Card className="border-border/50">
                <CardHeader><CardTitle className="font-heading text-base">Payment Method</CardTitle></CardHeader>
                <CardContent>
                  <div className="flex items-center gap-3 p-3 rounded-lg border border-border/50 bg-muted/50">
                    <span className="text-sm font-body">Cash on Delivery (COD)</span>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          <div>
            <Card className="border-border/50 sticky top-20">
              <CardHeader><CardTitle className="font-heading text-base">Order Summary</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                {cart.map((item) => (
                  <div key={`${item.product.id}-${item.size}`} className="flex items-center gap-3 text-sm">
                    <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center shrink-0 overflow-hidden">
                      {item.product.image ? (
                        <img src={item.product.image} alt={item.product.name} className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-sm opacity-30">👕</span>
                      )}
                    </div>
                    <span className="text-muted-foreground truncate flex-1">{item.product.name} × {item.quantity}</span>
                    <span className="font-medium shrink-0">৳{(item.product.price * item.quantity).toLocaleString()}</span>
                  </div>
                ))}
                <div className="border-t border-border pt-3 space-y-2">
                  <div className="flex justify-between text-sm"><span className="text-muted-foreground">Subtotal</span><span>৳{cartTotal.toLocaleString()}</span></div>
                  {showDeliveryArea && <div className="flex justify-between text-sm"><span className="text-muted-foreground">Delivery</span><span>৳{deliveryCharge}</span></div>}
                  <div className="flex justify-between font-heading font-bold text-lg border-t border-border pt-2"><span>Total</span><span>৳{grandTotal.toLocaleString()}</span></div>
                </div>
                <Button type="submit" className="w-full rounded-full font-heading" size="lg" disabled={submitting}>
                  {submitting ? "Placing Order..." : "Place Order"}
                </Button>
              </CardContent>
            </Card>
          </div>
        </form>
      </main>
      <SiteFooter />
    </div>
  );
};

export default Checkout;