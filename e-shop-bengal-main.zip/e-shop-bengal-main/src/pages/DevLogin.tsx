import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Shield } from "lucide-react";

const DevLogin = () => {
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const { data } = await supabase
      .from("dev_settings")
      .select("value")
      .eq("key", "dev_password")
      .maybeSingle();

    if (data && data.value === password) {
      sessionStorage.setItem("dev_authenticated", "true");
      navigate("/dev-panel");
    } else {
      toast({ title: "Invalid password", variant: "destructive" });
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-sm border-border/50">
        <CardHeader className="text-center">
          <Shield className="h-10 w-10 mx-auto text-primary mb-2" />
          <CardTitle className="font-heading text-xl">Developer Access</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label>Password</Label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter developer password"
                required
              />
            </div>
            <Button type="submit" className="w-full rounded-full" disabled={loading}>
              {loading ? "Verifying..." : "Access Panel"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default DevLogin;
