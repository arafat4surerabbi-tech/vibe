import { Navigate } from "react-router-dom";
import DevPanelContent from "@/components/dev/DevPanelContent";

const DevPanel = () => {
  const isAuth = sessionStorage.getItem("dev_authenticated") === "true";
  if (!isAuth) return <Navigate to="/dev-login" replace />;

  return (
    <div className="min-h-screen bg-background">
      <DevPanelContent />
    </div>
  );
};

export default DevPanel;
