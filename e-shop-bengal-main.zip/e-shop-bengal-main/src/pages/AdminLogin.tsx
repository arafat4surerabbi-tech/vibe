import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { Loader2, Lock } from "lucide-react";

const AdminLogin = () => {
  const { signIn, signUp } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [mode, setMode] = useState<"login" | "register">("login");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    if (mode === "login") {
      const { error } = await signIn(email, password);
      if (error) {
        setError(error);
        setLoading(false);
      } else {
        navigate("/admin");
      }
    } else {
      const { error } = await signUp(email, password);
      if (error) {
        setError(error);
        setLoading(false);
      } else {
        setError("");
        setMode("login");
        setLoading(false);
        setError("Account created! Please check your email to verify, then log in.");
      }
    }
  };

  return (
    <div className="min-h-screen bg-admin-secondary flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-admin-accent/30 bg-white">
        <CardHeader className="text-center">
          <div className="mx-auto w-12 h-12 bg-admin-accent rounded-full flex items-center justify-center mb-2">
            <Lock className="h-6 w-6 text-admin-accent-foreground" />
          </div>
          <CardTitle className="font-heading text-2xl text-admin">
            {mode === "login" ? "Admin Login" : "Create Admin Account"}
          </CardTitle>
          <CardDescription className="font-body">
            {mode === "login" ? "Sign in to manage your store" : "Register a new admin account"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label className="font-body">Email</Label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="rounded-lg"
                placeholder="admin@example.com"
              />
            </div>
            <div>
              <Label className="font-body">Password</Label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="rounded-lg"
                minLength={6}
                placeholder="••••••••"
              />
            </div>
            {error && (
              <p className={`text-sm ${error.includes("created") ? "text-success" : "text-destructive"}`}>
                {error}
              </p>
            )}
            <Button type="submit" className="w-full rounded-full font-heading bg-admin-accent hover:bg-admin-accent/90 text-admin-accent-foreground" disabled={loading}>
              {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {mode === "login" ? "Sign In" : "Create Account"}
            </Button>
          </form>
          <div className="mt-4 text-center">
            <button
              type="button"
              onClick={() => { setMode(mode === "login" ? "register" : "login"); setError(""); }}
              className="text-sm text-admin-accent hover:underline font-body"
            >
              {mode === "login" ? "Need an account? Register" : "Already have an account? Sign in"}
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminLogin;
