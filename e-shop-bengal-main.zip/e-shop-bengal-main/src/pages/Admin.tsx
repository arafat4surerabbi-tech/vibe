import { useAuth } from "@/hooks/useAuth";
import { Navigate } from "react-router-dom";
import AdminPanel from "@/components/admin/AdminPanel";
import { Spinner } from "@/components/ui/spinner";

const Admin = () => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Spinner size="large" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/admin/login" replace />;
  }

  return (
    <div className="min-h-screen bg-background">
      <AdminPanel />
    </div>
  );
};

export default Admin;
