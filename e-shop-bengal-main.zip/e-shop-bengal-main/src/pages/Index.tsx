import SiteHeader from "@/components/website/SiteHeader";
import HeroBanner from "@/components/website/HeroBanner";
import CategoryGrid from "@/components/website/CategoryGrid";
import FeaturedProducts from "@/components/website/FeaturedProducts";
import NewArrivals from "@/components/website/NewArrivals";
import CategorySection from "@/components/website/CategorySection";
import SiteFooter from "@/components/website/SiteFooter";


const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="container mx-auto">
        <HeroBanner />
        <CategoryGrid />
        <FeaturedProducts />
        <NewArrivals />
        <CategorySection id="collections" title="New Collections" filterType="badge" filterValue="New" />
        <CategorySection id="men" title="Men" filterType="category" filterValue="Men" />
      </main>
      <SiteFooter />
      
    </div>
  );
};

export default Index;
