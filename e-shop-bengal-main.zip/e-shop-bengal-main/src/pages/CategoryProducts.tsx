import { useParams, useNavigate } from "react-router-dom";
import { useStore } from "@/contexts/StoreContext";
import SiteHeader from "@/components/website/SiteHeader";
import SiteFooter from "@/components/website/SiteFooter";
import ProductCard from "@/components/website/ProductCard";


const CategoryProducts = () => {
  const { name } = useParams();
  const navigate = useNavigate();
  const { products, categories } = useStore();

  const categoryName = decodeURIComponent(name || "");
  const category = categories.find(
    (c) => c.name.toLowerCase() === categoryName.toLowerCase()
  );

  const filtered = products.filter(
    (p) => p.category.toLowerCase() === categoryName.toLowerCase()
  );

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="container mx-auto px-4 py-6">
        <div className="mb-6">
          <h1 className="font-heading text-2xl md:text-3xl font-bold text-foreground">
            {category?.name || categoryName}
          </h1>
        </div>
        {filtered.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {filtered.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <p className="text-muted-foreground text-lg font-body">
              No products found in this category.
            </p>
          </div>
        )}
      </main>
      <SiteFooter />
      
    </div>
  );
};

export default CategoryProducts;
