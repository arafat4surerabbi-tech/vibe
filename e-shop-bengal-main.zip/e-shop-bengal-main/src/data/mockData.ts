export const categories = [
  { id: 1, name: "Men", namebn: "পুরুষ", icon: "👔", count: 245, image: "" },
  { id: 2, name: "Women", namebn: "মহিলা", icon: "👗", count: 312, image: "" },
  { id: 3, name: "Kids", namebn: "শিশু", icon: "🧒", count: 128, image: "" },
  { id: 4, name: "Accessories", namebn: "এক্সেসরিজ", icon: "👜", count: 89, image: "" },
];

export const products = [
  { id: 1, name: "Premium Cotton Panjabi", price: 2450, originalPrice: 3200, image: "", category: "Men", rating: 4.5, reviews: 128, badge: "New", colors: ["#1a1a2e", "#e8d5b7", "#2d4a3e"], sizes: ["S", "M", "L", "XL"], stock: 45 },
  { id: 2, name: "Jamdani Saree Collection", price: 8500, originalPrice: 12000, image: "", category: "Women", rating: 4.8, reviews: 256, badge: "Best Seller", colors: ["#c9184a", "#ff6b6b", "#4ecdc4"], sizes: ["Free"], stock: 12 },
  { id: 3, name: "Designer Kurti Set", price: 1850, originalPrice: 2500, image: "", category: "Women", rating: 4.3, reviews: 89, badge: "Sale", colors: ["#ff6b6b", "#ffd93d", "#6bcb77"], sizes: ["S", "M", "L"], stock: 67 },
  { id: 4, name: "Kids Party Dress", price: 1200, originalPrice: 1800, image: "", category: "Kids", rating: 4.6, reviews: 45, badge: "New", colors: ["#ff85a2", "#a855f7", "#60a5fa"], sizes: ["2-3Y", "4-5Y", "6-7Y"], stock: 34 },
  { id: 5, name: "Leather Wallet Premium", price: 950, originalPrice: 1400, image: "", category: "Accessories", rating: 4.2, reviews: 67, badge: "", colors: ["#1a1a2e", "#8b4513"], sizes: ["Free"], stock: 89 },
  { id: 6, name: "Silk Fatua Collection", price: 3200, originalPrice: 4500, image: "", category: "Men", rating: 4.7, reviews: 156, badge: "Trending", colors: ["#2d4a3e", "#c9184a", "#e8d5b7"], sizes: ["M", "L", "XL", "XXL"], stock: 23 },
  { id: 7, name: "Embroidered Salwar Kameez", price: 4500, originalPrice: 6000, image: "", category: "Women", rating: 4.4, reviews: 198, badge: "", colors: ["#ff6b6b", "#4ecdc4", "#ffd93d"], sizes: ["S", "M", "L", "XL"], stock: 56 },
  { id: 8, name: "Handcrafted Jute Bag", price: 650, originalPrice: 900, image: "", category: "Accessories", rating: 4.1, reviews: 34, badge: "Eco", colors: ["#8b4513", "#d4a574"], sizes: ["Free"], stock: 120 },
];

export const orders = [
  { id: "ORD-1001", customer: "Rahim Ahmed", items: 3, total: 5600, status: "Processing", date: "2026-04-10", phone: "01712345678" },
  { id: "ORD-1002", customer: "Fatima Begum", items: 1, total: 8500, status: "Shipped", date: "2026-04-09", phone: "01898765432" },
  { id: "ORD-1003", customer: "Kamal Hossain", items: 2, total: 3650, status: "Delivered", date: "2026-04-08", phone: "01556789012" },
  { id: "ORD-1004", customer: "Nasreen Akter", items: 4, total: 12400, status: "Pending", date: "2026-04-10", phone: "01634567890" },
  { id: "ORD-1005", customer: "Sumon Das", items: 1, total: 2450, status: "Processing", date: "2026-04-11", phone: "01987654321" },
];

export const dashboardStats = {
  totalSales: 245600,
  totalOrders: 342,
  totalCustomers: 1256,
  totalProducts: 774,
  monthlySales: [
    { month: "Jan", sales: 18500 },
    { month: "Feb", sales: 22000 },
    { month: "Mar", sales: 19800 },
    { month: "Apr", sales: 28500 },
    { month: "May", sales: 32000 },
    { month: "Jun", sales: 27500 },
  ],
  topProducts: [
    { name: "Jamdani Saree", sold: 256, revenue: 2176000 },
    { name: "Cotton Panjabi", sold: 198, revenue: 485100 },
    { name: "Designer Kurti", sold: 167, revenue: 308950 },
    { name: "Silk Fatua", sold: 134, revenue: 428800 },
  ],
  lowStockProducts: [
    { name: "Jamdani Saree Collection", stock: 12, threshold: 15 },
    { name: "Silk Fatua Collection", stock: 23, threshold: 25 },
  ],
};
