import { createContext, useContext, useState, ReactNode, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface Product {
  id: number;
  name: string;
  price: number;
  originalPrice: number;
  image: string;
  category: string;
  rating: number;
  reviews: number;
  badge: string;
  colors: string[];
  sizes: string[];
  stock: number;
  description?: string;
  hasColorVariations?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
  size: string;
  color: string;
}

export interface Order {
  id: string;
  customer: string;
  items: number;
  total: number;
  status: string;
  date: string;
  phone: string;
  email?: string;
  address?: string;
  deliveryArea?: string;
  paymentMethod?: string;
  products?: { name: string; qty: number; price: number; image?: string; size?: string; color?: string }[];
  courierBooking?: CourierBooking | null;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  orders: number;
  totalSpent: number;
  joinDate: string;
  status: "active" | "blocked";
  address: string;
}

export interface Coupon {
  id: string;
  code: string;
  discount: number;
  type: "percent" | "fixed";
  minOrder: number;
  maxUses: number;
  usedCount: number;
  expiry: string;
  active: boolean;
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  cta: string;
  bg: string;
  image: string;
  enabled: boolean;
  link?: string;
}

export interface Category {
  id: number;
  name: string;
  icon: string;
  image: string;
  count: number;
  enabled: boolean;
}

export interface DeliveryZone {
  id: number;
  name: string;
  charge: number;
  enabled: boolean;
}

export interface CourierConfig {
  id: string;
  name: string;
  enabled: boolean;
  apiKey: string;
  apiSecret: string;
  baseUrl: string;
  username?: string;
  password?: string;
  storeId?: string;
}

export interface CourierBooking {
  courierId: string;
  courierName: string;
  trackingId: string;
  consignmentId?: string;
  trackingLink?: string;
  status: string;
  bookedAt: string;
}

interface StoreContextType {
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  cart: CartItem[];
  addToCart: (product: Product, size: string, color: string, qty?: number, openCart?: boolean) => void;
  removeFromCart: (productId: number, size: string, color: string) => void;
  updateCartQty: (productId: number, size: string, color: string, qty: number) => void;
  clearCart: () => void;
  cartTotal: number;
  cartCount: number;
  wishlist: number[];
  toggleWishlist: (id: number) => void;
  orders: Order[];
  setOrders: React.Dispatch<React.SetStateAction<Order[]>>;
  updateOrderStatus: (orderId: string, status: string) => void;
  customers: Customer[];
  setCustomers: React.Dispatch<React.SetStateAction<Customer[]>>;
  coupons: Coupon[];
  setCoupons: React.Dispatch<React.SetStateAction<Coupon[]>>;
  cartOpen: boolean;
  setCartOpen: (open: boolean) => void;
  banners: Banner[];
  setBanners: React.Dispatch<React.SetStateAction<Banner[]>>;
  categories: Category[];
  setCategories: React.Dispatch<React.SetStateAction<Category[]>>;
  deliveryZones: DeliveryZone[];
  setDeliveryZones: React.Dispatch<React.SetStateAction<DeliveryZone[]>>;
  couriers: CourierConfig[];
  setCouriers: React.Dispatch<React.SetStateAction<CourierConfig[]>>;
  refreshProducts: () => Promise<void>;
  refreshOrders: () => Promise<void>;
  refreshCustomers: () => Promise<void>;
  refreshCoupons: () => Promise<void>;
  refreshBanners: () => Promise<void>;
  refreshCategories: () => Promise<void>;
  refreshDeliveryZones: () => Promise<void>;
  refreshCouriers: () => Promise<void>;
  dataLoading: boolean;
  storeSettings: Record<string, string>;
  refreshStoreSettings: () => Promise<void>;
}

const StoreContext = createContext<StoreContextType | null>(null);

export const useStore = () => {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
};

// Map DB rows to app types
const mapProduct = (r: any): Product => ({
  id: r.id,
  name: r.name,
  price: Number(r.price),
  originalPrice: Number(r.original_price),
  image: r.image || "",
  category: r.category || "",
  rating: Number(r.rating),
  reviews: r.reviews,
  badge: r.badge || "",
  colors: Array.isArray(r.colors) ? r.colors : JSON.parse(r.colors || "[]"),
  sizes: Array.isArray(r.sizes) ? r.sizes : JSON.parse(r.sizes || "[]"),
  stock: r.stock,
  description: r.description || "",
  hasColorVariations: r.has_color_variations || false,
});

const mapOrder = (r: any): Order => ({
  id: r.id,
  customer: r.customer_name,
  items: r.items_count,
  total: Number(r.total),
  status: r.status,
  date: r.created_at?.split("T")[0] || "",
  phone: r.phone,
  email: r.email || "",
  address: r.address || "",
  deliveryArea: r.delivery_area || "",
  paymentMethod: r.payment_method || "cod",
  courierBooking: r.courier_booking || null,
  // products will be loaded from order_items
});

const mapCustomer = (r: any): Customer => ({
  id: r.id,
  name: r.name,
  email: r.email || "",
  phone: r.phone || "",
  orders: r.orders_count,
  totalSpent: Number(r.total_spent),
  joinDate: r.join_date || "",
  status: r.status as "active" | "blocked",
  address: r.address || "",
});

const mapCoupon = (r: any): Coupon => ({
  id: r.id,
  code: r.code,
  discount: Number(r.discount),
  type: r.type as "percent" | "fixed",
  minOrder: Number(r.min_order),
  maxUses: r.max_uses,
  usedCount: r.used_count,
  expiry: r.expiry || "",
  active: r.active,
});

const mapBanner = (r: any): Banner => ({
  id: r.id,
  title: r.title || "",
  subtitle: r.subtitle || "",
  cta: r.cta || "Shop Now",
  bg: r.bg || "",
  image: r.image || "",
  enabled: r.enabled,
  link: r.link || "",
});

const mapCategory = (r: any): Category => ({
  id: r.id,
  name: r.name,
  icon: r.icon || "",
  image: r.image || "",
  count: r.count,
  enabled: r.enabled,
});

const mapDeliveryZone = (r: any): DeliveryZone => ({
  id: r.id,
  name: r.name,
  charge: Number(r.charge),
  enabled: r.enabled,
});

const mapCourier = (r: any): CourierConfig => ({
  id: r.id,
  name: r.name,
  enabled: r.enabled,
  apiKey: r.api_key || "",
  apiSecret: r.api_secret || "",
  baseUrl: r.base_url || "",
  username: r.username || "",
  password: r.password || "",
  storeId: r.store_id || "",
});

export const StoreProvider = ({ children }: { children: ReactNode }) => {
  const [productList, setProductList] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [orderList, setOrderList] = useState<Order[]>([]);
  const [customerList, setCustomerList] = useState<Customer[]>([]);
  const [couponList, setCouponList] = useState<Coupon[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [bannerList, setBannerList] = useState<Banner[]>([]);
  const [categoryList, setCategoryList] = useState<Category[]>([]);
  const [deliveryZones, setDeliveryZones] = useState<DeliveryZone[]>([]);
  const [courierList, setCourierList] = useState<CourierConfig[]>([]);
  const [dataLoading, setDataLoading] = useState(true);
  const [storeSettings, setStoreSettings] = useState<Record<string, string>>({});

  // Fetch functions
  const refreshProducts = useCallback(async () => {
    const { data } = await supabase.from("products").select("*").order("id");
    if (data) setProductList(data.map(mapProduct));
  }, []);

  const refreshOrders = useCallback(async () => {
    const { data } = await supabase.from("orders").select("*").order("created_at", { ascending: false });
    if (data) {
      // Also fetch order items for each order
      const orderIds = data.map((o: any) => o.id);
      const { data: items } = await supabase.from("order_items").select("*").in("order_id", orderIds);
      const itemsByOrder: Record<string, { name: string; qty: number; price: number; image?: string; size?: string; color?: string }[]> = {};
      (items || []).forEach((item: any) => {
        if (!itemsByOrder[item.order_id]) itemsByOrder[item.order_id] = [];
        itemsByOrder[item.order_id].push({ name: item.product_name, qty: item.quantity, price: Number(item.price), image: item.image || "", size: item.size || "", color: item.color || "" });
      });
      setOrderList(data.map((r: any) => ({ ...mapOrder(r), products: itemsByOrder[r.id] || [] })));
    }
  }, []);

  const refreshCustomers = useCallback(async () => {
    const { data } = await supabase.from("customers").select("*").order("created_at", { ascending: false });
    if (data) setCustomerList(data.map(mapCustomer));
  }, []);

  const refreshCoupons = useCallback(async () => {
    const { data } = await supabase.from("coupons").select("*").order("created_at", { ascending: false });
    if (data) setCouponList(data.map(mapCoupon));
  }, []);

  const refreshBanners = useCallback(async () => {
    const { data } = await supabase.from("banners").select("*").order("created_at");
    if (data) setBannerList(data.map(mapBanner));
  }, []);

  const refreshCategories = useCallback(async () => {
    const { data } = await supabase.from("categories").select("*").order("id");
    if (data) setCategoryList(data.map(mapCategory));
  }, []);

  const refreshDeliveryZones = useCallback(async () => {
    const { data } = await supabase.from("delivery_zones").select("*").order("id");
    if (data) setDeliveryZones(data.map(mapDeliveryZone));
  }, []);

  const refreshCouriers = useCallback(async () => {
    const { data } = await supabase.from("courier_configs").select("*").order("created_at");
    if (data) setCourierList(data.map(mapCourier));
  }, []);

  const refreshStoreSettings = useCallback(async () => {
    const { data } = await supabase.from("store_settings").select("*");
    if (data) {
      const map: Record<string, string> = {};
      data.forEach((r: any) => { map[r.key] = r.value; });
      setStoreSettings(map);
    }
  }, []);

  // Initial load - public data (products, categories, banners, delivery zones, settings)
  useEffect(() => {
    const loadPublicData = async () => {
      await Promise.all([
        refreshProducts(),
        refreshCategories(),
        refreshBanners(),
        refreshDeliveryZones(),
        refreshStoreSettings(),
      ]);
      setDataLoading(false);
    }
    loadPublicData();
  }, [refreshProducts, refreshCategories, refreshBanners, refreshDeliveryZones]);

  // Load admin-only data when authenticated
  useEffect(() => {
    const loadAdminData = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        await Promise.all([
          refreshOrders(),
          refreshCustomers(),
          refreshCoupons(),
          refreshCouriers(),
        ]);
      }
    };
    loadAdminData();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session) {
        Promise.all([
          refreshOrders(),
          refreshCustomers(),
          refreshCoupons(),
          refreshCouriers(),
        ]);
      }
    });

    return () => subscription.unsubscribe();
  }, [refreshOrders, refreshCustomers, refreshCoupons, refreshCouriers]);

  const addToCart = (product: Product, size: string, color: string, qty = 1, openCart = true) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.product.id === product.id && i.size === size && i.color === color);
      if (existing) {
        return prev.map((i) =>
          i.product.id === product.id && i.size === size && i.color === color
            ? { ...i, quantity: i.quantity + qty }
            : i
        );
      }
      return [...prev, { product, quantity: qty, size, color }];
    });
    
    // Meta Pixel: AddToCart
    if ((window as any).__metaTrack) {
      (window as any).__metaTrack("AddToCart", {
        content_name: product.name,
        content_ids: [String(product.id)],
        content_type: "product",
        value: product.price * qty,
        currency: "BDT",
      });
    }

    if (openCart) setCartOpen(true);
  };

  const removeFromCart = (productId: number, size: string, color: string) => {
    setCart((prev) => prev.filter((i) => !(i.product.id === productId && i.size === size && i.color === color)));
  };

  const updateCartQty = (productId: number, size: string, color: string, qty: number) => {
    if (qty <= 0) return removeFromCart(productId, size, color);
    setCart((prev) =>
      prev.map((i) =>
        i.product.id === productId && i.size === size && i.color === color ? { ...i, quantity: qty } : i
      )
    );
  };

  const clearCart = () => setCart([]);

  const cartTotal = cart.reduce((sum, i) => sum + i.product.price * i.quantity, 0);
  const cartCount = cart.reduce((sum, i) => sum + i.quantity, 0);

  const toggleWishlist = (id: number) => {
    setWishlist((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const updateOrderStatus = async (orderId: string, status: string) => {
    await supabase.from("orders").update({ status } as any).eq("id", orderId);
    setOrderList((prev) => prev.map((o) => (o.id === orderId ? { ...o, status } : o)));
  };

  useEffect(() => {
    if (storeSettings?.site_title) {
      document.title = storeSettings.site_title;
    }
    if (storeSettings?.flaticon_url) {
      let link = document.querySelector("link[rel~='icon']") as HTMLLinkElement;
      if (!link) {
        link = document.createElement("link");
        link.rel = "icon";
        document.head.appendChild(link);
      }
      link.href = storeSettings.flaticon_url;
    }
  }, [storeSettings?.site_title, storeSettings?.flaticon_url]);

  return (
    <StoreContext.Provider
      value={{
        products: productList,
        setProducts: setProductList,
        cart,
        addToCart,
        removeFromCart,
        updateCartQty,
        clearCart,
        cartTotal,
        cartCount,
        wishlist,
        toggleWishlist,
        orders: orderList,
        setOrders: setOrderList,
        updateOrderStatus,
        customers: customerList,
        setCustomers: setCustomerList,
        coupons: couponList,
        setCoupons: setCouponList,
        cartOpen,
        setCartOpen,
        banners: bannerList,
        setBanners: setBannerList,
        categories: categoryList,
        setCategories: setCategoryList,
        deliveryZones,
        setDeliveryZones,
        couriers: courierList,
        setCouriers: setCourierList,
        refreshProducts,
        refreshOrders,
        refreshCustomers,
        refreshCoupons,
        refreshBanners,
        refreshCategories,
        refreshDeliveryZones,
        refreshCouriers,
        dataLoading,
        storeSettings,
        refreshStoreSettings,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};
