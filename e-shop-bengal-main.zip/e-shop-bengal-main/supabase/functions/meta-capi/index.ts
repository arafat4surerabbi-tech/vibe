import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface CAPIEvent {
  event_name: string;
  event_time: number;
  event_id: string;
  event_source_url: string;
  action_source: "website";
  user_data: {
    client_ip_address?: string;
    client_user_agent?: string;
    fbc?: string;
    fbp?: string;
    em?: string[];
    ph?: string[];
  };
  custom_data?: Record<string, unknown>;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const { events } = body as { events: CAPIEvent[] };

    if (!events || !Array.isArray(events) || events.length === 0) {
      return new Response(
        JSON.stringify({ error: "No events provided" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get pixel ID and CAPI token from store_settings
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { data: settings } = await supabase
      .from("store_settings")
      .select("key, value")
      .in("key", ["meta_pixel_id", "meta_capi_token", "meta_pixel_enabled"]);

    const settingsMap: Record<string, string> = {};
    (settings || []).forEach((r: any) => {
      settingsMap[r.key] = r.value;
    });

    const pixelId = settingsMap.meta_pixel_id;
    const accessToken = settingsMap.meta_capi_token;
    const enabled = settingsMap.meta_pixel_enabled === "true";

    if (!enabled || !pixelId || !accessToken) {
      return new Response(
        JSON.stringify({ error: "Meta tracking not configured or disabled" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Add client IP and user agent from request headers
    const clientIp = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || 
                     req.headers.get("x-real-ip") || "";
    const userAgent = req.headers.get("user-agent") || "";

    const enrichedEvents = events.map((event) => ({
      ...event,
      user_data: {
        ...event.user_data,
        client_ip_address: clientIp || event.user_data?.client_ip_address,
        client_user_agent: userAgent || event.user_data?.client_user_agent,
      },
    }));

    // Send to Facebook Conversions API
    const fbResponse = await fetch(
      `https://graph.facebook.com/v21.0/${pixelId}/events?access_token=${accessToken}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ data: enrichedEvents }),
      }
    );

    const fbResult = await fbResponse.json();

    if (!fbResponse.ok) {
      console.error("Facebook CAPI error:", JSON.stringify(fbResult));
      return new Response(
        JSON.stringify({ error: "Facebook API error", details: fbResult }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ success: true, fb_response: fbResult }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("CAPI error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
