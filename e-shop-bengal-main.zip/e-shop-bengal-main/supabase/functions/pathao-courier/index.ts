const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const PATHAO_BASE_URL = "https://api-hermes.pathao.com";

interface TokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
}

async function getAccessToken(
  clientId: string,
  clientSecret: string,
  username: string,
  password: string
): Promise<string> {
  const res = await fetch(`${PATHAO_BASE_URL}/aladdin/api/v1/issue-token`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({
      client_id: clientId,
      client_secret: clientSecret,
      username,
      password,
      grant_type: "password",
    }),
  });

  const data = await res.json().catch(() => null);

  if (!res.ok || !data?.access_token) {
    throw new Error(data?.message || data?.error || "Failed to authenticate with Pathao");
  }

  return (data as TokenResponse).access_token;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { action, client_id, client_secret, username, password, ...params } = await req.json();

    const cid = typeof client_id === "string" ? client_id.trim() : "";
    const csec = typeof client_secret === "string" ? client_secret.trim() : "";
    const uname = typeof username === "string" ? username.trim() : "";
    const pwd = typeof password === "string" ? password.trim() : "";

    if (!cid || !csec || !uname || !pwd) {
      return new Response(
        JSON.stringify({ error: "Pathao credentials (client_id, client_secret, username, password) are required from Admin Panel setup." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const accessToken = await getAccessToken(cid, csec, uname, pwd);

    const authHeaders = {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      Accept: "application/json",
    };

    if (action === "get_stores") {
      const res = await fetch(`${PATHAO_BASE_URL}/aladdin/api/v1/stores`, {
        method: "GET",
        headers: authHeaders,
      });
      const data = await res.json().catch(() => null);
      return new Response(JSON.stringify(data), {
        status: res.ok ? 200 : res.status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "get_cities") {
      const res = await fetch(`${PATHAO_BASE_URL}/aladdin/api/v1/countries/1/city-list`, {
        method: "GET",
        headers: authHeaders,
      });
      const data = await res.json().catch(() => null);
      return new Response(JSON.stringify(data), {
        status: res.ok ? 200 : res.status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "get_zones") {
      const { city_id } = params;
      if (!city_id) {
        return new Response(JSON.stringify({ error: "city_id is required" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const res = await fetch(`${PATHAO_BASE_URL}/aladdin/api/v1/cities/${city_id}/zone-list`, {
        method: "GET",
        headers: authHeaders,
      });
      const data = await res.json().catch(() => null);
      return new Response(JSON.stringify(data), {
        status: res.ok ? 200 : res.status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "get_areas") {
      const { zone_id } = params;
      if (!zone_id) {
        return new Response(JSON.stringify({ error: "zone_id is required" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const res = await fetch(`${PATHAO_BASE_URL}/aladdin/api/v1/zones/${zone_id}/area-list`, {
        method: "GET",
        headers: authHeaders,
      });
      const data = await res.json().catch(() => null);
      return new Response(JSON.stringify(data), {
        status: res.ok ? 200 : res.status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "create_order") {
      const {
        store_id, merchant_order_id, recipient_name, recipient_phone,
        recipient_address, recipient_city, recipient_zone, recipient_area,
        delivery_type, item_type, item_quantity, item_weight,
        amount_to_collect, special_instruction,
      } = params;

      if (!store_id || !recipient_name || !recipient_phone || !recipient_address || !recipient_city || !recipient_zone) {
        return new Response(
          JSON.stringify({ error: "Missing required fields: store_id, recipient_name, recipient_phone, recipient_address, recipient_city, recipient_zone" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const orderBody: Record<string, unknown> = {
        store_id,
        merchant_order_id: merchant_order_id || "",
        recipient_name,
        recipient_phone,
        recipient_address,
        recipient_city,
        recipient_zone,
        recipient_area: recipient_area || "",
        delivery_type: delivery_type || 48,
        item_type: item_type || 2,
        special_instruction: special_instruction || "",
        item_quantity: item_quantity || 1,
        item_weight: item_weight || 0.5,
        amount_to_collect: amount_to_collect ?? 0,
      };

      const res = await fetch(`${PATHAO_BASE_URL}/aladdin/api/v1/orders`, {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify(orderBody),
      });

      const data = await res.json().catch(() => null);

      if (!res.ok) {
        return new Response(
          JSON.stringify({ error: data?.message || "Failed to create order on Pathao", details: data }),
          { status: res.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      return new Response(JSON.stringify(data), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(
      JSON.stringify({ error: "Invalid action. Use 'create_order', 'get_stores', 'get_cities', 'get_zones', or 'get_areas'." }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
