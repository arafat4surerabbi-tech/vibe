const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const STEADFAST_BASE_URL = "https://portal.packzy.com/api/v1";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { action, api_key, secret_key, ...params } = await req.json();
    const apiKey = typeof api_key === "string" ? api_key.trim() : "";
    const secretKey = typeof secret_key === "string" ? secret_key.trim() : "";

    if (!apiKey || !secretKey) {
      return new Response(
        JSON.stringify({ error: "Steadfast API credentials are required from Admin Panel setup." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const steadfastHeaders = {
      "Api-Key": apiKey,
      "Secret-Key": secretKey,
      "Content-Type": "application/json",
    };

    if (action === "create_order") {
      const { invoice, recipient_name, recipient_phone, recipient_address, cod_amount, note } = params;

      if (!invoice || !recipient_name || !recipient_phone || !recipient_address || cod_amount === undefined) {
        return new Response(
          JSON.stringify({ error: "Missing required fields: invoice, recipient_name, recipient_phone, recipient_address, cod_amount" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const response = await fetch(`${STEADFAST_BASE_URL}/create_order`, {
        method: "POST",
        headers: steadfastHeaders,
        body: JSON.stringify({
          invoice,
          recipient_name,
          recipient_phone,
          recipient_address,
          cod_amount,
          note: note || "",
        }),
      });

      const data = await response.json().catch(() => null);

      if (!response.ok) {
        return new Response(
          JSON.stringify({ error: data?.message || "Failed to create order on Steadfast", details: data }),
          { status: response.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      return new Response(JSON.stringify(data), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "check_status") {
      const { consignment_id } = params;

      if (!consignment_id) {
        return new Response(
          JSON.stringify({ error: "Missing consignment_id" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const response = await fetch(`${STEADFAST_BASE_URL}/status_by_cid/${consignment_id}`, {
        method: "GET",
        headers: steadfastHeaders,
      });

      const data = await response.json().catch(() => null);

      return new Response(JSON.stringify(data), {
        status: response.ok ? 200 : response.status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(
      JSON.stringify({ error: "Invalid action. Use 'create_order' or 'check_status'." }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";

    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
