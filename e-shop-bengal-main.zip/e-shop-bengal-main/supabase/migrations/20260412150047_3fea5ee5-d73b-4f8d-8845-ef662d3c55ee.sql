
CREATE OR REPLACE FUNCTION public.reset_all_data()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  TRUNCATE order_items, orders, customers, products, banners, categories, coupons, nav_links, delivery_zones, store_settings, courier_configs;

  -- Re-seed delivery zones
  INSERT INTO delivery_zones (name, charge, enabled) VALUES
    ('Inside Dhaka', 80, true),
    ('Outside Dhaka', 150, true);

  -- Re-seed courier configs
  INSERT INTO courier_configs (id, name, api_key, api_secret, base_url, enabled) VALUES
    ('steadfast', 'Steadfast', '', '', 'https://portal.steadfast.com.bd/api/v1', false),
    ('pathao', 'Pathao', '', '', 'https://api-hermes.pathao.com', false),
    ('redx', 'Redx', '', '', 'https://openapi.redx.com.bd/v1.0.0-beta', false);
END;
$$;
