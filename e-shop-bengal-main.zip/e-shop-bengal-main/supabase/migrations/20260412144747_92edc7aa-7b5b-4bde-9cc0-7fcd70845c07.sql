
CREATE OR REPLACE FUNCTION public.reset_all_data()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  DELETE FROM order_items;
  DELETE FROM orders;
  DELETE FROM customers;
  DELETE FROM products;
  DELETE FROM banners;
  DELETE FROM categories;
  DELETE FROM coupons;
  DELETE FROM nav_links;
  DELETE FROM delivery_zones;
  DELETE FROM store_settings;
  DELETE FROM courier_configs;
END;
$$;
