
CREATE TABLE public.dev_settings (
  id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  key text NOT NULL UNIQUE,
  value text NOT NULL DEFAULT '',
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.dev_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view dev settings" ON public.dev_settings FOR SELECT USING (true);
CREATE POLICY "Authenticated users can insert dev settings" ON public.dev_settings FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update dev settings" ON public.dev_settings FOR UPDATE TO authenticated USING (true);

-- Insert default settings
INSERT INTO public.dev_settings (key, value) VALUES
  ('site_blocked', 'false'),
  ('admin_blocked', 'false'),
  ('hosting_expiry', ''),
  ('block_message', 'This website is currently unavailable. Please contact the administrator.'),
  ('admin_block_message', 'Admin panel is currently unavailable. Please contact the developer.'),
  ('dev_password', 'dev@2024');
