
CREATE POLICY "Authenticated users can update order items"
ON public.order_items
FOR UPDATE
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can delete order items"
ON public.order_items
FOR DELETE
TO authenticated
USING (true);
