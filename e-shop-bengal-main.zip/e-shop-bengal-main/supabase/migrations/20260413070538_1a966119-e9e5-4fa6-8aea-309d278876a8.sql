
CREATE OR REPLACE FUNCTION public.reset_all_data()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  TRUNCATE product_images, order_items, orders, customers, products, banners, categories, coupons, nav_links, store_settings;

  INSERT INTO public.delivery_zones (id, name, charge, enabled)
  VALUES
    (1, 'Inside Dhaka', 60, false),
    (2, 'Dhaka Suburbs', 100, false),
    (3, 'Outside Dhaka', 150, false)
  ON CONFLICT (id) DO UPDATE
  SET
    name = EXCLUDED.name,
    charge = EXCLUDED.charge,
    enabled = false;

  PERFORM setval(
    'public.delivery_zones_id_seq',
    COALESCE((SELECT MAX(id) FROM public.delivery_zones), 1),
    true
  );

  INSERT INTO public.courier_configs (id, name, api_key, api_secret, base_url, username, password, store_id, enabled)
  VALUES
    ('pathao', 'Pathao', '', '', 'https://api-hermes.pathao.com', '', '', '', false),
    ('steadfast', 'Steadfast', '', '', 'https://portal.steadfast.com.bd/api/v1', '', '', '', false),
    ('redx', 'Redx', '', '', 'https://openapi.redx.com.bd/v1.0.0-beta', '', '', '', false)
  ON CONFLICT (id) DO UPDATE
  SET
    name = EXCLUDED.name,
    base_url = EXCLUDED.base_url,
    api_key = '',
    api_secret = '',
    username = '',
    password = '',
    store_id = '',
    enabled = false;
END;
$function$;
