
CREATE OR REPLACE FUNCTION public.reset_all_data()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  TRUNCATE order_items, orders, customers, products, banners, categories, coupons, nav_links, delivery_zones, store_settings, courier_configs;
END;
$$;
