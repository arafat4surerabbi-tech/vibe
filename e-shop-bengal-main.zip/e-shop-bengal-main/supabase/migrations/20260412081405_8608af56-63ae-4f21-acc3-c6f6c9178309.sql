
-- Add cta_color to banners
ALTER TABLE public.banners ADD COLUMN cta_color text NOT NULL DEFAULT '';

-- Create nav_links table
CREATE TABLE public.nav_links (
  id serial PRIMARY KEY,
  label text NOT NULL,
  path text NOT NULL DEFAULT '/',
  sort_order integer NOT NULL DEFAULT 0,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.nav_links ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view nav links" ON public.nav_links FOR SELECT USING (true);
CREATE POLICY "Authenticated users can insert nav links" ON public.nav_links FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update nav links" ON public.nav_links FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete nav links" ON public.nav_links FOR DELETE TO authenticated USING (true);
