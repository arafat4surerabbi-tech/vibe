
CREATE OR REPLACE FUNCTION public.reset_all_data()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Delete data tables only
  TRUNCATE order_items, orders, customers, products, banners, categories, coupons, nav_links, store_settings;

  -- Reset courier configs: clear credentials, disable, but KEEP the rows
  UPDATE courier_configs SET api_key = '', api_secret = '', username = '', password = '', store_id = '', enabled = false;

  -- Reset delivery zones: disable but KEEP the rows and charges
  UPDATE delivery_zones SET enabled = false;
END;
$$;
