
-- =============================================
-- PRODUCTS
-- =============================================
CREATE TABLE public.products (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  price NUMERIC NOT NULL DEFAULT 0,
  original_price NUMERIC NOT NULL DEFAULT 0,
  image TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT '',
  rating NUMERIC NOT NULL DEFAULT 0,
  reviews INTEGER NOT NULL DEFAULT 0,
  badge TEXT NOT NULL DEFAULT '',
  colors JSONB NOT NULL DEFAULT '[]'::jsonb,
  sizes JSONB NOT NULL DEFAULT '[]'::jsonb,
  stock INTEGER NOT NULL DEFAULT 0,
  description TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view products" ON public.products FOR SELECT USING (true);
CREATE POLICY "Authenticated users can insert products" ON public.products FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update products" ON public.products FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete products" ON public.products FOR DELETE TO authenticated USING (true);

-- =============================================
-- CATEGORIES
-- =============================================
CREATE TABLE public.categories (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  icon TEXT NOT NULL DEFAULT '',
  image TEXT NOT NULL DEFAULT '',
  count INTEGER NOT NULL DEFAULT 0,
  enabled BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view categories" ON public.categories FOR SELECT USING (true);
CREATE POLICY "Authenticated users can insert categories" ON public.categories FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update categories" ON public.categories FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete categories" ON public.categories FOR DELETE TO authenticated USING (true);

-- =============================================
-- BANNERS
-- =============================================
CREATE TABLE public.banners (
  id TEXT PRIMARY KEY DEFAULT 'B' || extract(epoch from now())::bigint::text,
  title TEXT NOT NULL DEFAULT '',
  subtitle TEXT NOT NULL DEFAULT '',
  cta TEXT NOT NULL DEFAULT 'Shop Now',
  bg TEXT NOT NULL DEFAULT '',
  image TEXT NOT NULL DEFAULT '',
  enabled BOOLEAN NOT NULL DEFAULT true,
  link TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.banners ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view banners" ON public.banners FOR SELECT USING (true);
CREATE POLICY "Authenticated users can insert banners" ON public.banners FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update banners" ON public.banners FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete banners" ON public.banners FOR DELETE TO authenticated USING (true);

-- =============================================
-- ORDERS
-- =============================================
CREATE SEQUENCE public.order_id_seq START WITH 1003;

CREATE TABLE public.orders (
  id TEXT PRIMARY KEY,
  customer_name TEXT NOT NULL,
  items_count INTEGER NOT NULL DEFAULT 0,
  total NUMERIC NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Pending',
  phone TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  delivery_area TEXT NOT NULL DEFAULT '',
  payment_method TEXT NOT NULL DEFAULT 'cod',
  courier_booking JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Anyone can insert (checkout)
CREATE POLICY "Anyone can create orders" ON public.orders FOR INSERT WITH CHECK (true);
-- Only authenticated can view/update/delete
CREATE POLICY "Authenticated users can view orders" ON public.orders FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can update orders" ON public.orders FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete orders" ON public.orders FOR DELETE TO authenticated USING (true);

-- =============================================
-- ORDER ITEMS
-- =============================================
CREATE TABLE public.order_items (
  id SERIAL PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_name TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1,
  price NUMERIC NOT NULL DEFAULT 0
);

ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can create order items" ON public.order_items FOR INSERT WITH CHECK (true);
CREATE POLICY "Authenticated users can view order items" ON public.order_items FOR SELECT TO authenticated USING (true);

-- =============================================
-- CUSTOMERS
-- =============================================
CREATE TABLE public.customers (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  orders_count INTEGER NOT NULL DEFAULT 0,
  total_spent NUMERIC NOT NULL DEFAULT 0,
  join_date TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active',
  address TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;

-- Anyone can insert/update (checkout upserts customer)
CREATE POLICY "Anyone can create customers" ON public.customers FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update customers" ON public.customers FOR UPDATE USING (true);
CREATE POLICY "Authenticated users can view customers" ON public.customers FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete customers" ON public.customers FOR DELETE TO authenticated USING (true);

-- =============================================
-- COUPONS
-- =============================================
CREATE TABLE public.coupons (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  discount NUMERIC NOT NULL DEFAULT 0,
  type TEXT NOT NULL DEFAULT 'percent',
  min_order NUMERIC NOT NULL DEFAULT 0,
  max_uses INTEGER NOT NULL DEFAULT 100,
  used_count INTEGER NOT NULL DEFAULT 0,
  expiry TEXT NOT NULL DEFAULT '',
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view coupons" ON public.coupons FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert coupons" ON public.coupons FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update coupons" ON public.coupons FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete coupons" ON public.coupons FOR DELETE TO authenticated USING (true);

-- =============================================
-- DELIVERY ZONES
-- =============================================
CREATE TABLE public.delivery_zones (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  charge NUMERIC NOT NULL DEFAULT 0,
  enabled BOOLEAN NOT NULL DEFAULT true
);

ALTER TABLE public.delivery_zones ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view delivery zones" ON public.delivery_zones FOR SELECT USING (true);
CREATE POLICY "Authenticated users can insert delivery zones" ON public.delivery_zones FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update delivery zones" ON public.delivery_zones FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete delivery zones" ON public.delivery_zones FOR DELETE TO authenticated USING (true);

-- =============================================
-- COURIER CONFIGS
-- =============================================
CREATE TABLE public.courier_configs (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT false,
  api_key TEXT NOT NULL DEFAULT '',
  api_secret TEXT NOT NULL DEFAULT '',
  base_url TEXT NOT NULL DEFAULT '',
  username TEXT NOT NULL DEFAULT '',
  password TEXT NOT NULL DEFAULT '',
  store_id TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.courier_configs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view courier configs" ON public.courier_configs FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert courier configs" ON public.courier_configs FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update courier configs" ON public.courier_configs FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete courier configs" ON public.courier_configs FOR DELETE TO authenticated USING (true);

-- =============================================
-- STORE SETTINGS
-- =============================================
CREATE TABLE public.store_settings (
  id SERIAL PRIMARY KEY,
  key TEXT NOT NULL UNIQUE,
  value TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.store_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view store settings" ON public.store_settings FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert store settings" ON public.store_settings FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update store settings" ON public.store_settings FOR UPDATE TO authenticated USING (true);

-- =============================================
-- AUTO-UPDATE TIMESTAMPS
-- =============================================
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_products_updated_at
BEFORE UPDATE ON public.products
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =============================================
-- GENERATE ORDER ID FUNCTION
-- =============================================
CREATE OR REPLACE FUNCTION public.generate_order_id()
RETURNS TEXT AS $$
BEGIN
  RETURN 'ORD-' || nextval('public.order_id_seq')::text;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- =============================================
-- SEED DATA
-- =============================================

-- Products
INSERT INTO public.products (id, name, price, original_price, image, category, rating, reviews, badge, colors, sizes, stock, description) VALUES
(1, 'Premium Cotton Panjabi', 2450, 3200, '', 'Men', 4.5, 128, 'New', '["#1a1a2e","#e8d5b7","#2d4a3e"]', '["S","M","L","XL"]', 45, 'Crafted from premium quality cotton with intricate embroidery.'),
(2, 'Jamdani Saree Collection', 8500, 12000, '', 'Women', 4.8, 256, 'Best Seller', '["#c9184a","#ff6b6b","#4ecdc4"]', '["Free"]', 12, 'Authentic Jamdani saree handwoven by skilled artisans.'),
(3, 'Designer Kurti Set', 1850, 2500, '', 'Women', 4.3, 89, 'Sale', '["#ff6b6b","#ffd93d","#6bcb77"]', '["S","M","L"]', 67, 'Elegant designer kurti set with matching bottom.'),
(4, 'Kids Party Dress', 1200, 1800, '', 'Kids', 4.6, 45, 'New', '["#ff85a2","#a855f7","#60a5fa"]', '["2-3Y","4-5Y","6-7Y"]', 34, 'Adorable party dress for kids.'),
(5, 'Leather Wallet Premium', 950, 1400, '', 'Accessories', 4.2, 67, '', '["#1a1a2e","#8b4513"]', '["Free"]', 89, 'Genuine leather wallet with multiple card slots.'),
(6, 'Silk Fatua Collection', 3200, 4500, '', 'Men', 4.7, 156, 'Trending', '["#2d4a3e","#c9184a","#e8d5b7"]', '["M","L","XL","XXL"]', 23, 'Luxurious silk fatua with traditional design elements.'),
(7, 'Embroidered Salwar Kameez', 4500, 6000, '', 'Women', 4.4, 198, '', '["#ff6b6b","#4ecdc4","#ffd93d"]', '["S","M","L","XL"]', 56, 'Beautifully embroidered salwar kameez set.'),
(8, 'Handcrafted Jute Bag', 650, 900, '', 'Accessories', 4.1, 34, 'Eco', '["#8b4513","#d4a574"]', '["Free"]', 120, 'Eco-friendly handcrafted jute bag.');

SELECT setval('products_id_seq', 8);

-- Categories
INSERT INTO public.categories (id, name, icon, image, count, enabled) VALUES
(1, 'New Arrivals', '✨', '', 48, true),
(2, 'New Collections', '🎨', '', 36, true),
(3, 'Men', '👔', '', 245, true),
(4, 'Trending', '🔥', '', 89, true);

SELECT setval('categories_id_seq', 4);

-- Banners
INSERT INTO public.banners (id, title, subtitle, cta, bg, image, enabled) VALUES
('B1', 'Eid Collection 2026', 'Discover the finest traditional wear', 'Shop Now', 'from-primary/20 to-accent/10', '', true),
('B2', 'Summer Fashion Sale', 'Up to 50% off on selected items', 'Explore Deals', 'from-accent/20 to-primary/10', '', true),
('B3', 'New Arrivals Weekly', 'Fresh styles every Friday', 'See What''s New', 'from-muted to-muted/50', '', true);

-- Delivery Zones
INSERT INTO public.delivery_zones (id, name, charge, enabled) VALUES
(1, 'Inside Dhaka', 60, true),
(2, 'Dhaka Suburbs', 100, true),
(3, 'Outside Dhaka', 150, true);

SELECT setval('delivery_zones_id_seq', 3);

-- Courier Configs
INSERT INTO public.courier_configs (id, name, enabled, base_url) VALUES
('pathao', 'Pathao', false, 'https://api-hermes.pathao.com'),
('steadfast', 'Steadfast', false, 'https://portal.steadfast.com.bd/api/v1'),
('redx', 'Redx', false, 'https://openapi.redx.com.bd/v1');

-- Coupons
INSERT INTO public.coupons (id, code, discount, type, min_order, max_uses, used_count, expiry, active) VALUES
('CP1', 'EID2026', 15, 'percent', 2000, 100, 45, '2026-05-01', true),
('CP2', 'FLAT500', 500, 'fixed', 3000, 50, 12, '2026-06-30', true),
('CP3', 'SUMMER20', 20, 'percent', 1500, 200, 88, '2026-04-15', false);

-- Customers
INSERT INTO public.customers (id, name, email, phone, orders_count, total_spent, join_date, status, address) VALUES
('C001', 'Rahim Ahmed', 'rahim@email.com', '01712345678', 5, 24500, '2025-12-01', 'active', 'Dhanmondi, Dhaka'),
('C002', 'Fatima Begum', 'fatima@email.com', '01898765432', 3, 18200, '2026-01-15', 'active', 'Gulshan, Dhaka'),
('C003', 'Kamal Hossain', 'kamal@email.com', '01556789012', 8, 45600, '2025-09-20', 'active', 'Chittagong'),
('C004', 'Nasreen Akter', 'nasreen@email.com', '01634567890', 2, 12400, '2026-03-05', 'active', 'Mirpur, Dhaka'),
('C005', 'Sumon Das', 'sumon@email.com', '01987654321', 1, 2450, '2026-04-01', 'blocked', 'Sylhet');

-- Orders
INSERT INTO public.orders (id, customer_name, items_count, total, status, phone, email, address, delivery_area, payment_method) VALUES
('ORD-1001', 'Rahim Ahmed', 2, 5010, 'Pending', '01712345678', 'rahim@email.com', 'Dhanmondi, Dhaka', 'Inside Dhaka', 'cod'),
('ORD-1002', 'Fatima Begum', 1, 8560, 'Processing', '01898765432', 'fatima@email.com', 'Gulshan, Dhaka', 'Inside Dhaka', 'bkash');

-- Order Items
INSERT INTO public.order_items (order_id, product_name, quantity, price) VALUES
('ORD-1001', 'Premium Cotton Panjabi', 1, 2450),
('ORD-1001', 'Leather Wallet Premium', 1, 950),
('ORD-1002', 'Jamdani Saree Collection', 1, 8500);

-- Store Settings
INSERT INTO public.store_settings (key, value) VALUES
('store_name', 'Store'),
('store_email', 'admin@store.com'),
('store_phone', '01700000000'),
('store_address', 'Dhaka, Bangladesh'),
('vat_rate', '5'),
('maintenance_mode', 'false');
