---
name: Design tokens
description: HSL color palette (black/white), fonts, and semantic colors for the e-commerce site
type: design
---
## Colors
- Primary: black (0 0% 0%), Primary-foreground: white (0 0% 100%)
- Secondary: light gray (0 0% 96%)
- Muted: (0 0% 95%), Muted-foreground: (0 0% 45%)
- Accent: (0 0% 92%)
- Background: white, Foreground: black

## Fonts
- Heading: Anek Bangla
- Body: Hind Siliguri

## Status Colors
- Success: 145 60% 42%
- Warning: 38 92% 50%
- Info: 210 80% 55%
- Destructive: 0 84% 60%
