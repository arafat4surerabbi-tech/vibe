

# Meta Pixel Integration with Admin Panel Control

## Overview
Add a Meta (Facebook) Pixel management system that lets you configure and change your pixel ID anytime from the Admin Settings panel. The pixel script will be dynamically injected into all public-facing pages.

## How It Works

1. **Admin Settings** -- A new "Meta Pixel" card in the Settings page with:
   - Pixel ID input field
   - Enable/Disable toggle
   - Saves to the existing `store_settings` table (keys: `meta_pixel_id`, `meta_pixel_enabled`)

2. **Dynamic Script Injection** -- A `MetaPixel` component that:
   - Reads the pixel ID and enabled status from `storeSettings` in StoreContext
   - Injects the Meta Pixel base code (`fbq('init', ...)` + `fbq('track', 'PageView')`) into the `<head>` using `useEffect`
   - Places the `<noscript><img>` fallback in `<body>` (HTML5 compliant)
   - Automatically removes/updates the script when the pixel ID changes or is disabled

3. **Placement** -- The `MetaPixel` component renders inside `App.tsx` (within StoreProvider so it has access to settings). It only activates on public routes, not the admin panel.

## Technical Details

### Database
- Use existing `store_settings` table -- upsert two keys: `meta_pixel_id` and `meta_pixel_enabled`. No migration needed, just insert the rows if they don't exist (the save handler already uses update; we'll add upsert logic).

### Files to Change
- **`src/components/admin/AdminSettings.tsx`** -- Add a "Meta Pixel / Tracking" card with pixel ID input and enable toggle. Save values as `meta_pixel_id` and `meta_pixel_enabled` to store_settings.
- **`src/components/website/MetaPixel.tsx`** (new) -- Component that reads `storeSettings.meta_pixel_id` and `storeSettings.meta_pixel_enabled`, and dynamically injects/removes the Facebook pixel script in the document head.
- **`src/App.tsx`** -- Render `<MetaPixel />` inside the StoreProvider.
- **`src/contexts/StoreContext.tsx`** -- No changes needed; `storeSettings` already loads all key-value pairs.

### Save Logic Enhancement
The current save uses `.update().eq("key", ...)` which fails if the key doesn't exist yet. Will switch to upsert logic so new keys (like `meta_pixel_id`) are auto-created on first save.

